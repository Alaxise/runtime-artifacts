#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ipaddress
import os
import re
import secrets
import tempfile
import urllib.parse
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TEMPLATE = ROOT / "entrypoint" / "no-sso.g5680a.template.conf"
OUTPUT = ROOT / "runtime" / "no-sso-entrypoint.conf"
ANONYMOUS_SECRET = ROOT / "secrets" / "anonymous-session"

INTERNAL_SECRET_KEYS = (
    "NO_SSO_AGENT_API_KEY",
    "NO_SSO_RAG_API_KEY",
    "NO_SSO_MINIO_ROOT_PASSWORD",
)
IMAGE_KEYS = (
    "NO_SSO_PROXY_IMAGE",
    "NO_SSO_UI_IMAGE",
    "NO_SSO_AGENT_IMAGE",
    "NO_SSO_RAG_IMAGE",
    "NO_SSO_VECTOR_SEED_IMAGE",
    "NO_SSO_ETCD_IMAGE",
    "NO_SSO_MINIO_IMAGE",
    "NO_SSO_MILVUS_IMAGE",
)
PORT_CONTRACT = {
    "NO_SSO_ENTRYPOINT_PORT": 20380,
    "NO_SSO_UI_HOST_PORT": 20180,
    "NO_SSO_AGENT_HOST_PORT": 20644,
    "NO_SSO_RAG_HOST_PORT": 20890,
}
VECTOR_ADDRESS_KEYS = (
    "NO_SSO_VECTOR_COORDINATOR_ADDRESS",
    "NO_SSO_VECTOR_OBJECT_ADDRESS",
    "NO_SSO_VECTOR_ENGINE_ADDRESS",
)
TARGET_AUTHORITIES = (
    "scan-planner.hku.hk",
    "scan-planner.hku.hk:443",
    "planner.its.hku.hk",
    "planner.its.hku.hk:443",
    "10.64.142.35",
    "10.64.142.35:20380",
)
PROTECTED_PORTS = {443, 8642, 18380, 18644, 18645, 18890, 19380, 19644}
PLACEHOLDER_MARKERS = ("REPLACE_WITH_", "CHANGEME", "EXAMPLE")
PINNED_IMAGE = re.compile(r"^.+@sha256:[0-9a-f]{64}$")
SHA256 = re.compile(r"^[0-9a-f]{64}$")


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def read_env(path: Path) -> dict[str, str]:
    if not path.is_file():
        fail(f"environment file is missing: {path}")
    values: dict[str, str] = {}
    for number, raw_line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            fail(f"invalid environment entry at {path}:{number}")
        key, value = line.split("=", 1)
        key = key.strip()
        if key in values:
            fail(f"duplicate environment key: {key}")
        values[key] = value.strip()
    return values


def require(values: dict[str, str], key: str) -> str:
    value = values.get(key, "").strip()
    if not value:
        fail(f"{key} is required")
    return value


def is_placeholder(value: str) -> bool:
    upper = value.upper()
    return not value or any(marker in upper for marker in PLACEHOLDER_MARKERS)


def strong_secret(value: str, *, minimum: int = 48) -> bool:
    return (
        len(value) >= minimum
        and not any(character.isspace() for character in value)
        and not is_placeholder(value)
        and len(set(value)) >= 12
    )


def update_env(path: Path, replacements: dict[str, str]) -> None:
    original = path.stat()
    lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
    seen: set[str] = set()
    rendered: list[str] = []
    for line in lines:
        key = line.split("=", 1)[0].strip() if "=" in line else ""
        if key in replacements:
            if key in seen:
                fail(f"duplicate environment key: {key}")
            rendered.append(f"{key}={replacements[key]}\n")
            seen.add(key)
        else:
            rendered.append(line)
    for key, value in replacements.items():
        if key not in seen:
            if rendered and not rendered[-1].endswith(("\n", "\r")):
                rendered[-1] += "\n"
            rendered.append(f"{key}={value}\n")
    with tempfile.NamedTemporaryFile(
        "w", encoding="utf-8", dir=path.parent, prefix=f".{path.name}.", delete=False
    ) as stream:
        stream.writelines(rendered)
        temporary = Path(stream.name)
    try:
        os.chmod(temporary, original.st_mode & 0o777)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _port(values: dict[str, str], key: str) -> int:
    try:
        value = int(require(values, key))
    except ValueError:
        fail(f"{key} must be an integer")
    if not 1024 <= value <= 65535:
        fail(f"{key} must be an unprivileged TCP port")
    return value


def _loopback_http_url(value: str, key: str) -> None:
    parsed = urllib.parse.urlparse(value)
    if parsed.scheme != "http" or parsed.hostname != "127.0.0.1" or parsed.username or parsed.password:
        fail(f"{key} must be an HTTP loopback URL")


def validate_contract(values: dict[str, str], *, root: Path = ROOT) -> None:
    target_root = Path(require(values, "NO_SSO_TARGET_ROOT")).resolve()
    data_root = Path(require(values, "NO_SSO_DATA_ROOT")).resolve()
    if root.resolve() != target_root:
        fail(f"bundle must run from its declared root: {target_root}")
    try:
        data_root.relative_to(target_root)
    except ValueError:
        fail("NO_SSO_DATA_ROOT must be beneath NO_SSO_TARGET_ROOT")
    if data_root != target_root / "data":
        fail("NO_SSO_DATA_ROOT must be the lane-local data directory")
    seed_root = Path(require(values, "NO_SSO_VECTOR_SEED_ROOT")).resolve()
    if seed_root != target_root / "runtime" / "vector-seed-family":
        fail("NO_SSO_VECTOR_SEED_ROOT must be the lane-local family seed directory")
    if require(values, "NO_SSO_SEED_CONTAINER") != "hku-no-sso-v3-seed-family":
        fail("the vector seed container name changed")

    if require(values, "NO_SSO_COLLECTION") != (
        "DATASET_HKU_GB10_POC_03_LATEST_FAMILY_V1"
    ):
        fail(
            "the release collection must remain "
            "DATASET_HKU_GB10_POC_03_LATEST_FAMILY_V1"
        )
    if require(values, "NO_SSO_VECTOR_BACKUP_NAME") != (
        "hku_poc03_family_20260725T163343Z"
    ):
        fail("the release vector backup name changed")
    if require(values, "NO_SSO_EXPECTED_ROWS") != "15647":
        fail("the release row-count contract changed")
    if not SHA256.fullmatch(require(values, "NO_SSO_VECTOR_BACKUP_SHA256")):
        fail("NO_SSO_VECTOR_BACKUP_SHA256 must be a lowercase SHA-256 digest")
    if require(values, "NO_SSO_VECTOR_BACKUP_SHA256") != (
        "e719a441ccf7f939464d88615270c197611b89c53dfaf6d8d6aaee50e4dc1252"
    ):
        fail("the release vector backup digest changed")

    ports = {key: _port(values, key) for key in PORT_CONTRACT}
    for key, expected in PORT_CONTRACT.items():
        if ports[key] != expected:
            fail(f"{key} must remain {expected}")
    if len(set(ports.values())) != len(ports):
        fail("lane ports must be unique")
    collisions = sorted(set(ports.values()) & PROTECTED_PORTS)
    if collisions:
        fail(f"lane ports overlap protected services: {collisions}")

    resolved_vector_addresses: list[ipaddress.IPv4Address] = []
    for key in VECTOR_ADDRESS_KEYS:
        value = require(values, key)
        if value == "AUTO":
            continue
        try:
            address = ipaddress.ip_address(value)
        except ValueError:
            fail(f"{key} must be AUTO or a private IPv4 address")
        if not isinstance(address, ipaddress.IPv4Address) or not address.is_private or address.is_loopback:
            fail(f"{key} must be AUTO or a private non-loopback IPv4 address")
        resolved_vector_addresses.append(address)
    if resolved_vector_addresses and len(resolved_vector_addresses) != len(VECTOR_ADDRESS_KEYS):
        fail("vector addresses must be either all AUTO or all resolved")
    if len(set(resolved_vector_addresses)) != len(resolved_vector_addresses):
        fail("resolved vector dependency addresses must be unique")

    if require(values, "NO_SSO_BIND_ADDRESS") != "0.0.0.0":
        fail("the browser entrypoint must bind 0.0.0.0")
    public_url = urllib.parse.urlparse(require(values, "NO_SSO_PUBLIC_URL"))
    if public_url.scheme not in {"http", "https"} or not public_url.hostname:
        fail("NO_SSO_PUBLIC_URL must be an HTTP(S) origin")
    if public_url.path not in {"", "/"} or public_url.query or public_url.fragment:
        fail("NO_SSO_PUBLIC_URL must not contain a path, query, or fragment")
    if public_url.geturl().rstrip("/") != "https://planner.its.hku.hk":
        fail("NO_SSO_PUBLIC_URL must remain the approved public HTTPS origin")
    cookie_secure = require(values, "NO_SSO_ANONYMOUS_COOKIE_SECURE")
    if cookie_secure not in {"0", "1"}:
        fail("NO_SSO_ANONYMOUS_COOKIE_SECURE must be 0 or 1")
    if cookie_secure != "0":
        fail("the no-SSO UAT lane must permit its anonymous cookie over HTTP")

    for key in ("NO_SSO_EMBEDDING_BASE_URL", "NO_SSO_RERANKER_BASE_URL"):
        _loopback_http_url(require(values, key), key)
    control_urls = [item.strip() for item in require(values, "NO_SSO_CONTROL_URLS").split(",") if item.strip()]
    if len(control_urls) < 2:
        fail("NO_SSO_CONTROL_URLS must protect both the 18380 and 18890 controls")
    for url in control_urls:
        _loopback_http_url(url, "NO_SSO_CONTROL_URLS")
    if not any(":18380" in url for url in control_urls) or not any(":18890" in url for url in control_urls):
        fail("control URLs must include ports 18380 and 18890")

    secrets_by_key = {key: require(values, key) for key in INTERNAL_SECRET_KEYS}
    for key, value in secrets_by_key.items():
        if not strong_secret(value):
            fail(f"{key} must be an independently generated strong secret")
    if len(set(secrets_by_key.values())) != len(secrets_by_key):
        fail("lane-local secrets must be different from one another")
    model_key = require(values, "DEEPSEEK_API_KEY")
    if is_placeholder(model_key) or any(character.isspace() for character in model_key):
        fail("DEEPSEEK_API_KEY must be supplied without whitespace")
    if not re.fullmatch(r"[a-z][a-z0-9-]{2,31}", require(values, "NO_SSO_MINIO_ROOT_USER")):
        fail("NO_SSO_MINIO_ROOT_USER must be a neutral lowercase service account")

    require_digests = require(values, "NO_SSO_REQUIRE_DIGESTS")
    if require_digests not in {"0", "1"}:
        fail("NO_SSO_REQUIRE_DIGESTS must be 0 or 1")
    if require_digests == "1":
        for key in IMAGE_KEYS:
            if not PINNED_IMAGE.fullmatch(require(values, key)):
                fail(f"{key} must be pinned by sha256 registry digest")

    forbidden = [key for key in values if key.startswith("AUTH_OIDC_") or key.startswith("AUTH_GATEWAY_")]
    if forbidden:
        fail(f"OIDC configuration is forbidden in the no-SSO lane: {', '.join(sorted(forbidden))}")


def ensure_generated_values(env_path: Path) -> None:
    values = read_env(env_path)
    replacements: dict[str, str] = {}
    for key in INTERNAL_SECRET_KEYS:
        if not strong_secret(values.get(key, "")):
            replacements[key] = secrets.token_hex(32)
    if replacements:
        update_env(env_path, replacements)

    ANONYMOUS_SECRET.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(ANONYMOUS_SECRET.parent, 0o700)
    if not ANONYMOUS_SECRET.is_file() or not strong_secret(
        ANONYMOUS_SECRET.read_text(encoding="ascii") if ANONYMOUS_SECRET.is_file() else ""
    ):
        temporary = ANONYMOUS_SECRET.with_name(f".{ANONYMOUS_SECRET.name}.{os.getpid()}")
        temporary.write_text(secrets.token_hex(32), encoding="ascii")
        os.chmod(temporary, 0o444)
        os.replace(temporary, ANONYMOUS_SECRET)
    os.chmod(ANONYMOUS_SECRET, 0o444)
    os.chmod(env_path, 0o600)


def render(values: dict[str, str]) -> None:
    content = TEMPLATE.read_text(encoding="utf-8")
    authorities = "\n".join(f'    "{value}" 1;' for value in TARGET_AUTHORITIES)
    replacements = {
        "__ALLOWED_AUTHORITIES__": authorities,
        "__BIND_ADDRESS__": require(values, "NO_SSO_BIND_ADDRESS"),
        "__ENTRYPOINT_PORT__": require(values, "NO_SSO_ENTRYPOINT_PORT"),
        "__UI_PORT__": require(values, "NO_SSO_UI_HOST_PORT"),
    }
    for marker, value in replacements.items():
        if content.count(marker) != 1:
            fail(f"entrypoint template marker changed: {marker}")
        content = content.replace(marker, value)
    if "__" in content:
        fail("unresolved entrypoint template marker remains")
    OUTPUT.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    temporary = OUTPUT.with_name(f".{OUTPUT.name}.{os.getpid()}")
    temporary.write_text(content, encoding="utf-8")
    os.chmod(temporary, 0o444)
    os.replace(temporary, OUTPUT)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("prepare", "check", "render"))
    parser.add_argument("--env", type=Path, default=ROOT / ".env")
    args = parser.parse_args()
    if args.command == "prepare":
        ensure_generated_values(args.env)
    values = read_env(args.env)
    validate_contract(values)
    if args.command in {"prepare", "render"}:
        render(values)
    print(f"no-SSO target configuration {args.command} ok")


if __name__ == "__main__":
    main()
