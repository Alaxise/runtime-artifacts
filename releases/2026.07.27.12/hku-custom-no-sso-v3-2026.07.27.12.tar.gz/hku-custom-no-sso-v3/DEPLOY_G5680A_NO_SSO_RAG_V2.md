# Isolated no-SSO POC03 application refresh

This release refreshes only the UI, agent runtime, and search API of the existing
no-SSO lane on port `20380`. It does not recreate or restart that lane's
entrypoint, vector coordinator, object store, or vector engine. It also leaves
all services on ports `18380`, `443`, `18644`, `18645`, and `18890` unchanged.

## Fixed contract

| Item | Value |
|---|---|
| Target root | `/model/dockervolume/hku-custom-no-sso-v3` |
| Compose project | `hku-no-sso-v3` |
| Public HTTP | `0.0.0.0:20380` |
| Loopback UI | `127.0.0.1:20180` |
| Loopback agent | `127.0.0.1:20644` |
| Loopback search API | `127.0.0.1:20890` |
| Collection | `DATASET_HKU_GB10_POC_03_LATEST_FAMILY_V1` |
| Expected rows | `15647` |
| Authentication mode | Anonymous signed browser session |

The lane contains one entrypoint, one UI, one agent runtime, one search API, and a lane-private vector store. It has no external identity gateway, session store, PostgreSQL, replicas, admission control, or monitoring stack.

The collection retains its `is_latest` field for provenance. Of its 15,647
rows, 9,380 are true, 6,267 are false, and none are null. The search API
accepts `is_latest` only through the structured filter object and does not
return the field in API payloads. Raw filter expressions remain rejected.

The agent sends `is_latest=true` by default. When a user explicitly requests an
academic year, the agent omits `is_latest` and filters by that year. The retired
broad instruction to resolve conflicting chunks after retrieval is not
present.

The UI, agent, and search API are Linux ARM64 PyInstaller artifacts built in multiple stages with application source removed. Their runtime names and package surface are neutral. The agent is stateless, dashboard-disabled, memory-disabled, and logs only at `ERROR`. Each search hit is capped at 4,000 characters; context files are capped at 32,768 characters; the agent uses at most six iterations and 1,200 output tokens.

## Isolation boundary

Only port `20380` is browser-reachable. UI, agent, and search are loopback-only. The coordinator, object store, and vector engine publish no host ports and remain on Docker's private bridge. Their private addresses are resolved and validated before the search service is created. Every mutable path is below the target root. The lane reuses the existing embedding and reranking endpoints read-only and must not restart them.

The start script captures all pre-existing containers and control health before startup. Its final check requires those identities and endpoints to remain unchanged. If candidate verification fails, it stops only the seven candidate containers and preserves files, data, evidence, and stopped containers for diagnosis.

Never use `down`, `rm`, `prune`, or a command aimed at another Compose project. The stop script uses only `docker-compose stop` for this project.

## Stage without changing the running lane

Download the release archive and checksum into a versioned directory below the
authorized target root. Do not extract it over the running deployment:

```bash
mkdir -p /model/dockervolume/hku-custom-no-sso-v3/releases/2026.07.25.2
cd /model/dockervolume/hku-custom-no-sso-v3/releases/2026.07.25.2

curl -fL -o hku-custom-no-sso-v3-2026.07.25.2.tar.gz "${BUNDLE_URL}"
curl -fL -o hku-custom-no-sso-v3-2026.07.25.2.tar.gz.sha256 "${CHECKSUM_URL}"
sha256sum -c hku-custom-no-sso-v3-2026.07.25.2.tar.gz.sha256
tar -xzf hku-custom-no-sso-v3-2026.07.25.2.tar.gz --strip-components=1
unset BUNDLE_URL CHECKSUM_URL
```

The refresh reuses the running lane's existing secrets and mutable data. It
does not replace `.env` wholesale and does not print any credential.

## Read-only preflight

Before any application refresh, compare the documented target with a fresh
inventory. Confirm:

- `/model/dockervolume/hku-custom-no-sso-v3` is the only authorized root;
- Compose project and all `hku-no-sso-v3-*` names are free or already owned by this project;
- ports `20380`, `20180`, `20644`, and `20890` are owned by the documented
  `hku-no-sso-v3` containers;
- the three private vector dependencies have no Docker host-port bindings;
- control ports `18380`, `443`, `18644`, `18645`, and `18890` retain their current owners and health;
- embedding and reranking endpoints at `127.0.0.1:18112` and `127.0.0.1:18113` are the approved shared dependencies; and
- sufficient storage remains below `/model/dockervolume`.

Do not run a fresh install or vector restore against an already running lane.
The UAT hotfix script performs image, ownership, database, and control preflight
checks before its first mutation.

## Apply and verify the UAT access hotfix

```bash
./ApplyNoSSOUTATHotfix.sh /model/dockervolume/hku-custom-no-sso-v3
```

The hotfix is ordered:

1. Validate the exact target root, Compose project, current image boundary, and
   container ownership.
2. Capture the five preserved agent, search, and vector containers, control
   endpoints, UI database integrity and row counts, and an online SQLite backup.
3. Update the exact authority list for `planner.its.hku.hk` and set the
   anonymous UAT cookie to work over HTTP while retaining `HttpOnly` and
   `SameSite=Lax`.
4. Recreate only the UI and entrypoint containers.
5. Re-run the Tenable-mapped ingress checks, anonymous browser flow, and six
   historical completion cases.
6. Prove the agent, search, vector services, data, prompt, images, mounts, and
   external controls are unchanged.

Acceptance requires:

- all seven existing runtime containers remain healthy;
- only the UI and entrypoint container IDs may change;
- agent, search, and all three vector containers retain their exact IDs,
  images, mounts, and health;
- the UI, agent, and search images contain no application `.py` or `.pyc` payload;
- `planner.its.hku.hk` is accepted while wildcard and malformed authorities
  still return `421`;
- the anonymous cookie omits `Secure` but retains `HttpOnly` and
  `SameSite=Lax`;
- all six historical stuck-response cases complete with a terminal event; and
- every pre-existing control container and endpoint is unchanged.

The browser acceptance URL is:

`http://10.64.142.35:20380`

## Roll back only the UAT access hotfix

If acceptance fails after the automatic recovery path, provide the preserved
`uat-http-hotfix-*` evidence directory:

```bash
./RollbackNoSSOUTATHotfix.sh \
  /model/dockervolume/hku-custom-no-sso-v3 \
  /model/dockervolume/hku-custom-no-sso-v3/evidence/uat-http-hotfix-<timestamp>
```

Rollback restores the previous environment and entrypoint configuration, then
recreates only the UI and entrypoint. It preserves the agent, search, vector
services, collections, data, configuration backups, and evidence.

## Stop and preserve

```bash
cd /model/dockervolume/hku-custom-no-sso-v3
./StopNoSSOG5680A.sh
```

This stops only the candidate project's seven runtime containers. It preserves the seed container, data, configuration, and evidence. Removal requires separate human approval.

## Known boundaries

- This lane intentionally has no user authentication and is suitable only for the approved UAT/PT network boundary.
- The model key and generated lane credentials remain in an owner-readable `.env` because the current runtimes do not support secret-file variables.
- Embedding and reranking remain shared dependencies until independently packaged variants are approved.
- `is_latest` tagging must be evaluated programme by programme. Aggregate counts
  alone do not prove that every older document without a replacement is tagged
  true.
- The semantic qualification completed 37/37 requests with zero request errors.
  The bounded automated judge passed 32 cases; source adjudication passed 34.
  Both results remain in the release evidence.
- Three semantic gaps remain: DS&E curriculum completeness, one unsupported
  programme in the technology-master's fee comparison, and BChinMed Common
  Core retrieval.
- The independent GB10 technical and manual browser rehearsal passed. Target
  deployment still requires explicit authorization, a fresh g5680a inventory,
  and the full target checks.
