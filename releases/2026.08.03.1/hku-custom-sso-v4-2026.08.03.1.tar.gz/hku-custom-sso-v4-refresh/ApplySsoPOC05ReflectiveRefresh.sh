#!/usr/bin/env bash
set -euo pipefail

PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET_ROOT="/model/dockervolume/hku-custom-sso-v4"
PROJECT="hku-sso-v4"
CANDIDATE_ENV="$PACKAGE_ROOT/.env.g5680a.sso-poc05-refresh.example"
OVERRIDE="$PACKAGE_ROOT/compose.sso-poc05-refresh.override.yml"
BASE_COMPOSE="$TARGET_ROOT/compose.sso-poc04.g5680a.yml"
UPDATE_ID="${SSO_POC05_UPDATE_ID:-$(date -u +%Y%m%dT%H%M%SZ)-poc05-reflective-refresh}"
UPDATE_DIR="$TARGET_ROOT/updates/$UPDATE_ID"
COMPOSE=(
  "$PACKAGE_ROOT/scripts/compose_no_sso.sh"
  -p "$PROJECT"
  -f "$BASE_COMPOSE"
  -f "$OVERRIDE"
)

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

env_value() {
  local file="$1"
  local key="$2"
  awk -F= -v key="$key" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' "$file"
}

wait_health() {
  local container="$1"
  local state
  for _ in $(seq 1 90); do
    state="$(docker inspect "$container" --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' 2>/dev/null || true)"
    [[ "$state" == "healthy" || "$state" == "running" ]] && return 0
    sleep 2
  done
  fail "$container did not become ready"
}

pull_image() {
  local reference="$1"
  local attempt
  for attempt in $(seq 1 5); do
    docker pull "$reference" && return 0
    sleep "$((attempt * 5))"
  done
  fail "image pull failed: $reference"
}

[[ "$(cd "$TARGET_ROOT" && pwd -P)" == "$TARGET_ROOT" ]] || fail "target root changed"
[[ ! -L "$TARGET_ROOT" ]] || fail "target root must not be a symbolic link"
[[ -f "$TARGET_ROOT/.env" ]] || fail "live environment is missing"
[[ -f "$BASE_COMPOSE" ]] || fail "live Compose file is missing"
[[ -f "$CANDIDATE_ENV" && -f "$OVERRIDE" ]] || fail "candidate contract is incomplete"
[[ ! -e "$UPDATE_DIR" ]] || fail "update evidence directory already exists"

mkdir -p "$UPDATE_DIR"
chmod 700 "$UPDATE_DIR"
cp "$TARGET_ROOT/.env" "$UPDATE_DIR/before.env"
cp "$BASE_COMPOSE" "$UPDATE_DIR/compose.before.yml"
chmod 600 "$UPDATE_DIR/before.env" "$UPDATE_DIR/compose.before.yml"

python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" \
  --root "$TARGET_ROOT" \
  --env "$TARGET_ROOT/.env" \
  capture-preserved \
  --output "$UPDATE_DIR/preserved-before.json"

python3 - "$UPDATE_DIR/before.env" "$CANDIDATE_ENV" "$UPDATE_DIR/candidate.env" <<'PY'
import os
import pathlib
import sys

live_path = pathlib.Path(sys.argv[1])
candidate_path = pathlib.Path(sys.argv[2])
output_path = pathlib.Path(sys.argv[3])
allowed = {
    "NO_SSO_COLLECTION",
    "NO_SSO_EXPECTED_ROWS",
    "NO_SSO_EXPECTED_LATEST_ROWS",
    "NO_SSO_EXPECTED_NOT_LATEST_ROWS",
    "NO_SSO_VECTOR_BACKUP_NAME",
    "NO_SSO_VECTOR_BACKUP_SHA256",
    "NO_SSO_SEED_CONTAINER",
    "NO_SSO_VECTOR_SEED_ROOT",
    "NO_SSO_UI_IMAGE",
    "NO_SSO_AGENT_IMAGE",
    "NO_SSO_RAG_IMAGE",
    "NO_SSO_VECTOR_SEED_IMAGE",
    "NO_SSO_GROUNDED_COORDINATOR_TOTAL_TIMEOUT_SECONDS",
    "NO_SSO_GROUNDED_COORDINATOR_SPARSE_WEIGHT",
    "NO_SSO_GROUNDED_COORDINATOR_DENSE_WEIGHT",
    "NO_SSO_RAG_MAX_CONCURRENCY",
    "NO_SSO_RAG_MAX_QUEUE",
    "NO_SSO_RAG_QUEUE_TIMEOUT_SECONDS",
    "NO_SSO_CONTROL_URLS",
    "NO_SSO_CONTROL_PORTS",
}

def read(path):
    values = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        key, separator, value = line.partition("=")
        if not separator or key in values:
            raise SystemExit(f"invalid environment entry: {line}")
        values[key] = value
    return values

live = read(live_path)
updates = read(candidate_path)
if set(updates) != allowed:
    raise SystemExit("candidate environment key set changed")
live.update(updates)
with output_path.open("w", encoding="utf-8") as stream:
    for key, value in live.items():
        stream.write(f"{key}={value}\n")
os.chmod(output_path, 0o600)
PY

for key in NO_SSO_UI_IMAGE NO_SSO_AGENT_IMAGE NO_SSO_RAG_IMAGE NO_SSO_VECTOR_SEED_IMAGE; do
  pull_image "$(env_value "$UPDATE_DIR/candidate.env" "$key")"
done

python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" \
  --root "$TARGET_ROOT" \
  --env "$UPDATE_DIR/candidate.env" \
  preflight
python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" \
  --root "$TARGET_ROOT" \
  --env "$UPDATE_DIR/candidate.env" \
  capture \
  --output "$UPDATE_DIR/control-before.json"

NO_SSO_ENV_FILE="$UPDATE_DIR/candidate.env" \
NO_SSO_OPERATION_EVIDENCE_DIR="$UPDATE_DIR" \
  "$PACKAGE_ROOT/StagePOC03.sh"
NO_SSO_ENV_FILE="$UPDATE_DIR/candidate.env" \
NO_SSO_OPERATION_EVIDENCE_DIR="$UPDATE_DIR" \
NO_SSO_OPERATION_RUNTIME_DIR="$UPDATE_DIR/runtime" \
  "$PACKAGE_ROOT/RestorePOC03.sh"

temporary="$(mktemp "$TARGET_ROOT/.env.candidate.XXXXXX")"
cp "$UPDATE_DIR/candidate.env" "$temporary"
chmod 600 "$temporary"
mv "$temporary" "$TARGET_ROOT/.env"

rollback_on_error() {
  local status=$?
  trap - EXIT INT TERM
  "$PACKAGE_ROOT/RollbackSsoPOC05ReflectiveRefresh.sh" "$UPDATE_DIR" || true
  exit "$status"
}
trap rollback_on_error EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

"${COMPOSE[@]}" config >/dev/null
"${COMPOSE[@]}" up -d --no-deps rag-api
wait_health hku-sso-v4-search
"${COMPOSE[@]}" up -d --no-deps agent-runtime
wait_health hku-sso-v4-agent
"${COMPOSE[@]}" up -d --no-deps web-ui
wait_health hku-sso-v4-ui

"$PACKAGE_ROOT/CheckSsoPOC05ReflectiveRefresh.sh" "$UPDATE_DIR"
printf '%s\n' "$UPDATE_DIR" > "$TARGET_ROOT/runtime/latest-poc05-reflective-refresh"
chmod 600 "$TARGET_ROOT/runtime/latest-poc05-reflective-refresh"
trap - EXIT INT TERM
echo "Authenticated POC05 reflective refresh applied and verified: $UPDATE_DIR"
