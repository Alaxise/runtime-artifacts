#!/usr/bin/env bash
set -euo pipefail

PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET_ROOT="/model/dockervolume/hku-custom-sso-v4"
CONTRACT="$PACKAGE_ROOT/.env.g5680a.sso-protected-agent.example"
UPDATE_DIR="${1:-}"

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

contract_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' "$CONTRACT"
}

live_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' "$TARGET_ROOT/.env"
}

[[ -n "$UPDATE_DIR" && -f "$UPDATE_DIR/agent-refresh-before.json" ]] \
  || fail "agent-refresh snapshot is missing"
mkdir -p "$UPDATE_DIR/evidence"

python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" \
  --root "$TARGET_ROOT" --env "$TARGET_ROOT/.env" check-config
python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" \
  --root "$TARGET_ROOT" --env "$TARGET_ROOT/.env" verify-target
python3 "$PACKAGE_ROOT/scripts/sso_agent_refresh_control.py" \
  compare-preserved --snapshot "$UPDATE_DIR/agent-refresh-before.json"
for preserved_name in hku-sso-v4-ui hku-sso-v4-search hku-sso-v4-gateway; do
  docker inspect "$preserved_name" >/dev/null \
    || fail "preserved SSO container is unavailable: $preserved_name"
done
python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" \
  --root "$TARGET_ROOT" --env "$TARGET_ROOT/.env" \
  compare --before "$UPDATE_DIR/control-before.json"

actual_image_id="$(docker inspect hku-sso-v4-agent --format '{{.Image}}')"
[[ "$actual_image_id" == "$(contract_value REFRESH_CANDIDATE_AGENT_IMAGE_ID)" ]] \
  || fail "running agent differs from the qualified protected image"
[[ "$(live_value NO_SSO_AGENT_IMAGE)" == "$(contract_value REFRESH_CANDIDATE_AGENT_IMAGE)" ]] \
  || fail "live environment is not pinned to the protected image digest"

for label in \
  "org.opencontainers.image.revision=$(contract_value REFRESH_EXPECTED_SOURCE_REVISION)" \
  "hku.agent.behavior.revision=$(contract_value REFRESH_EXPECTED_BEHAVIOR_REVISION)" \
  "hku.agent.prompt.sha256=$(contract_value REFRESH_EXPECTED_PROMPT_SHA256)"; do
  key="${label%%=*}"
  value="${label#*=}"
  actual="$(docker image inspect "$(contract_value REFRESH_CANDIDATE_AGENT_IMAGE)" --format "{{index .Config.Labels \"$key\"}}")"
  [[ "$actual" == "$value" ]] || fail "protected image label changed: $key"
done

agent_env="$(docker inspect hku-sso-v4-agent --format '{{range .Config.Env}}{{println .}}{{end}}')"
for setting in \
  'DEEPSEEK_MODEL=deepseek-v4-flash' \
  'DEEPSEEK_JUDGE_MODEL=deepseek-v4-flash' \
  'HKU_COURSE_SEARCH_COLLECTION=DATASET_HKU_GB10_POC_05' \
  'HKU_AGENT_MODEL_MAX_TOKENS=4096' \
  'HKU_AGENT_CONTEXT_FILE_MAX_CHARS=65536' \
  'HKU_AGENT_DASHBOARD_ENABLED=false' \
  'HKU_GROUNDED_JUDGE_TIMEOUT_SECONDS=8' \
  'HKU_GROUNDED_JUDGE_MAX_TOKENS=1024' \
  'HKU_GROUNDED_REPAIR_TIMEOUT_SECONDS=6' \
  'HKU_GROUNDED_REPAIR_MAX_TOKENS=4096' \
  'HKU_GLOBAL_DEADLINE_SECONDS=60' \
  'HKU_COURSE_SEARCH_RETRIEVAL_EVALUATOR_TIMEOUT_SECONDS=4' \
  'HKU_COURSE_SEARCH_QUALIFIED_ROUTING=false' \
  'HKU_COURSE_SEARCH_ANSWER_HINTS=false' \
  'HKU_TIMETABLE_DB_PATH=/opt/hku-runtime/data/timetable.sqlite3' \
  'HKU_TIMETABLE_QUERY_TIMEOUT_SECONDS=2' \
  'HKU_TIMETABLE_CONFLICT_TIMEOUT_SECONDS=2' \
  'LOG_LEVEL=ERROR' \
  'HKU_AGENT_LOG_LEVEL=ERROR'; do
  grep -Fqx "$setting" <<<"$agent_env" || fail "agent runtime setting changed: $setting"
done

docker exec hku-sso-v4-agent sh -ec '
  test -x /opt/hku-runtime/bin/hku-agent-runtime
  test ! -e /app
  test ! -d /opt/hku-runtime/venv
  test -z "$(find /opt/hku-runtime -type f \( -name "*.py" -o -name "*.pyc" \) -print -quit)"
  internal_a="her""mes"
  internal_b="no""us"
  internal_c="co""dex"
  test -z "$(find /opt/hku-runtime \( -iname "*${internal_a}*" -o -iname "*${internal_b}*" -o -iname "*${internal_c}*" \) -print -quit)"
  test ! -w /opt/hku-runtime/data/timetable.sqlite3
  /opt/hku-runtime/bin/hku-agent-runtime __release_check__
' > "$UPDATE_DIR/evidence/release-check.json"
grep -Fq '"dashboard_enabled": false' "$UPDATE_DIR/evidence/release-check.json"
grep -Fq '"global_deadline_seconds": 60.0' "$UPDATE_DIR/evidence/release-check.json"
grep -Fq '"meeting_rows": 28174' "$UPDATE_DIR/evidence/release-check.json"
grep -Fq "\"prompt_sha256\": \"$(contract_value REFRESH_EXPECTED_PROMPT_SHA256)\"" \
  "$UPDATE_DIR/evidence/release-check.json"

timetable_sha="$(docker exec hku-sso-v4-agent sha256sum /opt/hku-runtime/data/timetable.sqlite3 | awk '{print $1}')"
[[ "$timetable_sha" == "$(contract_value REFRESH_EXPECTED_TIMETABLE_SHA256)" ]] \
  || fail "protected timetable snapshot changed"

docker exec hku-sso-v4-agent \
  /opt/hku-runtime/bin/hku-agent-runtime __live_contract_check__ \
  > "$UPDATE_DIR/evidence/live-timetable-contract.json"
grep -Fq '"verified": true' "$UPDATE_DIR/evidence/live-timetable-contract.json"

curl -fsS "http://127.0.0.1:$(live_value NO_SSO_AGENT_HOST_PORT)/health" \
  > "$UPDATE_DIR/evidence/agent-health.json"
curl -fsS \
  -H "Authorization: Bearer $(live_value AUTH_AGENT_API_KEY)" \
  "http://127.0.0.1:$(live_value NO_SSO_AGENT_HOST_PORT)/v1/models" \
  > "$UPDATE_DIR/evidence/agent-models.json"

python3 "$PACKAGE_ROOT/tests/e2e_sso_protected_agent.py" \
  --base-url "http://127.0.0.1:$(live_value NO_SSO_AGENT_HOST_PORT)" \
  --env-file "$TARGET_ROOT/.env" \
  --output "$UPDATE_DIR/evidence/behavior.json"

curl -kfsS \
  --resolve curr-planner.hku.hk:443:127.0.0.1 \
  https://curr-planner.hku.hk/__health \
  > "$UPDATE_DIR/evidence/public-health.txt"
public_body="$UPDATE_DIR/evidence/public-prelogin-body.html"
auth_status="$(curl -ksS -o "$public_body" -w '%{http_code}' \
  --resolve curr-planner.hku.hk:443:127.0.0.1 \
  https://curr-planner.hku.hk/)"
api_me_status=""
if [[ "$auth_status" == "200" ]]; then
  api_me_status="$(curl -ksS -o "$UPDATE_DIR/evidence/public-api-me-body.html" -w '%{http_code}' \
    --resolve curr-planner.hku.hk:443:127.0.0.1 \
    https://curr-planner.hku.hk/api/me)"
fi
prelogin_args=(
  --public-status "$auth_status"
  --public-body "$public_body"
)
if [[ -n "$api_me_status" ]]; then
  prelogin_args+=(--api-me-status "$api_me_status")
fi
python3 "$PACKAGE_ROOT/scripts/sso_prelogin_contract.py" "${prelogin_args[@]}"
printf '%s\n' "$auth_status" > "$UPDATE_DIR/evidence/public-prelogin-status.txt"
printf '%s\n' "$api_me_status" > "$UPDATE_DIR/evidence/public-api-me-status.txt"

python3 "$PACKAGE_ROOT/scripts/sso_agent_refresh_control.py" \
  compare-preserved --snapshot "$UPDATE_DIR/agent-refresh-before.json"
echo "Protected authenticated agent refresh verification passed."
