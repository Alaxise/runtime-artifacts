#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import subprocess
from pathlib import Path


RELEASE_ID = "hku-sso-protected-agent-g5680a-2026.08.14.5"
PARENT_RELEASE = "hku-sso-poc05-g5680a-2026.08.03.3"
IMAGE = (
    "middletaste/hku-custom-core:protected-28480-8d87ce275850-arm64@"
    "sha256:26c3eb6e187739f932c66a3a71594807a2be34c42b9ae9437bb19db3f43dea25"
)
IMAGE_ID = "sha256:ec9de45cd7e39c0eb80f0b52943f02be8be867d61d555acd9df667606946a06b"
EXPECTED_PACKAGE_FILES = [
    ".env.g5680a.sso-protected-agent.example",
    "ApplySsoProtectedAgentRefresh.sh",
    "CheckSsoProtectedAgentRefresh.sh",
    "DEPLOY_G5680A_SSO_PROTECTED_AGENT.md",
    "PackageSsoProtectedAgentG5680A.sh",
    "RollbackSsoProtectedAgentRefresh.sh",
    "THIRD_PARTY_NOTICES_SSO_PROTECTED_AGENT.md",
    "compose.sso-parent-agent.override.yml",
    "compose.sso-protected-agent.override.yml",
    "g5680a-sso-protected-agent-components.lock.json",
    "image-list.sso-protected-agent.g5680a.txt",
    "scripts/compose_no_sso.sh",
    "scripts/sso_agent_refresh_control.py",
    "scripts/sso_prelogin_contract.py",
    "scripts/sso_poc04_target.py",
    "scripts/verify_sso_protected_agent_release.py",
    "tests/e2e_sso_protected_agent.py",
]
EXPECTED_ENV = {
    "REFRESH_RELEASE_ID": RELEASE_ID,
    "REFRESH_PARENT_RELEASE": PARENT_RELEASE,
    "REFRESH_CANDIDATE_AGENT_IMAGE": IMAGE,
    "REFRESH_CANDIDATE_AGENT_IMAGE_ID": IMAGE_ID,
    "REFRESH_EXPECTED_SOURCE_REVISION": "8d87ce275850d09d405966f17979fca37352900c",
    "REFRESH_EXPECTED_BEHAVIOR_REVISION": "3b74fc1b46c7287019f669b09cd4a00a90058b07",
    "REFRESH_EXPECTED_PROMPT_SHA256": "dc64255d05e7bae6771507d2ad6d52797c877cc0f4a7cd94b0e56e2fa49bae20",
    "REFRESH_EXPECTED_TIMETABLE_SHA256": "7a1eac3fa59a3515d2cec7fcf11dd7647972e8f65f8194cd7c488241105cf617",
    "REFRESH_EXPECTED_TIMETABLE_ROWS": "28174",
}
FORBIDDEN_LABELS = (
    "her" + "mes",
    "no" + "us",
    "co" + "dex",
    "cy" + "rus",
    "clau" + "de",
    "op" + "us",
    "open" + "webui",
)
FORBIDDEN_SCALE_TERMS = ("postgres", "replica", "admission", "prometheus", "grafana")
FORBIDDEN_FILES = {
    "AGENTS.md",
    "G5680A_DEPLOYMENT_PLAYBOOK.md",
    "docs/HKU_DEPLOYMENT_LANE_REGISTRY.html",
    ".env",
    "compose.sso-poc04.g5680a.yml",
}
LIVE_SECRET = re.compile(r"(?<![A-Za-z0-9])sk-[A-Za-z0-9_+./=-]{20,}")


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def read_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        key, separator, value = line.partition("=")
        if not separator or key in values:
            fail(f"invalid environment entry: {line}")
        values[key] = value
    return values


def package_paths(path: Path) -> list[str]:
    content = path.read_text(encoding="utf-8")
    match = re.search(r"^files=\(\n(?P<body>.*?)^\)$", content, re.MULTILINE | re.DOTALL)
    if match is None:
        fail("package file list is unavailable")
    return [line.strip() for line in match.group("body").splitlines() if line.strip()]


def compose_services(content: str) -> set[str]:
    match = re.search(r"(?ms)^services:\n(?P<body>.*)\Z", content)
    if match is None:
        fail("Compose services block is unavailable")
    return set(re.findall(r"(?m)^  ([a-z0-9-]+):$", match.group("body")))


def validate_no_scale_ancestry(root: Path) -> None:
    scale_ref = "origin/experiment/gb10-scale-rehearsal"
    reference = subprocess.run(
        ("git", "-C", str(root), "rev-parse", "--verify", scale_ref),
        check=False,
        capture_output=True,
        text=True,
    )
    if reference.returncode != 0:
        fail(f"scale reference is unavailable: {scale_ref}")
    ancestor = subprocess.run(
        ("git", "-C", str(root), "merge-base", "--is-ancestor", scale_ref, "HEAD"),
        check=False,
        capture_output=True,
        text=True,
    )
    if ancestor.returncode == 0:
        fail(f"release contains prohibited scale ancestry: {scale_ref}")
    if ancestor.returncode != 1:
        fail(ancestor.stderr.strip() or "unable to verify release ancestry")


def require_tracked(root: Path, paths: list[str]) -> None:
    result = subprocess.run(
        ("git", "-C", str(root), "ls-files", "--error-unmatch", *paths),
        check=False,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        fail(result.stderr.strip() or "all package files must be tracked")


def is_git_worktree(root: Path) -> bool:
    result = subprocess.run(
        ("git", "-C", str(root), "rev-parse", "--is-inside-work-tree"),
        check=False,
        capture_output=True,
        text=True,
    )
    return result.returncode == 0 and result.stdout.strip() == "true"


def validate(root: Path) -> None:
    env_path = root / ".env.g5680a.sso-protected-agent.example"
    package_path = root / "PackageSsoProtectedAgentG5680A.sh"
    manifest_path = root / "g5680a-sso-protected-agent-components.lock.json"
    image_list_path = root / "image-list.sso-protected-agent.g5680a.txt"
    candidate_override = root / "compose.sso-protected-agent.override.yml"
    parent_override = root / "compose.sso-parent-agent.override.yml"
    for path in (
        env_path,
        package_path,
        manifest_path,
        image_list_path,
        candidate_override,
        parent_override,
    ):
        if not path.is_file():
            fail(f"required release file is missing: {path.name}")

    paths = package_paths(package_path)
    if paths != EXPECTED_PACKAGE_FILES:
        fail("archive file boundary changed")
    if FORBIDDEN_FILES.intersection(paths):
        fail("local orchestration or full-lane material entered the selective archive")
    if any(path.startswith("release/") for path in paths):
        fail("generated archives entered the target archive")
    if is_git_worktree(root):
        require_tracked(root, paths)
        validate_no_scale_ancestry(root)
    else:
        missing = [relative for relative in paths if not (root / relative).is_file()]
        if missing:
            fail("extracted archive is incomplete: " + ", ".join(missing))

    violations: list[str] = []
    for relative in paths:
        content = (root / relative).read_text(encoding="utf-8", errors="ignore")
        lowered = content.casefold()
        for label in FORBIDDEN_LABELS:
            if label in lowered:
                violations.append(f"{relative}: internal label")
        if LIVE_SECRET.search(content):
            violations.append(f"{relative}: live model credential")
    if violations:
        fail("target archive contains forbidden material: " + ", ".join(violations))

    if read_env(env_path) != EXPECTED_ENV:
        fail("candidate environment contract changed")
    if image_list_path.read_text(encoding="utf-8").strip() != IMAGE:
        fail("image list differs from the approved protected image")

    for override in (candidate_override, parent_override):
        content = override.read_text(encoding="utf-8")
        if not content.startswith('version: "2.4"\n'):
            fail("Compose override must retain the legacy 2.4 format")
        if compose_services(content) != {"agent-runtime"}:
            fail("Compose override may define only agent-runtime")
        for term in FORBIDDEN_SCALE_TERMS:
            if term in content.casefold():
                fail(f"Compose override contains excluded topology: {term}")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    release = manifest.get("release", {})
    if release.get("id") != RELEASE_ID or release.get("git_tag") != RELEASE_ID:
        fail("release identity changed")
    if release.get("parent_release") != PARENT_RELEASE:
        fail("parent release changed")
    if release.get("target_root") != "/model/dockervolume/hku-custom-sso-v4":
        fail("target root changed")
    if release.get("compose_project") != "hku-sso-v4":
        fail("Compose project changed")
    if manifest.get("artifact", {}).get("image") != IMAGE:
        fail("protected image reference changed")
    if manifest.get("artifact", {}).get("image_id") != IMAGE_ID:
        fail("protected image ID changed")
    if manifest.get("mutation_boundary") != ["hku-sso-v4-agent"]:
        fail("mutation boundary expanded")
    preserved = set(manifest.get("preserved_containers", []))
    if {"hku-sso-v4-ui", "hku-sso-v4-search", "hku-sso-v4-gateway"} - preserved:
        fail("required SSO containers are not preserved")

    apply = (root / "ApplySsoProtectedAgentRefresh.sh").read_text(encoding="utf-8")
    rollback = (root / "RollbackSsoProtectedAgentRefresh.sh").read_text(encoding="utf-8")
    for content in (apply, rollback):
        if "up -d --no-deps agent-runtime" not in content:
            fail("agent recreation step is missing")
        for service in ("web-ui", "rag-api", "entrypoint", "auth-gateway", "session-store"):
            if f"up -d --no-deps {service}" in content:
                fail(f"mutation boundary expanded to {service}")
    print("protected SSO agent release contract verified")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    validate(args.root.resolve())


if __name__ == "__main__":
    main()
