#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT"

version="2026.07.27.7"
if [[ "$#" -gt 0 && "$1" != "$version" ]]; then
  echo "This packager is locked to release $version." >&2
  exit 1
fi
archive="hku-custom-no-sso-v3-${version}.tar.gz"
release_tag="hku-no-sso-poc03-family-citation-thread-g5680a-${version}"
release_dir="$ROOT/release"

[[ -z "$(git status --porcelain)" ]] \
  || { echo "Refusing to package a dirty worktree." >&2; exit 1; }
[[ "$(git rev-parse HEAD)" == "$(git rev-parse "${release_tag}^{commit}")" ]] \
  || { echo "HEAD must be the exact $release_tag release commit." >&2; exit 1; }
python3 scripts/verify_no_sso_release.py --root "$ROOT" --require-rehearsal

files=(
  .env.g5680a.no-sso-rag-v2.example
  ApplyNoSSOIntegratedRefresh.sh
  CheckNoSSOG5680A.sh
  DEPLOY_G5680A_NO_SSO_RAG_V2.md
  InstallNoSSOG5680A.sh
  PackageNoSSOG5680A.sh
  PrepareNoSSOG5680A.sh
  PreflightNoSSOG5680A.sh
  RestorePOC03.sh
  RollbackNoSSOIntegratedRefresh.sh
  RestartNoSSOG5680A.sh
  RunRegressionNoSSOTarget.sh
  StagePOC03.sh
  StartNoSSOG5680A.sh
  StopNoSSOG5680A.sh
  THIRD_PARTY_NOTICES_NO_SSO.md
  compose.no-sso-rag-v2.g5680a.yml
  entrypoint/no-sso.g5680a.template.conf
  g5680a-no-sso-rag-v2-components.lock.json
  image-list.no-sso-rag-v2.g5680a.txt
  scripts/compose_no_sso.sh
  scripts/no_sso_target_config.py
  scripts/no_sso_target_control.py
  scripts/verify_no_sso_ingress.py
  scripts/verify_vector_seed.py
  tests/e2e_agent_stream_regression.py
  tests/e2e_no_sso_rehearsal.py
)

mkdir -p "$release_dir"
git archive --format=tar --prefix=hku-custom-no-sso-v3/ "$release_tag" -- "${files[@]}" \
  | gzip -n -9 > "$release_dir/$archive"

if command -v sha256sum >/dev/null 2>&1; then
  (cd "$release_dir" && sha256sum "$archive" > "$archive.sha256")
else
  digest="$(shasum -a 256 "$release_dir/$archive" | awk '{print $1}')"
  printf '%s  %s\n' "$digest" "$archive" > "$release_dir/$archive.sha256"
fi

echo "$release_dir/$archive"
echo "$release_dir/$archive.sha256"
