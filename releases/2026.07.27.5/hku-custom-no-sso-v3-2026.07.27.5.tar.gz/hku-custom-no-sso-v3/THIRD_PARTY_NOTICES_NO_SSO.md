# Third-party notices

This deployment uses unmodified container artifacts from the projects below. Their license and notice files remain inside their respective images.

| Component | Pinned version | License reference |
|---|---|---|
| NGINX Open Source | `1.30.4-alpine` | 2-clause BSD-like license, https://github.com/nginx/nginx/blob/master/LICENSE |
| etcd | `v3.5.18` | Apache License 2.0, https://github.com/etcd-io/etcd/blob/v3.5.18/LICENSE |
| MinIO | `RELEASE.2024-05-28T17-19-04Z` | GNU AGPLv3, https://github.com/minio/minio/blob/RELEASE.2024-05-28T17-19-04Z/LICENSE |
| Milvus | `v2.6.3` | Apache License 2.0, https://github.com/milvus-io/milvus/blob/v2.6.3/LICENSE |

The deployment does not rename or modify these infrastructure binaries. Application artifacts and exact image identities are recorded in `g5680a-no-sso-rag-v2-components.lock.json`.

This notice is an inventory aid and not a substitute for legal review of image dependencies.
