#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT"

[[ -f .env ]] || { echo "Missing .env. Start from .env.g5680a.no-sso-rag-v2.example." >&2; exit 1; }
chmod 600 .env
python3 scripts/no_sso_target_config.py prepare --env .env

data_root="$(awk -F= '$1 == "NO_SSO_DATA_ROOT" {sub(/^[^=]*=/, ""); print; exit}' .env)"
[[ "$data_root" == "$ROOT/data" ]] || { echo "The mutable data root must be $ROOT/data." >&2; exit 1; }

umask 077
mkdir -p \
  "$data_root/ui" \
  "$data_root/coordinator" \
  "$data_root/object" \
  "$data_root/vector" \
  evidence runtime secrets
chmod 700 "$data_root" "$data_root/ui" evidence runtime secrets

if [[ "$(id -u)" != "1000" ]]; then
  command -v setfacl >/dev/null 2>&1 || { echo "setfacl is required for the UI data boundary." >&2; exit 1; }
  setfacl -m u:1000:rwx,g::---,m::rwx,o::--- "$data_root/ui"
  setfacl -d -m u::rwx,u:1000:rwx,g::---,m::rwx,o::--- "$data_root/ui"
fi

chmod 444 secrets/anonymous-session runtime/no-sso-entrypoint.conf
chmod 600 .env
echo "Prepared the isolated no-SSO lane under $ROOT"
