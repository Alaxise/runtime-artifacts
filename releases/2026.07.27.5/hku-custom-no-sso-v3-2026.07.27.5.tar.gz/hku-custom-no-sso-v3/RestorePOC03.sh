#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT"
ENV_FILE="${NO_SSO_ENV_FILE:-$ROOT/.env}"

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

env_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' "$ENV_FILE"
}

milvus_post() {
  local path="$1"
  local body="$2"
  curl -fsS \
    -H "Authorization: Bearer root:Milvus" \
    -H "Request-Timeout: 30" \
    -H "Content-Type: application/json" \
    -d "$body" \
    "http://${milvus_address}:${milvus_port}${path}"
}

collection_exists() {
  milvus_post /v2/vectordb/collections/list '{"dbName":"default"}' \
    | grep -Fq "\"${collection}\""
}

[[ -f "$ENV_FILE" ]] || fail "Missing environment file: $ENV_FILE"
collection="$(env_value NO_SSO_COLLECTION)"
expected_rows="$(env_value NO_SSO_EXPECTED_ROWS)"
backup_name="$(env_value NO_SSO_VECTOR_BACKUP_NAME)"
data_root="$(env_value NO_SSO_DATA_ROOT)"
milvus_address="$(env_value NO_SSO_VECTOR_ENGINE_ADDRESS)"
milvus_port="$(env_value NO_SSO_VECTOR_ENGINE_PORT)"
milvus_port="${milvus_port:-19530}"
milvus_http_port="$(env_value NO_SSO_VECTOR_ENGINE_HTTP_PORT)"
milvus_http_port="${milvus_http_port:-9091}"
etcd_address="$(env_value NO_SSO_VECTOR_COORDINATOR_ADDRESS)"
etcd_port="$(env_value NO_SSO_VECTOR_COORDINATOR_PORT)"
etcd_port="${etcd_port:-2379}"
minio_address="$(env_value NO_SSO_VECTOR_OBJECT_ADDRESS)"
minio_port="$(env_value NO_SSO_VECTOR_OBJECT_PORT)"
minio_port="${minio_port:-9000}"
minio_user="$(env_value NO_SSO_MINIO_ROOT_USER)"
minio_password="$(env_value NO_SSO_MINIO_ROOT_PASSWORD)"
payload="$(env_value NO_SSO_VECTOR_SEED_ROOT)"
payload="${payload:-$ROOT/runtime/vector-seed}"
source_backup="$payload/backup/$backup_name"
target_backup="$data_root/object/a-bucket/backup/hku-sync/$backup_name"

[[ -x "$payload/milvus-backup" ]] || fail "The verified vector seed has not been staged"
[[ -d "$target_backup" ]] || fail "The lane-owned backup payload has not been staged"
python3 scripts/verify_vector_seed.py compare --left "$source_backup" --right "$target_backup" \
  > evidence/vector-seed-restore-tree.json

backup_binary="$payload/milvus-backup"
cat > runtime/vector-restore.yaml <<EOF
log:
  level: info
  console: true
  file:
    filename: "$ROOT/evidence/vector-restore.log"
milvus:
  address: "$milvus_address"
  port: $milvus_port
  user: "root"
  password: "Milvus"
  tlsMode: 0
  rpcChannelName: "by-dev-replicate-msg"
  etcd:
    endpoints: "$etcd_address:$etcd_port"
    rootPath: "by-dev"
minio:
  storageType: "minio"
  address: "$minio_address"
  port: $minio_port
  region: ""
  accessKeyID: "$minio_user"
  secretAccessKey: "$minio_password"
  useSSL: false
  useIAM: false
  bucketName: "a-bucket"
  rootPath: "files"
  backupStorageType: "minio"
  backupAddress: "$minio_address"
  backupPort: $minio_port
  backupAccessKeyID: "$minio_user"
  backupSecretAccessKey: "$minio_password"
  backupBucketName: "a-bucket"
  backupRootPath: "backup/hku-sync"
  backupUseSSL: false
  crossStorage: false
backup:
  parallelism:
    copydata: 8
    backupCollection: 1
    backupSegment: 16
    restoreCollection: 1
    importJob: 4
  keepTempFiles: false
  gcPause:
    enable: false
    address: "http://$milvus_address:$milvus_http_port"
EOF
chmod 600 runtime/vector-restore.yaml

"$backup_binary" --config runtime/vector-restore.yaml check >/dev/null
"$backup_binary" --config runtime/vector-restore.yaml get -n "$backup_name" \
  > evidence/vector-backup-record.json

if ! collection_exists; then
  "$backup_binary" --config runtime/vector-restore.yaml restore \
    -n "$backup_name" \
    --filter "default.$collection" \
    --rebuild_index \
    > evidence/vector-restore-command.log
fi

for _ in $(seq 1 180); do
  stats="$(milvus_post /v2/vectordb/collections/get_stats "{\"dbName\":\"default\",\"collectionName\":\"$collection\"}" 2>/dev/null || true)"
  if python3 - "$expected_rows" "$stats" <<'PY'
import json
import sys
expected = int(sys.argv[1])
try:
    payload = json.loads(sys.argv[2])
    value = payload.get("data", {}).get("row_count", payload.get("data", {}).get("rowCount"))
    raise SystemExit(0 if int(value) == expected else 1)
except (TypeError, ValueError, json.JSONDecodeError):
    raise SystemExit(1)
PY
  then
    break
  fi
  sleep 2
done

[[ -n "${stats:-}" ]] || fail "The restored collection did not expose row statistics"
describe="$(milvus_post /v2/vectordb/collections/describe "{\"dbName\":\"default\",\"collectionName\":\"$collection\"}")"
python3 - "$collection" "$expected_rows" "$stats" "$describe" > evidence/vector-collection.json <<'PY'
import json
import sys

collection = sys.argv[1]
expected_rows = int(sys.argv[2])
stats = json.loads(sys.argv[3])
describe = json.loads(sys.argv[4])
row_count = stats.get("data", {}).get("row_count", stats.get("data", {}).get("rowCount"))
if int(row_count) != expected_rows:
    raise SystemExit(f"row count mismatch: {row_count} != {expected_rows}")
fields = describe.get("data", {}).get("fields", [])
latest = [field for field in fields if field.get("fieldName", field.get("name")) == "is_latest"]
if not latest:
    raise SystemExit("is_latest field is absent from the restored collection")
print(json.dumps({"collection": collection, "row_count": int(row_count), "is_latest_field": True}, sort_keys=True))
PY

echo "POC03 vector collection is ready in the lane-owned store."
