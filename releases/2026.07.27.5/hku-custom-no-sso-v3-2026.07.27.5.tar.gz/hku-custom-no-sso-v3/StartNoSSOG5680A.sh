#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT"
COMPOSE=("$ROOT/scripts/compose_no_sso.sh" -p hku-no-sso-v3 -f compose.no-sso-rag-v2.g5680a.yml)

env_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' .env
}

wait_http() {
  local url="$1"
  local label="$2"
  for _ in $(seq 1 180); do
    if curl -fsS "$url" >/dev/null 2>&1; then
      return 0
    fi
    sleep 2
  done
  echo "$label did not become ready: $url" >&2
  return 1
}

wait_milvus() {
  local address="$1"
  local port="$2"
  for _ in $(seq 1 180); do
    if curl -fsS \
      -H 'Authorization: Bearer root:Milvus' \
      -H 'Content-Type: application/json' \
      -d '{"dbName":"default"}' \
      "http://${address}:${port}/v2/vectordb/collections/list" >/dev/null 2>&1; then
      return 0
    fi
    sleep 2
  done
  echo "vector store did not become ready at $address:$port" >&2
  return 1
}

verified=0
started=0

stop_unverified_lane() {
  status=$?
  trap - EXIT INT TERM
  if [[ "$started" == "1" && "$verified" != "1" ]]; then
    echo "Verification did not complete; stopping only the unverified hku-no-sso-v3 containers." >&2
    "${COMPOSE[@]}" stop || true
  fi
  exit "$status"
}

./PrepareNoSSOG5680A.sh
./PreflightNoSSOG5680A.sh
python3 scripts/no_sso_target_control.py --root "$ROOT" --env "$ROOT/.env" \
  capture --output evidence/control-before.json
./StagePOC03.sh

trap stop_unverified_lane EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
started=1
"${COMPOSE[@]}" up -d vector-coordinator vector-object vector-engine
python3 scripts/no_sso_target_control.py --root "$ROOT" --env "$ROOT/.env" \
  sync-vector-addresses
wait_http "http://$(env_value NO_SSO_VECTOR_COORDINATOR_ADDRESS):2379/health" "vector coordinator"
wait_http "http://$(env_value NO_SSO_VECTOR_OBJECT_ADDRESS):9000/minio/health/live" "object store"
wait_milvus "$(env_value NO_SSO_VECTOR_ENGINE_ADDRESS)" 19530
./RestorePOC03.sh

"${COMPOSE[@]}" up -d --no-deps rag-api
wait_http "http://127.0.0.1:$(env_value NO_SSO_RAG_HOST_PORT)/health" "search API"
"${COMPOSE[@]}" up -d --no-deps agent-runtime
wait_http "http://127.0.0.1:$(env_value NO_SSO_AGENT_HOST_PORT)/health" "agent runtime"
"${COMPOSE[@]}" up -d --no-deps web-ui
wait_http "http://127.0.0.1:$(env_value NO_SSO_UI_HOST_PORT)/healthz" "application UI"
"${COMPOSE[@]}" up -d --no-deps entrypoint
./CheckNoSSOG5680A.sh
verified=1
trap - EXIT INT TERM
