#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT"

"$ROOT/scripts/compose_no_sso.sh" -p hku-no-sso-v3 -f compose.no-sso-rag-v2.g5680a.yml stop \
  entrypoint web-ui agent-runtime rag-api vector-engine vector-object vector-coordinator

echo "Only hku-no-sso-v3 services were stopped. No container, image, volume, or data was removed."
