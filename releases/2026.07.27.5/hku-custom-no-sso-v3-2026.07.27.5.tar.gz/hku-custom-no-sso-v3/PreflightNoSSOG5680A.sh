#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT"

python3 scripts/no_sso_target_config.py check --env .env
"$ROOT/scripts/compose_no_sso.sh" -p hku-no-sso-v3 -f compose.no-sso-rag-v2.g5680a.yml config >/dev/null
python3 scripts/no_sso_target_control.py --root "$ROOT" --env "$ROOT/.env" preflight
