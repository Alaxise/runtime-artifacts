#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import http.cookiejar
import json
import os
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from e2e_agent_stream_regression import call_stream, chat_url


LATEST_SCHEDULE_QUESTION = (
    "According to the latest official course-selection schedule, "
    "when does the first-semester add/drop period end?"
)


class LoopbackSecureCookiePolicy(http.cookiejar.DefaultCookiePolicy):
    def return_ok_secure(self, cookie: Any, request: Any) -> bool:
        hostname = urllib.parse.urlparse(request.get_full_url()).hostname
        if hostname in {"127.0.0.1", "localhost"}:
            return True
        return super().return_ok_secure(cookie, request)


def request_json(
    opener: urllib.request.OpenerDirector,
    url: str,
    *,
    payload: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
    timeout: float = 240,
) -> tuple[int, dict[str, Any]]:
    body = json.dumps(payload).encode("utf-8") if payload is not None else None
    request = urllib.request.Request(
        url,
        data=body,
        headers={"Content-Type": "application/json", **(headers or {})},
        method="POST" if payload is not None else "GET",
    )
    with opener.open(request, timeout=timeout) as response:
        return response.status, json.loads(response.read())


def contains_hidden_latest(value: Any) -> bool:
    if isinstance(value, dict):
        return any(
            str(key).strip().lower() == "is_latest" or contains_hidden_latest(item)
            for key, item in value.items()
        )
    if isinstance(value, (list, tuple)):
        return any(contains_hidden_latest(item) for item in value)
    return False


def result_identity(item: dict[str, Any]) -> tuple[str, str, str]:
    metadata = item.get("metadata") if isinstance(item.get("metadata"), dict) else {}
    chunk_id = str(item.get("chunk_id") or metadata.get("chunk_id") or "")
    source = str(item.get("source") or metadata.get("source") or "")
    text = str(item.get("text") or item.get("snippet") or "")
    return chunk_id, source, hashlib.sha256(text.encode("utf-8")).hexdigest()


def expect_unauthorized(opener: urllib.request.OpenerDirector, url: str) -> None:
    try:
        opener.open(url, timeout=20)
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            return
        raise
    raise AssertionError(f"expected 401 from {url}")


def anonymous_session(
    base_url: str,
    *,
    allow_secure_cookie_over_loopback: bool = False,
) -> tuple[urllib.request.OpenerDirector, dict[str, Any]]:
    policy = (
        LoopbackSecureCookiePolicy()
        if allow_secure_cookie_over_loopback
        else http.cookiejar.DefaultCookiePolicy()
    )
    jar = http.cookiejar.CookieJar(policy)
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
    expect_unauthorized(opener, f"{base_url}/api/me")
    opener.open(f"{base_url}/login", timeout=20).read()
    status, payload = request_json(opener, f"{base_url}/api/me", timeout=20)
    if status != 200 or not payload.get("user", {}).get("sub", "").startswith("anon_"):
        raise AssertionError("anonymous browser identity was not established")
    cookies = list(jar)
    if len(cookies) != 1 or "HttpOnly" not in cookies[0]._rest:
        raise AssertionError("anonymous session cookie is not HttpOnly")
    return opener, payload["user"]


def parse_ui_stream(response: Any) -> tuple[str, bool]:
    parts: list[str] = []
    done = False
    for raw in response:
        line = raw.decode("utf-8", "replace").strip()
        if not line.startswith("data:"):
            continue
        event = json.loads(line.removeprefix("data:").strip())
        if event.get("delta"):
            parts.append(str(event["delta"]))
        done = done or event.get("done") is True
    return "".join(parts), done


def latest_schedule_answer_is_current(answer: str) -> bool:
    normalized = " ".join(answer.lower().replace(",", "").split())
    current_date_forms = (
        "sep 15 2026",
        "september 15 2026",
        "15 sep 2026",
        "15 september 2026",
    )
    superseded_date_forms = (
        "sep 15 2025",
        "september 15 2025",
        "15 sep 2025",
        "15 september 2025",
    )
    return any(value in normalized for value in current_date_forms) and not any(
        value in normalized for value in superseded_date_forms
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ui-base-url", default="http://127.0.0.1:23480")
    parser.add_argument("--rag-base-url", default="http://127.0.0.1:23891")
    parser.add_argument("--agent-base-url", default="http://127.0.0.1:23645")
    parser.add_argument("--agent-api-key")
    parser.add_argument("--agent-api-key-env")
    parser.add_argument("--allow-secure-cookie-over-loopback", action="store_true")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    agent_api_key = args.agent_api_key or (
        os.environ.get(args.agent_api_key_env, "") if args.agent_api_key_env else ""
    )
    if not agent_api_key:
        parser.error("--agent-api-key or --agent-api-key-env is required")
    plain = urllib.request.build_opener()

    rag_status, rag = request_json(
        plain,
        f"{args.rag_base_url}/search_chunks",
        payload={
            "query": "latest first semester add drop period course selection schedule",
            "collection": "DATASET_HKU_GB10_POC_03_LATEST_FAMILY_V1",
            "top_k": 10,
            "filters": {"is_latest": True},
        },
    )
    if rag_status != 200 or not rag.get("results"):
        raise AssertionError("RAG V2 returned no rehearsal results")
    if contains_hidden_latest(rag):
        raise AssertionError("hidden latest metadata leaked from RAG V2")
    _, rag_false = request_json(
        plain,
        f"{args.rag_base_url}/search_chunks",
        payload={
            "query": "latest first semester add drop period course selection schedule",
            "collection": "DATASET_HKU_GB10_POC_03_LATEST_FAMILY_V1",
            "top_k": 10,
            "filters": {"is_latest": False},
        },
    )
    _, rag_unfiltered = request_json(
        plain,
        f"{args.rag_base_url}/search_chunks",
        payload={
            "query": "latest first semester add drop period course selection schedule",
            "collection": "DATASET_HKU_GB10_POC_03_LATEST_FAMILY_V1",
            "top_k": 10,
        },
    )
    ordered_ids = [result_identity(item) for item in rag["results"]]
    false_ids = [result_identity(item) for item in rag_false.get("results", [])]
    unfiltered_ids = [result_identity(item) for item in rag_unfiltered.get("results", [])]
    if not false_ids or not unfiltered_ids:
        raise AssertionError("latest-filter comparison requests returned no results")
    if ordered_ids == false_ids:
        raise AssertionError("is_latest=true and is_latest=false returned identical ordered results")
    if any(contains_hidden_latest(value) for value in (rag_false, rag_unfiltered)):
        raise AssertionError("hidden latest metadata leaked from a comparison response")
    latest_chunk_ids = [identity[0] for identity in ordered_ids]
    false_chunk_ids = [identity[0] for identity in false_ids]
    if not all(latest_chunk_ids) or not all(false_chunk_ids):
        raise AssertionError("RAG response omitted chunk IDs required for Milvus verification")
    sources = [str(item.get("source", "")) for item in rag["results"]]

    expect_unauthorized(plain, f"{args.agent_base_url}/v1/models")
    agent_status, models = request_json(
        plain,
        f"{args.agent_base_url}/v1/models",
        headers={"Authorization": f"Bearer {agent_api_key}"},
        timeout=20,
    )
    if agent_status != 200 or not models.get("data"):
        raise AssertionError("agent model endpoint is unavailable")

    consistency_attempts: list[dict[str, Any]] = []
    for attempt in range(1, 6):
        result = call_stream(
            url=chat_url(args.agent_base_url),
            api_key=agent_api_key,
            model="hku-rag-agent",
            prompt=LATEST_SCHEDULE_QUESTION,
            timeout=300,
        )
        answer = str(result.pop("answer", ""))
        passed = (
            result.get("status_code") == 200
            and result.get("finish_reason") == "stop"
            and result.get("done_seen") is True
            and result.get("malformed_event_count") == 0
            and latest_schedule_answer_is_current(answer)
        )
        consistency_attempts.append(
            {
                "attempt": attempt,
                "answer_chars": len(answer),
                "answer_sha256": hashlib.sha256(answer.encode("utf-8")).hexdigest(),
                "pass": passed,
                **result,
            }
        )
    if not all(item["pass"] for item in consistency_attempts):
        raise AssertionError("latest course-selection schedule was not consistent in 5/5 runs")

    first_opener, first_user = anonymous_session(
        args.ui_base_url,
        allow_secure_cookie_over_loopback=args.allow_secure_cookie_over_loopback,
    )
    _, second_user = anonymous_session(
        args.ui_base_url,
        allow_secure_cookie_over_loopback=args.allow_secure_cookie_over_loopback,
    )
    if first_user["sub"] == second_user["sub"]:
        raise AssertionError("two browsers received the same conversation owner")

    _, thread_payload = request_json(
        first_opener,
        f"{args.ui_base_url}/api/threads",
        payload={"title": "RAG V2 rehearsal"},
        timeout=20,
    )
    thread_id = thread_payload["thread"]["id"]
    request = urllib.request.Request(
        f"{args.ui_base_url}/api/threads/{thread_id}/messages/stream",
        data=json.dumps(
            {
                "content": LATEST_SCHEDULE_QUESTION
            }
        ).encode("utf-8"),
        headers={"Content-Type": "application/json", "Accept": "text/event-stream"},
        method="POST",
    )
    with first_opener.open(request, timeout=300) as response:
        answer, done = parse_ui_stream(response)
    if not done or not answer.strip():
        raise AssertionError("UI chat did not reach a terminal response")
    if not latest_schedule_answer_is_current(answer):
        raise AssertionError("agent did not use the newer 2026-2027 schedule evidence")

    first_opener.open(f"{args.ui_base_url}/logout", timeout=20).read()
    expect_unauthorized(first_opener, f"{args.ui_base_url}/api/me")

    evidence = {
        "rag_result_count": len(rag["results"]),
        "rag_sources": sources,
        "rag_latest_chunk_ids": latest_chunk_ids,
        "rag_non_latest_chunk_ids": false_chunk_ids,
        "rag_latest_field_hidden": True,
        "rag_latest_filter_applied": True,
        "rag_unfiltered_result_count": len(unfiltered_ids),
        "agent_rejects_missing_api_key": True,
        "latest_schedule_consistency_attempts": consistency_attempts,
        "latest_schedule_consistency_pass_count": sum(
            item["pass"] for item in consistency_attempts
        ),
        "browser_subjects_are_distinct": True,
        "answer_chars": len(answer),
        "answer_sha256": hashlib.sha256(answer.encode("utf-8")).hexdigest(),
        "terminal_event_seen": done,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(evidence, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    args.output.chmod(0o600)
    print(json.dumps(evidence, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
