#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT"
COMPOSE=("$ROOT/scripts/compose_no_sso.sh" -p hku-no-sso-v3 -f compose.no-sso-rag-v2.g5680a.yml)

env_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' .env
}

wait_http() {
  local url="$1"
  local label="$2"
  for _ in $(seq 1 180); do
    if curl -fsS "$url" >/dev/null 2>&1; then
      return 0
    fi
    sleep 2
  done
  echo "$label did not become ready: $url" >&2
  return 1
}

wait_milvus() {
  local address="$1"
  local port="$2"
  for _ in $(seq 1 180); do
    if curl -fsS \
      -H 'Authorization: Bearer root:Milvus' \
      -H 'Content-Type: application/json' \
      -d '{"dbName":"default"}' \
      "http://${address}:${port}/v2/vectordb/collections/list" >/dev/null 2>&1; then
      return 0
    fi
    sleep 2
  done
  echo "vector store did not become ready at $address:$port" >&2
  return 1
}

python3 scripts/no_sso_target_config.py check --env .env
"${COMPOSE[@]}" config >/dev/null
python3 scripts/no_sso_target_control.py --root "$ROOT" --env "$ROOT/.env" \
  capture --output evidence/control-before-ordered-restart.json

"${COMPOSE[@]}" restart vector-coordinator
"${COMPOSE[@]}" restart vector-object
"${COMPOSE[@]}" restart vector-engine
python3 scripts/no_sso_target_control.py --root "$ROOT" --env "$ROOT/.env" \
  sync-vector-addresses
wait_http "http://$(env_value NO_SSO_VECTOR_COORDINATOR_ADDRESS):2379/health" "vector coordinator"
wait_http "http://$(env_value NO_SSO_VECTOR_OBJECT_ADDRESS):9000/minio/health/live" "object store"
wait_milvus "$(env_value NO_SSO_VECTOR_ENGINE_ADDRESS)" 19530

"${COMPOSE[@]}" restart rag-api
wait_http "http://127.0.0.1:$(env_value NO_SSO_RAG_HOST_PORT)/health" "search API"
"${COMPOSE[@]}" restart agent-runtime
wait_http "http://127.0.0.1:$(env_value NO_SSO_AGENT_HOST_PORT)/health" "agent runtime"
"${COMPOSE[@]}" restart web-ui
wait_http "http://127.0.0.1:$(env_value NO_SSO_UI_HOST_PORT)/healthz" "application UI"
"${COMPOSE[@]}" restart entrypoint

./CheckNoSSOG5680A.sh
python3 scripts/no_sso_target_control.py --root "$ROOT" --env "$ROOT/.env" \
  compare --before evidence/control-before-ordered-restart.json

echo "Ordered isolated-lane restart passed."
