#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT"
[[ -f .env ]] || { echo "Missing .env" >&2; exit 1; }

env_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' .env
}

pull_image() {
  image="$1"
  attempt=1
  while ! docker pull "$image"; do
    if [[ "$attempt" -ge 5 ]]; then
      echo "Image pull failed after $attempt attempts." >&2
      return 1
    fi
    sleep_seconds=$((attempt * 5))
    echo "Image pull attempt $attempt failed; retrying in ${sleep_seconds}s." >&2
    sleep "$sleep_seconds"
    attempt=$((attempt + 1))
  done
}

for key in \
  NO_SSO_PROXY_IMAGE \
  NO_SSO_UI_IMAGE \
  NO_SSO_AGENT_IMAGE \
  NO_SSO_RAG_IMAGE \
  NO_SSO_VECTOR_SEED_IMAGE \
  NO_SSO_ETCD_IMAGE \
  NO_SSO_MINIO_IMAGE \
  NO_SSO_MILVUS_IMAGE; do
  image="$(env_value "$key")"
  [[ -n "$image" ]] || { echo "Missing image reference: $key" >&2; exit 1; }
  pull_image "$image"
done

"$ROOT/scripts/compose_no_sso.sh" -p hku-no-sso-v3 -f compose.no-sso-rag-v2.g5680a.yml config >/dev/null
echo "Pulled the isolated lane images without starting containers."
