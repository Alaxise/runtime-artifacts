#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT"

export NO_SSO_AGENT_API_KEY="$(awk -F= '$1 == "NO_SSO_AGENT_API_KEY" {sub(/^[^=]*=/, ""); print; exit}' .env)"
agent_port="$(awk -F= '$1 == "NO_SSO_AGENT_HOST_PORT" {print $2; exit}' .env)"

python3 tests/e2e_agent_stream_regression.py \
  --base-url "http://127.0.0.1:${agent_port}" \
  --api-key-env NO_SSO_AGENT_API_KEY \
  --output evidence/no-sso-target-six-case-stream.json
