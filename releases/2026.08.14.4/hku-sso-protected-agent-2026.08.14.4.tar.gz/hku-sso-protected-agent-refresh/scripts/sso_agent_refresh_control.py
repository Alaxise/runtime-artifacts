#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


PROJECT = "hku-sso-v4"
TARGET_ROOT = Path("/model/dockervolume/hku-custom-sso-v4")
AGENT = "hku-sso-v4-agent"
PRESERVED = (
    "hku-sso-v4-entrypoint",
    "hku-sso-v4-gateway",
    "hku-sso-v4-session",
    "hku-sso-v4-ui",
    "hku-sso-v4-search",
    "hku-sso-v4-coordinator",
    "hku-sso-v4-object",
    "hku-sso-v4-vector",
)
CONTRACT_KEYS = {
    "REFRESH_RELEASE_ID",
    "REFRESH_PARENT_RELEASE",
    "REFRESH_CANDIDATE_AGENT_IMAGE",
    "REFRESH_CANDIDATE_AGENT_IMAGE_ID",
    "REFRESH_EXPECTED_SOURCE_REVISION",
    "REFRESH_EXPECTED_BEHAVIOR_REVISION",
    "REFRESH_EXPECTED_PROMPT_SHA256",
    "REFRESH_EXPECTED_TIMETABLE_SHA256",
    "REFRESH_EXPECTED_TIMETABLE_ROWS",
}


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def run(*command: str, check: bool = True) -> str:
    result = subprocess.run(command, check=False, capture_output=True, text=True)
    if check and result.returncode != 0:
        fail(result.stderr.strip() or result.stdout.strip() or "command failed")
    return result.stdout


def read_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        key, separator, value = line.partition("=")
        if not separator or key in values:
            fail(f"invalid environment entry at {path}:{number}")
        values[key] = value
    return values


def inspect(name: str) -> dict[str, Any]:
    payload = json.loads(run("docker", "inspect", name))
    if not isinstance(payload, list) or len(payload) != 1:
        fail(f"container is unavailable: {name}")
    return payload[0]


def normalized(name: str) -> dict[str, Any]:
    item = inspect(name)
    state = item.get("State") or {}
    config = item.get("Config") or {}
    host = item.get("HostConfig") or {}
    return {
        "container_id": item.get("Id", ""),
        "image_id": item.get("Image", ""),
        "state": state.get("Status", ""),
        "health": (state.get("Health") or {}).get("Status", "none"),
        "started_at": state.get("StartedAt", ""),
        "restart_count": item.get("RestartCount", 0),
        "project": (config.get("Labels") or {}).get("com.docker.compose.project", ""),
        "network_mode": host.get("NetworkMode", ""),
        "pid_mode": host.get("PidMode", ""),
        "port_bindings": host.get("PortBindings") or {},
        "mounts": sorted(
            (
                {
                    "source": mount.get("Source", ""),
                    "destination": mount.get("Destination", ""),
                    "read_write": bool(mount.get("RW")),
                }
                for mount in item.get("Mounts") or []
            ),
            key=lambda value: (value["destination"], value["source"]),
        ),
        "environment_sha256": hashlib.sha256(
            "\0".join(sorted(config.get("Env") or [])).encode("utf-8")
        ).hexdigest(),
    }


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as stream:
        json.dump(payload, stream, indent=2, sort_keys=True)
        stream.write("\n")
        temporary = Path(stream.name)
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)


def capture(output: Path) -> None:
    payload = {
        "schema_version": 1,
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "agent": normalized(AGENT),
        "preserved": {name: normalized(name) for name in PRESERVED},
    }
    for name, item in {AGENT: payload["agent"], **payload["preserved"]}.items():
        if item["project"] != PROJECT or item["state"] != "running":
            fail(f"deployment inventory is not stable: {name}")
    atomic_json(output, payload)
    print(f"agent-refresh snapshot written: {output}")


def make_candidate(live: Path, contract: Path, output: Path) -> None:
    live_values = read_env(live)
    contract_values = read_env(contract)
    if set(contract_values) != CONTRACT_KEYS:
        fail("candidate metadata key set changed")
    image = contract_values["REFRESH_CANDIDATE_AGENT_IMAGE"]
    if "@sha256:" not in image:
        fail("candidate agent image is not digest-pinned")
    if "NO_SSO_AGENT_IMAGE" not in live_values:
        fail("live agent image setting is missing")
    live_values["NO_SSO_AGENT_IMAGE"] = image
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=output.parent, delete=False) as stream:
        for key, value in live_values.items():
            stream.write(f"{key}={value}\n")
        temporary = Path(stream.name)
    os.chmod(temporary, 0o600)
    os.replace(temporary, output)
    print(f"candidate environment written: {output}")


def validate_parent(snapshot: Path, live_env: Path) -> None:
    before = json.loads(snapshot.read_text(encoding="utf-8"))["agent"]
    live_values = read_env(live_env)
    reference = live_values.get("NO_SSO_AGENT_IMAGE", "")
    if not reference:
        fail("live agent image setting is missing")
    expected_image_id = run("docker", "image", "inspect", reference, "--format", "{{.Id}}").strip()
    if before["image_id"] != expected_image_id:
        fail("running parent agent does not match the live image contract")
    required = {
        "DEEPSEEK_MODEL=deepseek-v4-flash",
        "DEEPSEEK_JUDGE_MODEL=deepseek-v4-flash",
        "HKU_COURSE_SEARCH_COLLECTION=DATASET_HKU_GB10_POC_05",
        "HKU_AGENT_MODEL_MAX_TOKENS=4096",
        "HKU_AGENT_CONTEXT_FILE_MAX_CHARS=65536",
        "HKU_AGENT_DASHBOARD_ENABLED=false",
        "HKU_GROUNDED_JUDGE_TIMEOUT_SECONDS=8",
        "HKU_GROUNDED_JUDGE_MAX_TOKENS=2048",
        "HKU_GROUNDED_REPAIR_TIMEOUT_SECONDS=6",
        "HKU_GROUNDED_REPAIR_MAX_TOKENS=4096",
        "HKU_COURSE_SEARCH_RETRIEVAL_EVALUATOR_TIMEOUT_SECONDS=4",
        "HKU_COURSE_SEARCH_QUALIFIED_ROUTING=true",
        "HKU_COURSE_SEARCH_ANSWER_HINTS=false",
        "LOG_LEVEL=WARNING",
        "HKU_AGENT_LOG_LEVEL=WARNING",
    }
    running_environment = set((inspect(AGENT).get("Config") or {}).get("Env") or [])
    missing = sorted(required - running_environment)
    if missing:
        fail("running parent agent contract drifted: " + ", ".join(missing))
    print("running agent matches the parent release contract")


def compare_preserved(snapshot: Path) -> None:
    before = json.loads(snapshot.read_text(encoding="utf-8"))
    errors = []
    for name, expected in before["preserved"].items():
        actual = normalized(name)
        if actual != expected:
            errors.append(name)
    if errors:
        fail("preserved containers changed: " + ", ".join(errors))
    print("all non-agent SSO containers are unchanged")


def verify_agent_restored(snapshot: Path) -> None:
    before = json.loads(snapshot.read_text(encoding="utf-8"))["agent"]
    after = normalized(AGENT)
    for key in (
        "image_id",
        "network_mode",
        "pid_mode",
        "port_bindings",
        "mounts",
        "environment_sha256",
    ):
        if after[key] != before[key]:
            fail(f"rollback did not restore prior agent {key}")
    if after["state"] != "running" or after["health"] not in {"healthy", "none"}:
        fail("restored agent is not ready")
    print("prior agent image and runtime contract restored")


def main() -> None:
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)
    capture_parser = commands.add_parser("capture")
    capture_parser.add_argument("--output", type=Path, required=True)
    candidate = commands.add_parser("make-candidate")
    candidate.add_argument("--live", type=Path, required=True)
    candidate.add_argument("--contract", type=Path, required=True)
    candidate.add_argument("--output", type=Path, required=True)
    parent = commands.add_parser("validate-parent")
    parent.add_argument("--snapshot", type=Path, required=True)
    parent.add_argument("--live-env", type=Path, required=True)
    compare = commands.add_parser("compare-preserved")
    compare.add_argument("--snapshot", type=Path, required=True)
    restored = commands.add_parser("verify-agent-restored")
    restored.add_argument("--snapshot", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "capture":
        capture(args.output)
    elif args.command == "make-candidate":
        make_candidate(args.live, args.contract, args.output)
    elif args.command == "validate-parent":
        validate_parent(args.snapshot, args.live_env)
    elif args.command == "compare-preserved":
        compare_preserved(args.snapshot)
    else:
        verify_agent_restored(args.snapshot)


if __name__ == "__main__":
    main()
