# Protected authenticated agent refresh

This package replaces only the application agent in the existing authenticated
`hku-sso-v4` lane. It does not recreate the entrypoint, authentication gateway,
session store, UI, search API, vector services, or persistent data.

## Release identity

- Release: `hku-sso-protected-agent-g5680a-2026.08.14.4`
- Supersedes: `.1`, `.2`, and `.3` (CI scope/tooling corrections; do not deploy)
- Parent: `hku-sso-poc05-g5680a-2026.08.03.3`
- Target root: `/model/dockervolume/hku-custom-sso-v4`
- Compose project: `hku-sso-v4`
- Mutation boundary: `hku-sso-v4-agent`
- Qualified non-SSO rehearsal: port `28480` on GB10

The protected image is a digest-pinned Linux ARM64 artifact built with a
renamed application package, PyInstaller, a multi-stage container build,
application-source removal, and no dashboard.

## Deployment procedure

1. Read the local deployment playbook in full and perform a fresh read-only
   inventory with the user.
2. Confirm the target root, Compose project, live parent release, container
   identities, image references, mounts, listeners, and control lanes match
   the package contract.
3. Extract this archive outside the target root.
4. Run `./ApplySsoProtectedAgentRefresh.sh` from the extracted package.
5. Complete one real HKU pilot login, accept Terms if prompted, submit a
   timetable question and a curriculum question, inspect citations, and log
   out.

The apply script captures rollback state before changing the live environment,
pulls and verifies the approved image, recreates only `agent-runtime`, runs the
protected release checks and behavioral controls, and rolls back automatically
if any check fails.

## Rollback

Run:

```bash
./RollbackSsoProtectedAgentRefresh.sh \
  /model/dockervolume/hku-custom-sso-v4/updates/<update-id>
```

Rollback restores the prior environment, parent runtime override, and agent
image, then verifies that every preserved container stayed unchanged.

## Deliberate exclusions

This is not an accuracy-tuning release. It does not change the UI, SSO
configuration, search service, POC05 collection, embedding endpoint, reranker,
vector data, or scaling topology. Local playbooks, lane registries, live
configuration, secrets, and generated archives are not included in the target
archive.
