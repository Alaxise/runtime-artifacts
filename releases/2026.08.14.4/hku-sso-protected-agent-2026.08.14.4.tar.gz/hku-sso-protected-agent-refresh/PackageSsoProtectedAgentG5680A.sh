#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

version="2026.08.14.4"
if [[ "$#" -gt 0 && "$1" != "$version" ]]; then
  echo "ERROR: This packager is locked to release $version." >&2
  exit 1
fi
release_tag="hku-sso-protected-agent-g5680a-2026.08.14.4"
archive="hku-sso-protected-agent-${version}.tar.gz"
release_dir="$ROOT/release"

[[ -z "$(git status --porcelain)" ]] \
  || { echo "ERROR: Refusing to package a dirty worktree." >&2; exit 1; }
[[ "$(git rev-parse HEAD)" == "$(git rev-parse "${release_tag}^{commit}")" ]] \
  || { echo "ERROR: HEAD must be the exact $release_tag release commit." >&2; exit 1; }
python3 scripts/verify_sso_protected_agent_release.py --root "$ROOT"

files=(
  .env.g5680a.sso-protected-agent.example
  ApplySsoProtectedAgentRefresh.sh
  CheckSsoProtectedAgentRefresh.sh
  DEPLOY_G5680A_SSO_PROTECTED_AGENT.md
  PackageSsoProtectedAgentG5680A.sh
  RollbackSsoProtectedAgentRefresh.sh
  THIRD_PARTY_NOTICES_SSO_PROTECTED_AGENT.md
  compose.sso-parent-agent.override.yml
  compose.sso-protected-agent.override.yml
  g5680a-sso-protected-agent-components.lock.json
  image-list.sso-protected-agent.g5680a.txt
  scripts/compose_no_sso.sh
  scripts/sso_agent_refresh_control.py
  scripts/sso_poc04_target.py
  scripts/verify_sso_protected_agent_release.py
  tests/e2e_sso_protected_agent.py
)

mkdir -p "$release_dir"
git archive --format=tar --prefix=hku-sso-protected-agent-refresh/ "$release_tag" -- "${files[@]}" \
  | gzip -n -9 > "$release_dir/$archive"

if command -v sha256sum >/dev/null 2>&1; then
  (cd "$release_dir" && sha256sum "$archive" > "$archive.sha256")
else
  digest="$(shasum -a 256 "$release_dir/$archive" | awk '{print $1}')"
  printf '%s  %s\n' "$digest" "$archive" > "$release_dir/$archive.sha256"
fi

echo "$release_dir/$archive"
echo "$release_dir/$archive.sha256"
