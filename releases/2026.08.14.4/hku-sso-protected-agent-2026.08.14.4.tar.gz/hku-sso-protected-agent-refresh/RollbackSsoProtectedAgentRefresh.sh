#!/usr/bin/env bash
set -euo pipefail

PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET_ROOT="/model/dockervolume/hku-custom-sso-v4"
PROJECT="hku-sso-v4"
BASE_COMPOSE="$TARGET_ROOT/compose.sso-poc04.g5680a.yml"
PARENT_OVERRIDE="$PACKAGE_ROOT/compose.sso-parent-agent.override.yml"
UPDATE_DIR="${1:-}"

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

wait_healthy() {
  local state=""
  for _ in $(seq 1 90); do
    state="$(docker inspect hku-sso-v4-agent --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' 2>/dev/null || true)"
    [[ "$state" == "healthy" ]] && return 0
    sleep 2
  done
  fail "restored agent did not become healthy"
}

[[ -n "$UPDATE_DIR" ]] || fail "usage: $0 /model/dockervolume/hku-custom-sso-v4/updates/<update>"
case "$(cd "$UPDATE_DIR" 2>/dev/null && pwd -P || true)" in
  "$TARGET_ROOT"/updates/*) ;;
  *) fail "rollback evidence directory is outside the authorized target root" ;;
esac
for file in before.env compose.before.yml agent-refresh-before.json; do
  [[ -f "$UPDATE_DIR/$file" ]] || fail "rollback evidence is missing: $file"
done
cmp -s "$UPDATE_DIR/compose.before.yml" "$BASE_COMPOSE" || fail "live base Compose file drifted"

temporary="$(mktemp "$TARGET_ROOT/.env.rollback.XXXXXX")"
cp "$UPDATE_DIR/before.env" "$temporary"
chmod 600 "$temporary"
mv "$temporary" "$TARGET_ROOT/.env"

COMPOSE=(
  "$PACKAGE_ROOT/scripts/compose_no_sso.sh"
  -p "$PROJECT"
  -f "$BASE_COMPOSE"
  -f "$PARENT_OVERRIDE"
)
cd "$TARGET_ROOT"
"${COMPOSE[@]}" config >/dev/null
"${COMPOSE[@]}" up -d --no-deps agent-runtime
wait_healthy

python3 "$PACKAGE_ROOT/scripts/sso_agent_refresh_control.py" \
  compare-preserved --snapshot "$UPDATE_DIR/agent-refresh-before.json"
python3 "$PACKAGE_ROOT/scripts/sso_agent_refresh_control.py" \
  verify-agent-restored --snapshot "$UPDATE_DIR/agent-refresh-before.json"
if [[ -f "$UPDATE_DIR/control-before.json" ]]; then
  python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" \
    --root "$TARGET_ROOT" --env "$UPDATE_DIR/before.env" \
    compare --before "$UPDATE_DIR/control-before.json"
fi
python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" \
  --root "$TARGET_ROOT" --env "$TARGET_ROOT/.env" verify-target
echo "Prior authenticated agent image and runtime contract restored."
