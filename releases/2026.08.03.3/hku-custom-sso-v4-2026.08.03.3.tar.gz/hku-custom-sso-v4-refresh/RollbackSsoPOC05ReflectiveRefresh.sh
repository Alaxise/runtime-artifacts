#!/usr/bin/env bash
set -euo pipefail

PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET_ROOT="/model/dockervolume/hku-custom-sso-v4"
PROJECT="hku-sso-v4"
BASE_COMPOSE="$TARGET_ROOT/compose.sso-poc04.g5680a.yml"
UPDATE_DIR="${1:-}"

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

wait_health() {
  local container="$1"
  local state
  for _ in $(seq 1 90); do
    state="$(docker inspect "$container" --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' 2>/dev/null || true)"
    [[ "$state" == "healthy" || "$state" == "running" ]] && return 0
    sleep 2
  done
  fail "$container did not become ready during rollback"
}

[[ -n "$UPDATE_DIR" ]] || fail "usage: $0 /model/dockervolume/hku-custom-sso-v4/updates/<update>"
case "$(cd "$UPDATE_DIR" 2>/dev/null && pwd -P || true)" in
  "$TARGET_ROOT"/updates/*) ;;
  *) fail "rollback evidence directory is outside the authorized target root" ;;
esac
[[ -f "$UPDATE_DIR/before.env" ]] || fail "rollback environment is missing"
[[ -f "$UPDATE_DIR/compose.before.yml" ]] || fail "rollback Compose file is missing"
[[ -f "$UPDATE_DIR/preserved-before.json" ]] || fail "rollback snapshot is missing"
[[ -f "$BASE_COMPOSE" ]] || fail "live base Compose file is missing"
cmp -s "$UPDATE_DIR/compose.before.yml" "$BASE_COMPOSE" \
  || fail "live base Compose file drifted after the rollback snapshot"

temporary="$(mktemp "$TARGET_ROOT/.env.rollback.XXXXXX")"
cp "$UPDATE_DIR/before.env" "$temporary"
chmod 600 "$temporary"
mv "$temporary" "$TARGET_ROOT/.env"

COMPOSE=(
  "$PACKAGE_ROOT/scripts/compose_no_sso.sh"
  -p "$PROJECT"
  -f "$BASE_COMPOSE"
)
cd "$TARGET_ROOT"
"${COMPOSE[@]}" config >/dev/null
"${COMPOSE[@]}" up -d --no-deps rag-api
wait_health hku-sso-v4-search
"${COMPOSE[@]}" up -d --no-deps agent-runtime
wait_health hku-sso-v4-agent
"${COMPOSE[@]}" up -d --no-deps web-ui
wait_health hku-sso-v4-ui

python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" compare-preserved \
  --before "$UPDATE_DIR/preserved-before.json"
if [[ -f "$UPDATE_DIR/control-before.json" ]]; then
  python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" \
    --root "$TARGET_ROOT" \
    --env "$PACKAGE_ROOT/.env.g5680a.sso-poc05-refresh.example" \
    compare \
    --before "$UPDATE_DIR/control-before.json"
fi

python3 - "$UPDATE_DIR/preserved-before.json" <<'PY'
import json
import subprocess
import sys

before = json.load(open(sys.argv[1], encoding="utf-8"))["applications"]
for name, expected in before.items():
    actual = subprocess.check_output(
        ["docker", "inspect", name, "--format", "{{.Image}}"], text=True
    ).strip()
    if actual != expected["image_id"]:
        raise SystemExit(f"rollback image mismatch: {name}")
PY

echo "Prior authenticated application images and configuration restored. POC05 data remains dormant for evidence and is not deleted."
