#!/usr/bin/env bash
set -euo pipefail

PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET_ROOT="/model/dockervolume/hku-custom-sso-v4"
UPDATE_DIR="${1:-}"

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

env_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' "$TARGET_ROOT/.env"
}

milvus_count() {
  local filter="$1"
  local response
  response="$(curl -fsS \
    -H 'Authorization: Bearer root:Milvus' \
    -H 'Content-Type: application/json' \
    -d "{\"dbName\":\"default\",\"collectionName\":\"$(env_value NO_SSO_COLLECTION)\",\"filter\":\"$filter\",\"outputFields\":[\"count(*)\"]}" \
    "http://$(env_value NO_SSO_VECTOR_ENGINE_ADDRESS):19530/v2/vectordb/entities/query")"
  python3 - "$response" <<'PY'
import json
import sys
payload = json.loads(sys.argv[1])
if int(payload.get("code", -1)) != 0:
    raise SystemExit(payload.get("message", "vector count failed"))
print(int(payload["data"][0]["count(*)"]))
PY
}

[[ -n "$UPDATE_DIR" && -f "$UPDATE_DIR/preserved-before.json" ]] || fail "selective-refresh snapshot is missing"
python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" \
  --root "$TARGET_ROOT" \
  --env "$TARGET_ROOT/.env" \
  check-config
python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" \
  --root "$TARGET_ROOT" \
  --env "$TARGET_ROOT/.env" \
  verify-target
python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" compare-preserved \
  --before "$UPDATE_DIR/preserved-before.json"
python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" \
  --root "$TARGET_ROOT" \
  --env "$TARGET_ROOT/.env" \
  compare \
  --before "$UPDATE_DIR/control-before.json"

agent_env="$(docker inspect hku-sso-v4-agent --format '{{range .Config.Env}}{{println .}}{{end}}')"
for setting in \
  'DEEPSEEK_MODEL=deepseek-v4-flash' \
  'DEEPSEEK_JUDGE_MODEL=deepseek-v4-flash' \
  'HKU_COURSE_SEARCH_COLLECTION=DATASET_HKU_GB10_POC_05' \
  'HKU_AGENT_MODEL_MAX_TOKENS=4096' \
  'HKU_AGENT_CONTEXT_FILE_MAX_CHARS=65536' \
  'HKU_GROUNDED_JUDGE_TIMEOUT_SECONDS=8' \
  'HKU_GROUNDED_REPAIR_TIMEOUT_SECONDS=6' \
  'HKU_COURSE_SEARCH_RETRIEVAL_EVALUATOR_TIMEOUT_SECONDS=4' \
  'HKU_COURSE_SEARCH_QUALIFIED_ROUTING=true' \
  'HKU_COURSE_SEARCH_ANSWER_HINTS=false'; do
  grep -Fqx "$setting" <<<"$agent_env" || fail "agent runtime setting changed: $setting"
done

ui_env="$(docker inspect hku-sso-v4-ui --format '{{range .Config.Env}}{{println .}}{{end}}')"
grep -Fqx 'FORWARDED_ALLOW_IPS=' <<<"$ui_env" || fail "SSO transport-source correction is missing"
grep -Fqx 'HKU_UI_ALLOWED_EMAIL_DOMAINS=hku.hk,connect.hku.hk' <<<"$ui_env" \
  || fail "staff/student email-domain contract changed"

rag_env="$(docker inspect hku-sso-v4-search --format '{{range .Config.Env}}{{println .}}{{end}}')"
for setting in \
  'MILVUS_COLLECTION=DATASET_HKU_GB10_POC_05' \
  'HKU_DEFAULT_COLLECTION=DATASET_HKU_GB10_POC_05' \
  'RAG_MAX_CONCURRENCY=4' \
  'RAG_MAX_QUEUE=8' \
  'RAG_QUEUE_TIMEOUT_SECONDS=2' \
  'RAG_DEFAULT_SPARSE_WEIGHT=0.6' \
  'RAG_DEFAULT_DENSE_WEIGHT=0.4'; do
  grep -Fqx "$setting" <<<"$rag_env" || fail "search runtime setting changed: $setting"
done

[[ "$(milvus_count 'chunk_id != \"\"')" == "18675" ]] || fail "POC05 total row count changed"
[[ "$(milvus_count 'is_latest == true')" == "6870" ]] || fail "POC05 latest row count changed"
[[ "$(milvus_count 'is_latest == false')" == "11805" ]] || fail "POC05 historical row count changed"

[[ "$(docker inspect hku-sso-v4-ui --format '{{.Image}}')" == "sha256:e5ad547531638f4f4142a63a0e9733e649c6f5ee8552c610de7f9d2586afdffe" ]] \
  || fail "UI image differs from the approved SSO rehearsal"
[[ "$(docker inspect hku-sso-v4-agent --format '{{.Image}}')" == "sha256:0f0bd7e24193645507954c34062e92b4f67827476e26f3ff9889767a3d6c41c6" ]] \
  || fail "agent image differs from the approved SSO rehearsal"
[[ "$(docker inspect hku-sso-v4-search --format '{{.Image}}')" == "sha256:998e45fd37a08bfeac88064ace436296695801323792fbb92ab127d69d27c825" ]] \
  || fail "search image differs from the approved SSO rehearsal"

prompt="$(docker exec hku-sso-v4-agent sha256sum /opt/hku-runtime/.hku_agent/profiles/hku-chatbot-no-sso-rag-v2/SOUL.md | awk '{print $1}')"
[[ "$prompt" == "8f5f554806d7ac618a43803f6cd0c64a51aafae69e0b58e747c6b370ef9824e4" ]] \
  || fail "embedded prompt differs from the approved SSO rehearsal"

docker exec hku-sso-v4-agent sh -ec 'test -z "$(find /opt/hku-runtime/bin -type f \( -name "*.py" -o -name "*.pyc" \) -print -quit)"' \
  || fail "agent source is present"
docker exec hku-sso-v4-search sh -ec 'test -z "$(find /opt/hku-search/runtime -type f \( -name "*.py" -o -name "*.pyc" \) -print -quit)"' \
  || fail "search source is present"

echo "Authenticated POC05 reflective refresh verification passed."
