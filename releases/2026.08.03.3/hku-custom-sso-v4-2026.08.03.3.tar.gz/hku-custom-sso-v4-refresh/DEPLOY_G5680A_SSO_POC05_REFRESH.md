# Authenticated POC05 Selective Refresh

## Release Boundary

This package updates the existing authenticated lane at:

- target root: `/model/dockervolume/hku-custom-sso-v4`
- Compose project: `hku-sso-v4`
- backend port: `28380`, already routed by the existing public `443` entrypoint

It may recreate only:

- `hku-sso-v4-search`
- `hku-sso-v4-agent`
- `hku-sso-v4-ui`

It must preserve the entrypoint, authentication gateway, session store,
coordinator, object store, vector engine, persistent mounts, secrets, and all
unrelated lanes. Port `18380` is an untouchable control.

## Candidate

- release: `hku-sso-poc05-g5680a-2026.08.03.3`
- collection: `DATASET_HKU_GB10_POC_05`
- rows: `18,675` (`6,870` latest and `11,805` historical)
- absolute response deadline: `60` seconds
- generator and judge model selector: `deepseek-v4-flash`
- SSO transport-source setting: `FORWARDED_ALLOW_IPS` is empty

The UI, agent, search, and vector seed images are immutable Linux ARM64
artifacts recorded in `g5680a-sso-poc04-components.lock.json`.

Release `.3` supersedes `.2`. It binds each verified digest-pinned image to
the exact local tag consumed by Docker Compose v1 before any service is
recreated. This prevents Compose v1 from reusing a stale tagged image when a
`tag@digest` pull stores only the digest alias.

## Mandatory Preflight

Before mutation, read the local g5680a deployment playbook and compare it with
a fresh read-only Guacamole inventory. Resolve every drift in container names,
ports, paths, images, mounts, listeners, or rollback boundaries first.

Extract the verified archive beneath a new timestamped directory under:

`/model/dockervolume/hku-custom-sso-v4/updates`

Do not extract it over the live Compose files. Verify the archive SHA-256,
manifest, image architecture, image IDs, available disk space, lane ownership,
control health, and shared embedding/reranking health before applying it.

## Apply

From the extracted package directory, run:

```bash
./ApplySsoPOC05ReflectiveRefresh.sh
```

The script snapshots the live environment, live base Compose file, application
persistence boundaries, all preserved container identities, and control
listeners before it changes the environment. It stages and restores POC05
additively, then recreates search, agent, and UI in that order. Any failed gate
automatically invokes rollback.

## Rollback

The apply command prints its evidence directory. To restore the prior POC04
application images and configuration, run:

```bash
./RollbackSsoPOC05ReflectiveRefresh.sh \
  /model/dockervolume/hku-custom-sso-v4/updates/<update-id>
```

Rollback recreates only search, agent, and UI using the preserved environment
and Compose snapshot. It does not delete POC05, persistent data, evidence, or
containers.

## Acceptance

After local verification, complete one real HKU pilot login, accept the Terms,
submit one authenticated chat request, inspect the complete response and
citations, verify history, and log out through
`https://curr-planner.hku.hk`. Keep the previous image references and update
directory until acceptance is complete.
