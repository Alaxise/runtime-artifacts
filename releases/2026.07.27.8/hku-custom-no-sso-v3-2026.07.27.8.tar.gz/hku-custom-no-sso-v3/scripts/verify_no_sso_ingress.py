#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import http.client
import json
import socket
from pathlib import Path
from typing import Any


HTML_CSP = (
    "default-src 'self'; script-src 'self'; style-src 'self'; "
    "img-src 'self' data:; connect-src 'self'; object-src 'none'; "
    "base-uri 'self'; form-action 'self'; frame-ancestors 'none'"
)
API_CSP = (
    "default-src 'none'; base-uri 'none'; form-action 'none'; "
    "frame-ancestors 'none'"
)
PLUGIN_DISPOSITIONS = {
    "115174": {
        "owner": "application",
        "status": "locally-remediated",
        "proof": "entrypoint runtime reports nginx/1.30.4",
    },
    "115243": {
        "owner": "application",
        "status": "locally-remediated",
        "proof": "qualified nginx upgrade and SSE-only response buffering exception",
    },
    "115255": {
        "owner": "application",
        "status": "locally-remediated",
        "proof": "qualified nginx upgrade and exact-image configuration test",
    },
    "115285": {
        "owner": "application",
        "status": "locally-remediated",
        "proof": "qualified nginx upgrade with HTTP/3 and proxy-v2 unused",
    },
    "115314": {
        "owner": "application",
        "status": "locally-remediated",
        "proof": "authority maps validated only after the nginx upgrade",
    },
    "115141": {
        "owner": "application",
        "status": "locally-remediated",
        "proof": "qualified nginx upgrade; application upstream remains loopback HTTP",
    },
    "114954": {
        "owner": "application",
        "status": "locally-remediated",
        "proof": "qualified nginx upgrade; no mail listener is configured",
    },
    "114006": {
        "owner": "shared",
        "status": "requires-public-rescan",
        "proof": "exact authority gate and malicious-then-clean cache sequence pass locally",
    },
    "114223": {
        "owner": "shared",
        "status": "requires-public-rescan",
        "proof": "CL.TE, TE.CL, duplicate length, and malformed chunks reject locally",
    },
    "115010": {
        "owner": "application",
        "status": "locally-remediated",
        "proof": "all API query strings receive one sanitized deterministic response",
    },
    "98096": {
        "owner": "shared",
        "status": "requires-public-rescan",
        "proof": "localhost, arbitrary authorities, and wrong ports reject locally",
    },
    "98095": {
        "owner": "shared",
        "status": "requires-public-rescan",
        "proof": "only GET and POST are accepted by the application entrypoint",
    },
    "98060": {
        "owner": "application",
        "status": "locally-remediated",
        "proof": "X-Frame-Options is present on normal, redirect, and error responses",
    },
    "112529": {
        "owner": "application",
        "status": "locally-remediated",
        "proof": "X-Content-Type-Options is present on all tested route categories",
    },
    "112554": {
        "owner": "application",
        "status": "locally-remediated",
        "proof": "separate strict HTML and API policies pass route checks",
    },
    "114796": {
        "owner": "shared",
        "status": "accepted-low-risk",
        "proof": "strict CSP is active; no unmonitored collector is fabricated",
    },
    "112539": {
        "owner": "shared",
        "status": "requires-public-rescan",
        "proof": "TLS terminates at the HKU-managed public proxy, outside port 20380",
    },
}

SENSITIVE_MARKERS = (
    b"sqlite",
    b"operationalerror",
    b"traceback",
    b"select * from",
    b"insert into",
    b"update threads",
    b"127.0.0.1:20",
    b"169.254.169.254",
    b"/model/dockervolume",
)


def sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def header_values(headers: list[tuple[str, str]]) -> dict[str, list[str]]:
    result: dict[str, list[str]] = {}
    for name, value in headers:
        result.setdefault(name.casefold(), []).append(value)
    return result


def http_request(
    connect_host: str,
    port: int,
    authority: str,
    method: str,
    path: str,
    *,
    body: bytes | None = None,
    headers: dict[str, str] | None = None,
    timeout: float = 20,
) -> dict[str, Any]:
    connection = http.client.HTTPConnection(connect_host, port, timeout=timeout)
    try:
        connection.putrequest(method, path, skip_host=True, skip_accept_encoding=True)
        connection.putheader("Host", authority)
        for name, value in (headers or {}).items():
            connection.putheader(name, value)
        if body is not None and not any(
            name.casefold() == "content-length" for name in (headers or {})
        ):
            connection.putheader("Content-Length", str(len(body)))
        connection.endheaders(body)
        response = connection.getresponse()
        payload = response.read(2 * 1024 * 1024)
        return {
            "status": response.status,
            "headers": header_values(response.getheaders()),
            "body": payload,
            "body_sha256": sha256(payload),
            "body_bytes": len(payload),
        }
    finally:
        connection.close()


def parse_status(response: bytes) -> int:
    if not response:
        return 0
    first_line = response.split(b"\r\n", 1)[0]
    fields = first_line.split()
    if len(fields) < 2 or not fields[0].startswith(b"HTTP/"):
        raise ValueError("invalid HTTP status line")
    try:
        return int(fields[1])
    except ValueError as exc:
        raise ValueError("invalid HTTP status line") from exc


def raw_framing_cases(authority: str) -> dict[str, bytes]:
    prefix = b"POST /api/me HTTP/1.1\r\nHost: " + authority.encode("ascii") + b"\r\n"
    return {
        "cl_te": (
            prefix
            + b"Content-Length: 4\r\n"
            + b"Transfer-Encoding: chunked\r\n"
            + b"Connection: close\r\n\r\n"
            + b"0\r\n\r\nX"
        ),
        "te_cl": (
            prefix
            + b"Transfer-Encoding: chunked\r\n"
            + b"Content-Length: 4\r\n"
            + b"Connection: close\r\n\r\n"
            + b"0\r\n\r\nX"
        ),
        "duplicate_content_length": (
            prefix
            + b"Content-Length: 4\r\n"
            + b"Content-Length: 5\r\n"
            + b"Connection: close\r\n\r\n"
            + b"test!"
        ),
        "malformed_chunk": (
            prefix
            + b"Transfer-Encoding: chunked\r\n"
            + b"Connection: close\r\n\r\n"
            + b"Z\r\ninvalid\r\n0\r\n\r\n"
        ),
    }


def raw_exchange(host: str, port: int, payload: bytes, *, timeout: float = 5) -> bytes:
    chunks: list[bytes] = []
    with socket.create_connection((host, port), timeout=timeout) as stream:
        stream.settimeout(timeout)
        stream.sendall(payload)
        try:
            stream.shutdown(socket.SHUT_WR)
        except OSError:
            pass
        while sum(len(value) for value in chunks) < 65536:
            try:
                value = stream.recv(8192)
            except (ConnectionResetError, TimeoutError, socket.timeout):
                break
            if not value:
                break
            chunks.append(value)
    return b"".join(chunks)


def has_sensitive_detail(value: bytes) -> bool:
    lowered = value.lower()
    return any(marker in lowered for marker in SENSITIVE_MARKERS)


def one_header(response: dict[str, Any], name: str) -> str:
    values = response["headers"].get(name.casefold(), [])
    return ", ".join(values)


def redacted_response(response: dict[str, Any]) -> dict[str, Any]:
    return {
        "status": response["status"],
        "body_bytes": response["body_bytes"],
        "body_sha256": response["body_sha256"],
        "headers": {
            name: values
            for name, values in response["headers"].items()
            if name
            in {
                "allow",
                "cache-control",
                "content-security-policy",
                "content-type",
                "permissions-policy",
                "referrer-policy",
                "server",
                "x-accel-buffering",
                "x-content-type-options",
                "x-frame-options",
            }
        },
    }


def method_allowlist_passes(
    root_status: int,
    allowed_post_status: int,
    method_results: dict[str, dict[str, Any]],
) -> bool:
    invalid = method_results["BLAH"]
    invalid_rejected = invalid["status"] == 400 or (
        invalid["status"] == 405 and invalid["allow"] == "GET, POST"
    )
    disallowed = (
        value
        for method, value in method_results.items()
        if method != "BLAH"
    )
    return (
        root_status == 200
        and allowed_post_status != 405
        and invalid_rejected
        and all(
            value["status"] == 405 and value["allow"] == "GET, POST"
            for value in disallowed
        )
    )


def run_checks(
    connect_host: str,
    port: int,
    authority: str,
    *,
    expect_secure_cookie: bool,
) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []

    def record(name: str, passed: bool, evidence: Any) -> None:
        checks.append({"name": name, "pass": bool(passed), "evidence": evidence})

    root_before = http_request(connect_host, port, authority, "GET", "/")
    health = http_request(connect_host, port, authority, "GET", "/healthz")
    record("valid-authority-root", root_before["status"] == 200, redacted_response(root_before))
    record(
        "minimal-health",
        health["status"] == 200
        and health["body"] == b'{"status":"ok"}'
        and not has_sensitive_detail(health["body"]),
        redacted_response(health),
    )

    invalid_authorities = (
        "localhost",
        "admin.hk",
        "scan-planner.hku.hk:8888",
        "arbitrary.invalid",
    )
    host_results: dict[str, int] = {}
    for invalid in invalid_authorities:
        response = http_request(connect_host, port, invalid, "GET", "/api/me")
        host_results[invalid] = response["status"]
    record(
        "unexpected-authorities-rejected",
        all(status == 421 for status in host_results.values()),
        host_results,
    )

    root_after = http_request(connect_host, port, authority, "GET", "/")
    record(
        "malicious-host-cannot-poison-clean-response",
        root_after["status"] == 200
        and root_before["body_sha256"] == root_after["body_sha256"],
        {
            "before_sha256": root_before["body_sha256"],
            "after_sha256": root_after["body_sha256"],
        },
    )

    allowed_post = http_request(
        connect_host,
        port,
        authority,
        "POST",
        "/api/threads",
        body=b"{}",
        headers={"Content-Type": "application/json"},
    )
    post_boundary_login = http_request(
        connect_host,
        port,
        authority,
        "GET",
        "/login",
    )
    record(
        "upstream-request-boundary",
        allowed_post["status"] == 401
        and post_boundary_login["status"] in {301, 302, 303, 307, 308},
        {
            "unauthenticated_post_status": allowed_post["status"],
            "following_login_status": post_boundary_login["status"],
        },
    )
    method_results: dict[str, dict[str, Any]] = {}
    for method in ("BLAH", "PUT", "PATCH", "DELETE", "TRACE", "CONNECT", "OPTIONS"):
        request_target = authority if method == "CONNECT" else "/api/me"
        response = http_request(connect_host, port, authority, method, request_target)
        method_results[method] = {
            "status": response["status"],
            "allow": one_header(response, "allow"),
        }
    record(
        "method-allowlist",
        method_allowlist_passes(
            root_before["status"],
            allowed_post["status"],
            method_results,
        ),
        method_results,
    )

    query_paths = (
        "/api/me?sort=__class__",
        "/api/me?filter[$ne]=1",
        "/api/threads?where=1%3D1",
        "/api/threads?include=__table__",
    )
    query_responses = [
        http_request(connect_host, port, authority, "GET", path) for path in query_paths
    ]
    record(
        "api-query-contract",
        all(response["status"] == 400 for response in query_responses)
        and len({response["body_sha256"] for response in query_responses}) == 1
        and not any(has_sensitive_detail(response["body"]) for response in query_responses),
        [redacted_response(response) for response in query_responses],
    )

    framing_results: dict[str, dict[str, Any]] = {}
    for name, payload in raw_framing_cases(authority).items():
        response = raw_exchange(connect_host, port, payload)
        status = parse_status(response)
        clean = http_request(connect_host, port, authority, "GET", "/healthz")
        framing_results[name] = {
            "status": status,
            "response_sha256": sha256(response),
            "clean_status": clean["status"],
            "clean_body_sha256": clean["body_sha256"],
        }
    record(
        "ambiguous-framing-rejected",
        all(
            value["status"] == 400 and value["clean_status"] == 200
            for value in framing_results.values()
        ),
        framing_results,
    )

    route_cases = {
        "html": ("GET", "/", HTML_CSP),
        "api-unauthorized": ("GET", "/api/me", API_CSP),
        "api-not-found": ("GET", "/api/not-found", API_CSP),
        "health": ("GET", "/healthz", API_CSP),
        "redirect": ("GET", "/login", HTML_CSP),
        "error-405": ("PUT", "/api/me", API_CSP),
    }
    route_results: dict[str, Any] = {}
    route_pass = True
    for name, (method, path, expected_csp) in route_cases.items():
        response = http_request(connect_host, port, authority, method, path)
        route_results[name] = redacted_response(response)
        route_pass = route_pass and (
            one_header(response, "x-frame-options") == "DENY"
            and one_header(response, "x-content-type-options") == "nosniff"
            and one_header(response, "referrer-policy") == "no-referrer"
            and bool(one_header(response, "permissions-policy"))
            and one_header(response, "content-security-policy") == expected_csp
            and one_header(response, "server") == "nginx"
        )
    record("security-headers-all-routes", route_pass, route_results)

    stream = http_request(
        connect_host,
        port,
        authority,
        "POST",
        "/api/threads/not-a-session/messages/stream",
        body=b'{"content":"test"}',
        headers={
            "Accept": "text/event-stream",
            "Content-Type": "application/json",
        },
    )
    record(
        "sse-buffering-policy",
        one_header(stream, "cache-control") == "no-cache, no-transform"
        and one_header(stream, "x-accel-buffering") == "no"
        and one_header(stream, "content-security-policy") == API_CSP,
        redacted_response(stream),
    )

    login = post_boundary_login
    cookies = login["headers"].get("set-cookie", [])
    cookie_text = "; ".join(cookies).casefold()
    cookie_ok = (
        login["status"] in {301, 302, 303, 307, 308}
        and len(cookies) == 1
        and "httponly" in cookie_text
        and "samesite=lax" in cookie_text
        and ("secure" in cookie_text) == expect_secure_cookie
    )
    record(
        "anonymous-cookie-flags",
        cookie_ok,
        {
            "status": login["status"],
            "cookie_count": len(cookies),
            "httponly": "httponly" in cookie_text,
            "samesite_lax": "samesite=lax" in cookie_text,
            "secure": "secure" in cookie_text,
        },
    )

    return {
        "schema_version": 1,
        "target": {
            "connect_host": connect_host,
            "port": port,
            "authority": authority,
        },
        "plugin_dispositions": PLUGIN_DISPOSITIONS,
        "checks": checks,
        "pass_count": sum(item["pass"] for item in checks),
        "check_count": len(checks),
        "pass": all(item["pass"] for item in checks),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--connect-host", default="127.0.0.1")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--authority", required=True)
    parser.add_argument("--expect-secure-cookie", action="store_true")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    result = run_checks(
        args.connect_host,
        args.port,
        args.authority,
        expect_secure_cookie=args.expect_secure_cookie,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.output.with_suffix(args.output.suffix + ".tmp")
    temporary.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.chmod(0o600)
    temporary.replace(args.output)
    print(f"pass_count={result['pass_count']} check_count={result['check_count']}")
    return 0 if result["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
