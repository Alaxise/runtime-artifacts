# Third-party notices

This selective package preserves all infrastructure artifacts from its parent
non-SSO release. It changes only the protected application-agent image.

The application image retains the license and notice material for its bundled
runtime dependencies. The parent release continues to govern the unchanged
reverse proxy, UI, search service, coordinator, object store, and vector
engine.

This notice is an inventory aid, not a substitute for legal review of the
selected licenses or transitive image dependencies.
