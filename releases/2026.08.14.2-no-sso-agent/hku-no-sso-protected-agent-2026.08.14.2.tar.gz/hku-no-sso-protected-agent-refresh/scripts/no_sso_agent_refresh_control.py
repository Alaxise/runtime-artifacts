#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


PROJECT = "hku-no-sso-v3"
AGENT = "hku-no-sso-v3-agent"
PRESERVED = (
    "hku-no-sso-v3-entrypoint",
    "hku-no-sso-v3-ui",
    "hku-no-sso-v3-search",
    "hku-no-sso-v3-coordinator",
    "hku-no-sso-v3-object",
    "hku-no-sso-v3-vector",
)
CONTRACT_KEYS = {
    "REFRESH_RELEASE_ID",
    "REFRESH_PARENT_RELEASE",
    "REFRESH_CANDIDATE_AGENT_IMAGE",
    "REFRESH_CANDIDATE_AGENT_IMAGE_ID",
    "REFRESH_EXPECTED_SOURCE_REVISION",
    "REFRESH_EXPECTED_BEHAVIOR_REVISION",
    "REFRESH_EXPECTED_PROMPT_SHA256",
    "REFRESH_EXPECTED_TIMETABLE_SHA256",
    "REFRESH_EXPECTED_TIMETABLE_ROWS",
}


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def run(*command: str, check: bool = True) -> str:
    result = subprocess.run(command, check=False, capture_output=True, text=True)
    if check and result.returncode != 0:
        fail(result.stderr.strip() or result.stdout.strip() or "command failed")
    return result.stdout


def read_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        key, separator, value = line.partition("=")
        if not separator or key in values:
            fail(f"invalid environment entry at {path}:{number}")
        values[key] = value
    return values


def inspect(name: str) -> dict[str, Any]:
    payload = json.loads(run("docker", "inspect", name))
    if not isinstance(payload, list) or len(payload) != 1:
        fail(f"container is unavailable: {name}")
    return payload[0]


def normalized(name: str) -> dict[str, Any]:
    item = inspect(name)
    state = item.get("State") or {}
    config = item.get("Config") or {}
    host = item.get("HostConfig") or {}
    return {
        "container_id": item.get("Id", ""),
        "image_id": item.get("Image", ""),
        "state": state.get("Status", ""),
        "health": (state.get("Health") or {}).get("Status", "none"),
        "started_at": state.get("StartedAt", ""),
        "restart_count": item.get("RestartCount", 0),
        "project": (config.get("Labels") or {}).get("com.docker.compose.project", ""),
        "network_mode": host.get("NetworkMode", ""),
        "pid_mode": host.get("PidMode", ""),
        "port_bindings": host.get("PortBindings") or {},
        "mounts": sorted(
            (
                {
                    "source": mount.get("Source", ""),
                    "destination": mount.get("Destination", ""),
                    "read_write": bool(mount.get("RW")),
                }
                for mount in item.get("Mounts") or []
            ),
            key=lambda value: (value["destination"], value["source"]),
        ),
        "environment_sha256": hashlib.sha256(
            "\0".join(sorted(config.get("Env") or [])).encode("utf-8")
        ).hexdigest(),
    }


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with tempfile.NamedTemporaryFile(
        "w", encoding="utf-8", dir=path.parent, delete=False
    ) as stream:
        json.dump(payload, stream, indent=2, sort_keys=True)
        stream.write("\n")
        temporary = Path(stream.name)
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)


def capture(output: Path) -> None:
    payload = {
        "schema_version": 1,
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "agent": normalized(AGENT),
        "preserved": {name: normalized(name) for name in PRESERVED},
    }
    for name, item in {AGENT: payload["agent"], **payload["preserved"]}.items():
        if item["project"] != PROJECT or item["state"] != "running":
            fail(f"deployment inventory is not stable: {name}")
    atomic_json(output, payload)
    print(f"agent-refresh snapshot written: {output}")


def make_candidate(live: Path, contract: Path, output: Path) -> None:
    live_values = read_env(live)
    contract_values = read_env(contract)
    if set(contract_values) != CONTRACT_KEYS:
        fail("candidate metadata key set changed")
    image = contract_values["REFRESH_CANDIDATE_AGENT_IMAGE"]
    if "@sha256:" not in image:
        fail("candidate agent image is not digest-pinned")
    if "NO_SSO_AGENT_IMAGE" not in live_values:
        fail("live agent image setting is missing")
    live_values["NO_SSO_AGENT_IMAGE"] = image
    with tempfile.NamedTemporaryFile(
        "w", encoding="utf-8", dir=output.parent, delete=False
    ) as stream:
        for key, value in live_values.items():
            stream.write(f"{key}={value}\n")
        temporary = Path(stream.name)
    os.chmod(temporary, 0o600)
    os.replace(temporary, output)
    print(f"candidate environment written: {output}")


def validate_parent(snapshot: Path, live_env: Path) -> None:
    before = json.loads(snapshot.read_text(encoding="utf-8"))["agent"]
    reference = read_env(live_env).get("NO_SSO_AGENT_IMAGE", "")
    if not reference:
        fail("live agent image setting is missing")
    expected = run("docker", "image", "inspect", reference, "--format", "{{.Id}}").strip()
    if before["image_id"] != expected:
        fail("running parent agent does not match the live image contract")
    if before["health"] not in {"healthy", "none"}:
        fail("running parent agent is not healthy")
    print("running no-SSO agent matches the parent image contract")


def compare_preserved(snapshot: Path) -> None:
    before = json.loads(snapshot.read_text(encoding="utf-8"))
    changed = [
        name
        for name, expected in before["preserved"].items()
        if normalized(name) != expected
    ]
    if changed:
        fail("preserved no-SSO containers changed: " + ", ".join(changed))
    print("all non-agent no-SSO containers are unchanged")


def verify_agent(snapshot: Path, expected_image_id: str | None) -> None:
    before = json.loads(snapshot.read_text(encoding="utf-8"))["agent"]
    after = normalized(AGENT)
    expected = expected_image_id or before["image_id"]
    if after["image_id"] != expected:
        fail("agent image identity differs from the expected state")
    for key in ("network_mode", "pid_mode", "port_bindings", "mounts"):
        if after[key] != before[key]:
            fail(f"agent boundary changed: {key}")
    if expected_image_id is None and after["environment_sha256"] != before["environment_sha256"]:
        fail("rollback did not restore the prior agent environment")
    if after["state"] != "running" or after["health"] not in {"healthy", "none"}:
        fail("agent is not ready")
    print("agent image and runtime boundary verified")


def main() -> None:
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)
    capture_parser = commands.add_parser("capture")
    capture_parser.add_argument("--output", type=Path, required=True)
    candidate = commands.add_parser("make-candidate")
    candidate.add_argument("--live", type=Path, required=True)
    candidate.add_argument("--contract", type=Path, required=True)
    candidate.add_argument("--output", type=Path, required=True)
    parent = commands.add_parser("validate-parent")
    parent.add_argument("--snapshot", type=Path, required=True)
    parent.add_argument("--live-env", type=Path, required=True)
    compare = commands.add_parser("compare-preserved")
    compare.add_argument("--snapshot", type=Path, required=True)
    verify = commands.add_parser("verify-agent")
    verify.add_argument("--snapshot", type=Path, required=True)
    verify.add_argument("--expected-image-id")
    args = parser.parse_args()
    if args.command == "capture":
        capture(args.output)
    elif args.command == "make-candidate":
        make_candidate(args.live, args.contract, args.output)
    elif args.command == "validate-parent":
        validate_parent(args.snapshot, args.live_env)
    elif args.command == "compare-preserved":
        compare_preserved(args.snapshot)
    else:
        verify_agent(args.snapshot, args.expected_image_id)


if __name__ == "__main__":
    main()
