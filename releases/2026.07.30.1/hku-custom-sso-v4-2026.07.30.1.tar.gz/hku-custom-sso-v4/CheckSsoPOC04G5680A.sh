#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
PROJECT=hku-sso-v4
SNAPSHOT="$ROOT/evidence/control-before.json"
COMPOSE=(
  "$ROOT/scripts/compose_no_sso.sh"
  -p "$PROJECT"
  -f compose.sso-poc04.g5680a.yml
)

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

env_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' .env
}

wait_container() {
  local container="$1"
  local expected="${2:-healthy}"
  local state
  for _ in $(seq 1 180); do
    state="$(
      docker inspect "$container" \
        --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' \
        2>/dev/null || true
    )"
    [[ "$state" == "$expected" ]] && return 0
    sleep 2
  done
  fail "$container did not reach $expected"
}

milvus_count() {
  local filter="$1"
  local address
  local response
  address="$(env_value NO_SSO_VECTOR_ENGINE_ADDRESS)"
  response="$(
    curl -fsS \
      -H 'Authorization: Bearer root:Milvus' \
      -H 'Request-Timeout: 30' \
      -H 'Content-Type: application/json' \
      -d "{\"dbName\":\"default\",\"collectionName\":\"$(env_value NO_SSO_COLLECTION)\",\"filter\":\"$filter\",\"outputFields\":[\"count(*)\"]}" \
      "http://${address}:19530/v2/vectordb/entities/query"
  )"
  python3 - "$response" <<'PY'
import json
import sys

payload = json.loads(sys.argv[1])
if int(payload.get("code", -1)) != 0:
    raise SystemExit(payload.get("message", "vector count query failed"))
print(int(payload["data"][0]["count(*)"]))
PY
}

[[ -f .env ]] || fail "Missing .env"
[[ -f "$SNAPSHOT" ]] || fail "Missing control snapshot"
python3 scripts/agent_api_key.py check .env
python3 scripts/agent_api_key.py check .env --key-name RAG_API_KEY
python3 scripts/sso_poc04_target.py --root "$ROOT" --env "$ROOT/.env" check-config

for container in \
  hku-sso-v4-entrypoint \
  hku-sso-v4-session \
  hku-sso-v4-ui \
  hku-sso-v4-agent \
  hku-sso-v4-search \
  hku-sso-v4-vector; do
  wait_container "$container"
done
for container in \
  hku-sso-v4-gateway \
  hku-sso-v4-coordinator \
  hku-sso-v4-object; do
  wait_container "$container" running
done

"${COMPOSE[@]}" config >/dev/null
"${COMPOSE[@]}" ps
python3 scripts/sso_poc04_target.py --root "$ROOT" --env "$ROOT/.env" verify-target

docker inspect hku-sso-v4-entrypoint | python3 -c '
import json
import sys

item = json.load(sys.stdin)[0]
host = item["HostConfig"]
assert item["Config"]["User"] == "0:0"
assert host["ReadonlyRootfs"] is True
assert set(host["CapDrop"] or []) == {"ALL"}
assert set(host["CapAdd"] or []) == {"CHOWN", "DAC_OVERRIDE", "SETGID", "SETUID"}
assert "no-new-privileges:true" in (host["SecurityOpt"] or [])
assert host["RestartPolicy"]["Name"] == "unless-stopped"
'
docker exec hku-sso-v4-entrypoint sh -ec '
  test "$(awk '\''$1 == "Uid:" {print $2}'\'' /proc/1/status)" = 0
  worker="$(pgrep -P 1 nginx | head -1)"
  test -n "$worker"
  test "$(awk '\''$1 == "Uid:" {print $2}'\'' "/proc/$worker/status")" = 101
' || fail "TLS entrypoint privilege boundary changed"

expected_host="$(env_value AUTH_EXPECTED_HOST)"
entrypoint_port="$(env_value AUTH_ENTRYPOINT_PORT)"
public_backend="https://${expected_host}:${entrypoint_port}"
curl_options=(
  --resolve "${expected_host}:${entrypoint_port}:127.0.0.1"
  --cacert certs/tls.crt
)

docker exec hku-sso-v4-entrypoint nginx -t >/dev/null \
  || fail "Nginx configuration is invalid"
nginx_version="$(docker exec hku-sso-v4-entrypoint nginx -v 2>&1)"
grep -q 'nginx/1.30.4' <<<"$nginx_version" || fail "Nginx version changed"
openssl x509 -in certs/tls.crt -noout -checkend 86400 >/dev/null \
  || fail "TLS certificate is expired or near expiry"
[[ "$(openssl x509 -in certs/tls.crt -pubkey -noout)" == "$(openssl pkey -in certs/tls.key -pubout)" ]] \
  || fail "TLS certificate and private key do not match"
openssl x509 -in certs/tls.crt -noout -ext subjectAltName \
  | grep -Fq "DNS:${expected_host}" \
  || fail "TLS certificate does not contain the public hostname"
openssl x509 -in certs/tls.crt -noout -ext subjectAltName \
  | grep -Fq "IP Address:$(env_value AUTH_BACKEND_CERT_IP)" \
  || fail "TLS certificate does not contain the target IP address"
echo | openssl s_client -connect "127.0.0.1:${entrypoint_port}" -tls1_2 >/dev/null 2>&1 \
  || fail "TLS 1.2 handshake failed"
echo | openssl s_client -connect "127.0.0.1:${entrypoint_port}" -tls1_3 >/dev/null 2>&1 \
  || fail "TLS 1.3 handshake failed"

headers="$(curl -fsS -D- -o /dev/null "${curl_options[@]}" "${public_backend}/")"
grep -qi '^strict-transport-security:' <<<"$headers" || fail "HSTS is missing"
grep -qi '^content-security-policy:' <<<"$headers" || fail "CSP is missing"
grep -qi '^x-content-type-options: nosniff' <<<"$headers" || fail "nosniff is missing"
[[ "$(
  curl -ksS -o /dev/null -w '%{http_code}' \
    -H 'Host: untrusted.example' \
    "https://127.0.0.1:${entrypoint_port}/"
)" == "421" ]] || fail "Unexpected Host authority was not rejected"

gateway_version="$(docker exec hku-sso-v4-gateway /bin/oauth2-proxy --version 2>&1)"
grep -q 'v7.15.3' <<<"$gateway_version" || fail "Authentication gateway version changed"
docker exec hku-sso-v4-gateway /bin/oauth2-proxy \
  --config=/etc/auth-gateway/config.cfg \
  --alpha-config=/etc/auth-gateway/alpha.yaml \
  --config-test >/dev/null
for setting in \
  'session_store_type = "redis"' \
  'cookie_name = "__Host-hku_auth"' \
  'cookie_secure = true' \
  'cookie_httponly = true' \
  'cookie_samesite = "lax"' \
  'ssl_insecure_skip_verify = false'; do
  grep -Fqx "$setting" runtime/auth-gateway.cfg \
    || fail "Authentication setting is missing: $setting"
done
for setting in \
  '    code_challenge_method: S256' \
  '      insecureSkipNonce: false' \
  '      insecureSkipIssuerVerification: false' \
  '      emailClaim: "email"' \
  '      userIDClaim: "email"' \
  '        - RS256'; do
  grep -Fqx "$setting" runtime/auth-gateway-alpha.yaml \
    || fail "Structured identity setting is missing: $setting"
done
grep -A3 -F '  - name: X-Auth-Request-User' runtime/auth-gateway-alpha.yaml \
  | grep -Fq 'claim: "sub"' \
  || fail "Stable OIDC subject is not propagated to the UI"

ui_env="$(docker inspect hku-sso-v4-ui --format '{{range .Config.Env}}{{println .}}{{end}}')"
for setting in \
  'HKU_UI_AUTH_MODE=trusted_headers' \
  'HKU_UI_TRUSTED_PROXY_CIDRS=127.0.0.1/32' \
  'HKU_UI_TRUSTED_PROXY_SECRET_FILE=/run/secrets/ui-proxy-secret' \
  'HKU_UI_ALLOWED_EMAIL_DOMAINS=hku.hk,connect.hku.hk' \
  'HKU_UI_BACKEND_STREAMING=1' \
  'HKU_UI_SQLITE_BUSY_TIMEOUT_MS=2000' \
  'HKU_UI_MAX_ACTIVE_STREAMS=256' \
  'HKU_UI_MAX_ACTIVE_STREAMS_PER_PRINCIPAL=1' \
  'HKU_UI_MAX_ACTIVE_STREAMS_PER_SESSION=1'; do
  grep -Fqx "$setting" <<<"$ui_env" || fail "UI setting changed: $setting"
done

agent_env="$(docker inspect hku-sso-v4-agent --format '{{range .Config.Env}}{{println .}}{{end}}')"
for setting in \
  'DEEPSEEK_MODEL=deepseek-v4-flash' \
  'DEEPSEEK_JUDGE_MODEL=deepseek-v4-flash' \
  'HKU_GROUNDED_ANSWER_GATE_ENABLED=true' \
  'HKU_AGENT_STATELESS_CHAT_COMPLETIONS=true' \
  'HKU_AGENT_DASHBOARD_ENABLED=false' \
  'HKU_COURSE_SEARCH_COLLECTION=DATASET_HKU_GB10_POC_04' \
  'HKU_COURSE_SEARCH_LATEST_ACADEMIC_YEAR=2026-2027' \
  'HKU_COURSE_SEARCH_MAX_HIT_CHARS=4000' \
  'HKU_AGENT_CONTEXT_FILE_MAX_CHARS=32768' \
  'HKU_AGENT_MAX_ITERATIONS=6' \
  'LOG_LEVEL=ERROR' \
  'HKU_AGENT_LOG_LEVEL=ERROR'; do
  grep -Fqx "$setting" <<<"$agent_env" || fail "Agent setting changed: $setting"
done

rag_env="$(docker inspect hku-sso-v4-search --format '{{range .Config.Env}}{{println .}}{{end}}')"
for setting in \
  'MILVUS_COLLECTION=DATASET_HKU_GB10_POC_04' \
  'HKU_DEFAULT_COLLECTION=DATASET_HKU_GB10_POC_04' \
  'RAG_MAX_CONCURRENCY=16' \
  'RAG_MAX_QUEUE=16' \
  'RAG_QUEUE_TIMEOUT_SECONDS=5'; do
  grep -Fqx "$setting" <<<"$rag_env" || fail "Search setting changed: $setting"
done

all_rows="$(milvus_count 'chunk_id != \"\"')"
latest_rows="$(milvus_count 'is_latest == true')"
historical_rows="$(milvus_count 'is_latest == false')"
[[ "$all_rows" == "15590" ]] || fail "Vector row count changed: $all_rows"
[[ "$latest_rows" == "3785" ]] || fail "Latest vector row count changed: $latest_rows"
[[ "$historical_rows" == "11805" ]] || fail "Historical vector row count changed: $historical_rows"
[[ "$((latest_rows + historical_rows))" == "$all_rows" ]] \
  || fail "Latest-tag counts do not reconcile to the vector collection total"

[[ "$(docker inspect hku-sso-v4-ui --format '{{.Image}}')" == \
  "sha256:7a0be32377292e69f43f495e00ac1db480592b3b7c540a8ec882c09b1a607ad7" ]] \
  || fail "UI image differs from the qualified 27380 image"
[[ "$(docker inspect hku-sso-v4-agent --format '{{.Image}}')" == \
  "sha256:64af6751389fca2e2f3e64740008ff513f0701ee5a029693312a3be6d3910efa" ]] \
  || fail "Agent image differs from the qualified 27380 image"
[[ "$(docker inspect hku-sso-v4-search --format '{{.Image}}')" == \
  "sha256:af445f78389d148a4ce47f0eeb9c3f9d8a7ec4c22219357352d2fb7b92f4c443" ]] \
  || fail "Search image differs from the qualified 27380 image"

prompt="$(
  docker exec hku-sso-v4-agent \
    sha256sum /opt/hku-runtime/.hku_agent/profiles/hku-chatbot-no-sso-rag-v2/SOUL.md \
    | awk '{print $1}'
)"
[[ "$prompt" == "33dc49132eef9962e88dd661e85955e01a467cdb721f63b8dc52f5fbd0eb4c5b" ]] \
  || fail "Embedded prompt differs from the qualified 27380 prompt"

docker exec hku-sso-v4-agent sh -ec \
  'test -z "$(find /opt/hku-runtime/bin -type f \( -name "*.py" -o -name "*.pyc" \) -print -quit)"' \
  || fail "Agent application source is present"
docker exec hku-sso-v4-search sh -ec \
  'test -z "$(find /opt/hku-search/runtime -type f \( -name "*.py" -o -name "*.pyc" \) -print -quit)"' \
  || fail "Search application source is present"
docker exec hku-sso-v4-ui sh -ec '
  test -x /opt/hku-ui/hku-ui
  test ! -e /opt/hku-ui/app.py
  test ! -d /opt/hku-ui/hku_ui
  test -z "$(find /opt/hku-ui -path "*/_internal" -prune -o -type f \( -name "*.py" -o -name "*.pyc" \) -print -quit)"
' || fail "UI application source is present"

direct_status="$(
  curl -sS -o /dev/null -w '%{http_code}' \
    -H 'X-HKU-Auth-User: forged-subject' \
    -H 'X-HKU-Auth-Email: forged@hku.hk' \
    "http://127.0.0.1:$(env_value AUTH_UI_HOST_PORT)/api/me"
)"
[[ "$direct_status" == "401" ]] || fail "Untrusted identity headers bypassed the UI"

python3 tests/e2e_hku_prelogin.py \
  --base "$public_backend" \
  --host "$expected_host" \
  --resolve-to 127.0.0.1 \
  --client-id "$(env_value AUTH_OIDC_CLIENT_ID)" \
  --issuer "$(env_value AUTH_OIDC_ISSUER_URL)" \
  --scope "$(env_value AUTH_OIDC_SCOPES)" \
  --ca-certificate certs/tls.crt \
  --backend-port "$entrypoint_port"

metadata="$(docker inspect hku-sso-v4-entrypoint hku-sso-v4-gateway hku-sso-v4-session hku-sso-v4-ui)"
for secret_file in \
  secrets/oidc-client-secret \
  secrets/session-password \
  secrets/ui-proxy-secret; do
  secret="$(cat "$secret_file")"
  grep -Fq "$secret" <<<"$metadata" && fail "A file-backed secret is exposed in container metadata"
done
logs="$(docker logs hku-sso-v4-entrypoint 2>&1; docker logs hku-sso-v4-gateway 2>&1)"
if grep -Eqi '(authorization: bearer|access_token=|refresh_token=|id_token=|[?&]code=)' <<<"$logs"; then
  fail "Authorization material appeared in logs"
fi

python3 scripts/sso_poc04_target.py \
  --root "$ROOT" \
  --env "$ROOT/.env" \
  compare \
  --before "$SNAPSHOT"

echo "SSO POC04 target verification passed."
