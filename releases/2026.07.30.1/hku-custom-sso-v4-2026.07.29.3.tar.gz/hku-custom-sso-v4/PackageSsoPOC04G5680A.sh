#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

version="2026.07.29.3"
if [[ "$#" -gt 0 && "$1" != "$version" ]]; then
  echo "ERROR: This packager is locked to release $version." >&2
  exit 1
fi
release_tag="hku-sso-poc04-g5680a-${version}"
archive="hku-custom-sso-v4-${version}.tar.gz"
release_dir="$ROOT/release"

[[ -z "$(git status --porcelain)" ]] \
  || { echo "ERROR: Refusing to package a dirty worktree." >&2; exit 1; }
[[ "$(git rev-parse HEAD)" == "$(git rev-parse "${release_tag}^{commit}")" ]] \
  || { echo "ERROR: HEAD must be the exact $release_tag release commit." >&2; exit 1; }
python3 scripts/verify_sso_poc04_release.py --root "$ROOT"

files=(
  .env.g5680a.sso-poc04.example
  CheckSsoPOC04G5680A.sh
  DEPLOY_G5680A_SSO_POC04.md
  GenerateBackendTLS.sh
  InstallSsoPOC04G5680A.sh
  PackageSsoPOC04G5680A.sh
  PrepareSsoPOC04G5680A.sh
  PreflightSsoPOC04G5680A.sh
  RestorePOC03.sh
  RunRegressionSsoPOC04G5680A.sh
  StagePOC03.sh
  StartSsoPOC04G5680A.sh
  StopSsoPOC04G5680A.sh
  THIRD_PARTY_NOTICES_SSO_POC04.md
  compose.sso-poc04.g5680a.yml
  entrypoint/provider.none.conf
  entrypoint/security-headers.conf
  entrypoint/sso-poc04.g5680a.conf.template
  g5680a-sso-poc04-components.lock.json
  image-list.sso-poc04.g5680a.txt
  scripts/agent_api_key.py
  scripts/compose_no_sso.sh
  scripts/render_auth_config.py
  scripts/render_sso_entrypoint.py
  scripts/sso_poc04_target.py
  scripts/verify_vector_seed.py
  tests/e2e_agent_stream_regression.py
  tests/e2e_hku_prelogin.py
)

mkdir -p "$release_dir"
git archive --format=tar --prefix=hku-custom-sso-v4/ "$release_tag" -- "${files[@]}" \
  | gzip -n -9 > "$release_dir/$archive"

if command -v sha256sum >/dev/null 2>&1; then
  (cd "$release_dir" && sha256sum "$archive" > "$archive.sha256")
else
  digest="$(shasum -a 256 "$release_dir/$archive" | awk '{print $1}')"
  printf '%s  %s\n' "$digest" "$archive" > "$release_dir/$archive.sha256"
fi

echo "$release_dir/$archive"
echo "$release_dir/$archive.sha256"
