#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT"
COMPOSE=("$ROOT/scripts/compose_no_sso.sh" -p hku-no-sso-v3 -f compose.no-sso-rag-v2.g5680a.yml)
PUBLIC_AUTHORITY="scan-planner.hku.hk"
SECURITY_EVIDENCE="$ROOT/evidence/security"

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

env_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' .env
}

expected=(
  hku-no-sso-v3-entrypoint
  hku-no-sso-v3-ui
  hku-no-sso-v3-agent
  hku-no-sso-v3-search
  hku-no-sso-v3-coordinator
  hku-no-sso-v3-object
  hku-no-sso-v3-vector
)

python3 scripts/no_sso_target_config.py check --env .env
"${COMPOSE[@]}" config >/dev/null
"${COMPOSE[@]}" ps

for container in "${expected[@]}"; do
  deadline=$((SECONDS + 300))
  while true; do
    state="$(docker inspect "$container" --format '{{.State.Status}}' 2>/dev/null || true)"
    health="$(docker inspect "$container" 2>/dev/null | python3 -c 'import json, sys; value=json.load(sys.stdin)[0]["State"]; print((value.get("Health") or {}).get("Status", "none"))' || true)"
    if [[ "$state" == "running" && "$health" != "starting" ]]; then
      break
    fi
    (( SECONDS < deadline )) || fail "$container did not become ready"
    sleep 5
  done
  [[ "$health" == "healthy" || "$health" == "none" ]] || fail "$container health is $health"
done

python3 scripts/no_sso_target_control.py --root "$ROOT" --env "$ROOT/.env" verify-target

entrypoint_port="$(env_value NO_SSO_ENTRYPOINT_PORT)"
ui_port="$(env_value NO_SSO_UI_HOST_PORT)"
agent_port="$(env_value NO_SSO_AGENT_HOST_PORT)"
rag_port="$(env_value NO_SSO_RAG_HOST_PORT)"
coordinator_address="$(env_value NO_SSO_VECTOR_COORDINATOR_ADDRESS)"
object_address="$(env_value NO_SSO_VECTOR_OBJECT_ADDRESS)"
vector_address="$(env_value NO_SSO_VECTOR_ENGINE_ADDRESS)"
export NO_SSO_AGENT_API_KEY="$(env_value NO_SSO_AGENT_API_KEY)"

mkdir -p "$SECURITY_EVIDENCE"
chmod 700 "$SECURITY_EVIDENCE"

curl -fsS \
  -H "Host: ${PUBLIC_AUTHORITY}" \
  "http://127.0.0.1:${entrypoint_port}/healthz" >/dev/null \
  || fail "entrypoint health failed"
curl -fsS "http://127.0.0.1:${ui_port}/healthz" >/dev/null || fail "UI health failed"
curl -fsS "http://127.0.0.1:${agent_port}/health" >/dev/null || fail "agent health failed"
curl -fsS "http://127.0.0.1:${rag_port}/health" >/dev/null || fail "search API health failed"
curl -fsS "http://${coordinator_address}:2379/health" >/dev/null || fail "vector coordinator health failed"
curl -fsS "http://${object_address}:9000/minio/health/live" >/dev/null || fail "object store health failed"
curl -fsS \
  -H 'Authorization: Bearer root:Milvus' \
  -H 'Content-Type: application/json' \
  -d '{"dbName":"default"}' \
  "http://${vector_address}:19530/v2/vectordb/collections/list" >/dev/null \
  || fail "vector store health failed"

agent_env="$(docker inspect hku-no-sso-v3-agent --format '{{range .Config.Env}}{{println .}}{{end}}')"
for expected_setting in \
  'DEEPSEEK_MODEL=deepseek-v4-pro' \
  'HKU_AGENT_STATELESS_CHAT_COMPLETIONS=true' \
  'HKU_AGENT_DASHBOARD_ENABLED=false' \
  'HKU_AGENT_CONTEXT_FILE_MAX_CHARS=32768' \
  'HKU_AGENT_MAX_ITERATIONS=6' \
  'HKU_AGENT_MODEL_MAX_TOKENS=1200' \
  'HKU_COURSE_SEARCH_COLLECTION=DATASET_HKU_GB10_POC_03_LATEST_FAMILY_V1' \
  'HKU_COURSE_SEARCH_LATEST_ACADEMIC_YEAR=2026-2027' \
  'HKU_COURSE_SEARCH_MAX_HIT_CHARS=4000' \
  'HKU_COURSE_SEARCH_TRACE=false' \
  'LOG_LEVEL=ERROR' \
  'HKU_AGENT_LOG_LEVEL=ERROR'; do
  grep -Fqx "$expected_setting" <<<"$agent_env" || fail "agent setting changed: $expected_setting"
done

rag_env="$(docker inspect hku-no-sso-v3-search --format '{{range .Config.Env}}{{println .}}{{end}}')"
grep -Fqx 'MILVUS_COLLECTION=DATASET_HKU_GB10_POC_03_LATEST_FAMILY_V1' <<<"$rag_env" \
  || fail "search collection changed"
grep -Fqx 'HKU_DEFAULT_COLLECTION=DATASET_HKU_GB10_POC_03_LATEST_FAMILY_V1' <<<"$rag_env" \
  || fail "default search collection changed"
grep -Fqx "MILVUS_HOST=${vector_address}" <<<"$rag_env" \
  || fail "search vector address changed"
grep -Fqx 'MILVUS_PORT=19530' <<<"$rag_env" || fail "search vector port changed"

ui_env="$(docker inspect hku-no-sso-v3-ui --format '{{range .Config.Env}}{{println .}}{{end}}')"
grep -Fqx 'HKU_UI_AUTH_MODE=anonymous' <<<"$ui_env" || fail "the no-SSO lane enabled external authentication"
grep -Fqx 'HKU_UI_BACKEND_STREAMING=1' <<<"$ui_env" || fail "UI backend streaming is disabled"
grep -Fqx 'HKU_UI_ANONYMOUS_COOKIE_SECURE=1' <<<"$ui_env" \
  || fail "UI anonymous cookie is not Secure"

actual_prompt="$(docker exec hku-no-sso-v3-agent sha256sum /opt/hku-runtime/.hku_agent/profiles/hku-chatbot-no-sso-rag-v2/SOUL.md | awk '{print $1}')"
[[ "$actual_prompt" == "1f60880e86ded79e265de0e41324d2659cf855218883b5810b4987d843d14a9d" ]] \
  || fail "embedded prompt hash changed"

docker exec hku-no-sso-v3-agent sh -ec \
  'test -z "$(find /opt/hku-runtime/bin -type f \( -name "*.py" -o -name "*.pyc" \) -print -quit)"' \
  || fail "agent application source is present"
docker exec hku-no-sso-v3-search sh -ec \
  'test -z "$(find /opt/hku-search/runtime -type f \( -name "*.py" -o -name "*.pyc" \) -print -quit)"' \
  || fail "search application source is present"
docker exec hku-no-sso-v3-ui sh -ec \
  'test -z "$(find /opt/hku-ui -type f \( -name "*.py" -o -name "*.pyc" \) -print -quit)"' \
  || fail "UI application source is present"

docker exec hku-no-sso-v3-entrypoint nginx -v \
  2> "$SECURITY_EVIDENCE/nginx-version.txt"
grep -q 'nginx/1.30.4' "$SECURITY_EVIDENCE/nginx-version.txt" \
  || fail "entrypoint NGINX version changed"
docker exec hku-no-sso-v3-entrypoint nginx -t \
  > "$SECURITY_EVIDENCE/nginx-config-test.txt" 2>&1 \
  || fail "entrypoint NGINX configuration is invalid"

python3 scripts/verify_no_sso_ingress.py \
  --connect-host 127.0.0.1 \
  --port "$entrypoint_port" \
  --authority "$PUBLIC_AUTHORITY" \
  --expect-secure-cookie \
  --output "$SECURITY_EVIDENCE/tenable-remediation.json"

python3 tests/e2e_no_sso_rehearsal.py \
  --ui-base-url "http://127.0.0.1:${ui_port}" \
  --rag-base-url "http://127.0.0.1:${rag_port}" \
  --agent-base-url "http://127.0.0.1:${agent_port}" \
  --agent-api-key-env NO_SSO_AGENT_API_KEY \
  --output evidence/no-sso-target-e2e.json
./RunRegressionNoSSOTarget.sh

python3 scripts/no_sso_target_control.py --root "$ROOT" --env "$ROOT/.env" \
  compare --before evidence/control-before.json

echo "Isolated no-SSO POC03 lane checks passed."
