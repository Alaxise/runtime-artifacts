# SSO Timetable Reference UI Refresh

This package updates only the existing authenticated UI container. It adds the
`Timetable of Individual Courses` reference immediately after the course
selection schedule. It does not change authentication, session, agent, search,
vector, ingress, persistence, ports, models, prompts, or data.

Target contract:

- root: `/model/dockervolume/hku-custom-sso-v4`
- Compose project: `hku-sso-v4`
- mutable container: `hku-sso-v4-ui`
- command: `./ApplySsoTimetableUIRefresh.sh`
- rollback: `./RollbackSsoTimetableUIRefresh.sh <update-directory>`

Before application, compare the playbook with a fresh read-only inventory.
The apply script captures the live environment, Compose file, UI persistence
boundary, every preserved container, and control endpoints. Any failed check
automatically restores the previous UI image and environment.
