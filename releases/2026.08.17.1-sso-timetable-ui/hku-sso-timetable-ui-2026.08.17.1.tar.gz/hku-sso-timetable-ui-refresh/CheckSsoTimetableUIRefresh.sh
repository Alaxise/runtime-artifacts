#!/usr/bin/env bash
set -euo pipefail

PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET_ROOT="/model/dockervolume/hku-custom-sso-v4"
CONTRACT="$PACKAGE_ROOT/.env.g5680a.sso-timetable-ui.example"
UPDATE_DIR="${1:-}"

fail() { echo "ERROR: $*" >&2; exit 1; }
contract_value() { awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' "$CONTRACT"; }
live_value() { awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' "$TARGET_ROOT/.env"; }

[[ -n "$UPDATE_DIR" && -f "$UPDATE_DIR/ui-refresh-before.json" ]] || fail "UI-refresh snapshot is missing"
mkdir -p "$UPDATE_DIR/evidence"

python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" --root "$TARGET_ROOT" --env "$TARGET_ROOT/.env" check-config
python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" --root "$TARGET_ROOT" --env "$TARGET_ROOT/.env" verify-target
python3 "$PACKAGE_ROOT/scripts/sso_ui_refresh_control.py" compare-preserved --snapshot "$UPDATE_DIR/ui-refresh-before.json"
python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" --root "$TARGET_ROOT" --env "$TARGET_ROOT/.env" compare --before "$UPDATE_DIR/control-before.json"

[[ "$(docker inspect hku-sso-v4-ui --format '{{.Image}}')" == "$(contract_value REFRESH_CANDIDATE_UI_IMAGE_ID)" ]] || fail "running UI differs from the rehearsed image"
[[ "$(live_value NO_SSO_UI_IMAGE)" == "$(contract_value REFRESH_CANDIDATE_UI_IMAGE)" ]] || fail "live environment is not digest-pinned to the candidate UI"

ui_env="$(docker inspect hku-sso-v4-ui --format '{{range .Config.Env}}{{println .}}{{end}}')"
for setting in \
  'HKU_UI_PUBLIC_URL=https://curr-planner.hku.hk' \
  'HKU_UI_AUTH_MODE=trusted_headers' \
  'HKU_UI_TRUSTED_PROXY_CIDRS=127.0.0.1/32' \
  'FORWARDED_ALLOW_IPS=' \
  'HKU_UI_ALLOWED_EMAIL_DOMAINS=hku.hk,connect.hku.hk' \
  'HKU_GATEWAY_BASE_URL=http://127.0.0.1:28655/v1'; do
  grep -Fqx "$setting" <<<"$ui_env" || fail "authenticated UI setting changed: $setting"
done

docker exec hku-sso-v4-ui sh -ec '
  test -x /opt/hku-ui/hku-ui/hku-ui
  test ! -e /opt/hku-ui/app.py
  test ! -d /opt/hku-ui/hku_ui
  test -z "$(find /opt/hku-ui -path "*/_internal" -prune -o -type f \( -name "*.py" -o -name "*.pyc" \) -print -quit)"
  app="$(find /opt/hku-ui -type f -path "*/static/assets/app.js" -print -quit)"
  index="$(find /opt/hku-ui -type f -path "*/static/index.html" -print -quit)"
  grep -Fq "Timetable of Individual Courses" "$app"
  grep -Fq "2026-27%20class_timetable_20260810.xlsx" "$app"
  grep -Fq "20260817-timetable-reference-r1" "$index"
  python - <<"PY"
from pathlib import Path
import sqlite3
app = next(Path("/opt/hku-ui").glob("**/static/assets/app.js")).read_text()
assert app.index("Course Selection Schedule") < app.index("Timetable of Individual Courses") < app.index("Quick Guide on Course Selection and Enrollment")
db = sqlite3.connect("/data/hku_ui.sqlite3")
assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
db.close()
PY
'

curl -fsS "http://127.0.0.1:$(live_value AUTH_UI_HOST_PORT)/healthz" > "$UPDATE_DIR/evidence/ui-health.json"
curl -kfsS --resolve curr-planner.hku.hk:443:127.0.0.1 https://curr-planner.hku.hk/__health > "$UPDATE_DIR/evidence/public-health.txt"
public_body="$UPDATE_DIR/evidence/public-prelogin-body.html"
public_status="$(curl -ksS -o "$public_body" -w '%{http_code}' --resolve curr-planner.hku.hk:443:127.0.0.1 https://curr-planner.hku.hk/)"
api_me_status=""
if [[ "$public_status" == "200" ]]; then
  api_me_status="$(curl -ksS -o "$UPDATE_DIR/evidence/public-api-me-body.html" -w '%{http_code}' --resolve curr-planner.hku.hk:443:127.0.0.1 https://curr-planner.hku.hk/api/me)"
fi
args=(--public-status "$public_status" --public-body "$public_body")
[[ -z "$api_me_status" ]] || args+=(--api-me-status "$api_me_status")
python3 "$PACKAGE_ROOT/scripts/sso_prelogin_contract.py" "${args[@]}"

python3 "$PACKAGE_ROOT/scripts/sso_ui_refresh_control.py" compare-preserved --snapshot "$UPDATE_DIR/ui-refresh-before.json"
echo "Authenticated timetable-reference UI refresh verification passed."
