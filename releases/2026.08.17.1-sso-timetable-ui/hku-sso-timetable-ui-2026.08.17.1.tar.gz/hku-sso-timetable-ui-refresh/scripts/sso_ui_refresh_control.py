#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


PROJECT = "hku-sso-v4"
UI = "hku-sso-v4-ui"
PRESERVED = (
    "hku-sso-v4-entrypoint",
    "hku-sso-v4-gateway",
    "hku-sso-v4-session",
    "hku-sso-v4-agent",
    "hku-sso-v4-search",
    "hku-sso-v4-coordinator",
    "hku-sso-v4-object",
    "hku-sso-v4-vector",
)
CONTRACT_KEYS = {
    "REFRESH_RELEASE_ID",
    "REFRESH_PARENT_RELEASE",
    "REFRESH_CANDIDATE_UI_IMAGE",
    "REFRESH_CANDIDATE_UI_IMAGE_ID",
    "REFRESH_EXPECTED_UI_SOURCE_REVISION",
    "REFRESH_EXPECTED_PARENT_UI_REVISION",
    "REFRESH_EXPECTED_REFERENCE_LABEL",
    "REFRESH_EXPECTED_REFERENCE_URL",
    "REFRESH_EXPECTED_CACHE_KEY",
}


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def run(*command: str, check: bool = True) -> str:
    result = subprocess.run(command, check=False, capture_output=True, text=True)
    if check and result.returncode != 0:
        fail(result.stderr.strip() or result.stdout.strip() or "command failed")
    return result.stdout


def read_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        key, separator, value = line.partition("=")
        if not separator or key in values:
            fail(f"invalid environment entry at {path}:{number}")
        values[key] = value
    return values


def inspect(name: str) -> dict[str, Any]:
    payload = json.loads(run("docker", "inspect", name))
    if not isinstance(payload, list) or len(payload) != 1:
        fail(f"container is unavailable: {name}")
    return payload[0]


def normalized(name: str) -> dict[str, Any]:
    item = inspect(name)
    state = item.get("State") or {}
    config = item.get("Config") or {}
    host = item.get("HostConfig") or {}
    return {
        "container_id": item.get("Id", ""),
        "image_id": item.get("Image", ""),
        "state": state.get("Status", ""),
        "health": (state.get("Health") or {}).get("Status", "none"),
        "restart_count": item.get("RestartCount", 0),
        "project": (config.get("Labels") or {}).get("com.docker.compose.project", ""),
        "network_mode": host.get("NetworkMode", ""),
        "pid_mode": host.get("PidMode", ""),
        "port_bindings": host.get("PortBindings") or {},
        "mounts": sorted(
            (
                {
                    "source": mount.get("Source", ""),
                    "destination": mount.get("Destination", ""),
                    "read_write": bool(mount.get("RW")),
                }
                for mount in item.get("Mounts") or []
            ),
            key=lambda value: (value["destination"], value["source"]),
        ),
        "environment_sha256": hashlib.sha256(
            "\0".join(sorted(config.get("Env") or [])).encode("utf-8")
        ).hexdigest(),
    }


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as stream:
        json.dump(payload, stream, indent=2, sort_keys=True)
        stream.write("\n")
        temporary = Path(stream.name)
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)


def capture(output: Path) -> None:
    payload = {
        "schema_version": 1,
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "ui": normalized(UI),
        "preserved": {name: normalized(name) for name in PRESERVED},
    }
    for name, item in {UI: payload["ui"], **payload["preserved"]}.items():
        if item["project"] != PROJECT or item["state"] != "running":
            fail(f"deployment inventory is not stable: {name}")
    atomic_json(output, payload)
    print(f"UI-refresh snapshot written: {output}")


def make_candidate(live: Path, contract: Path, output: Path) -> None:
    live_values = read_env(live)
    contract_values = read_env(contract)
    if set(contract_values) != CONTRACT_KEYS:
        fail("candidate metadata key set changed")
    image = contract_values["REFRESH_CANDIDATE_UI_IMAGE"]
    if "@sha256:" not in image:
        fail("candidate UI image is not digest-pinned")
    if "NO_SSO_UI_IMAGE" not in live_values:
        fail("live UI image setting is missing")
    live_values["NO_SSO_UI_IMAGE"] = image
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=output.parent, delete=False) as stream:
        for key, value in live_values.items():
            stream.write(f"{key}={value}\n")
        temporary = Path(stream.name)
    os.chmod(temporary, 0o600)
    os.replace(temporary, output)
    print(f"candidate environment written: {output}")


def validate_parent(snapshot: Path, live_env: Path) -> None:
    before = json.loads(snapshot.read_text(encoding="utf-8"))["ui"]
    live_values = read_env(live_env)
    reference = live_values.get("NO_SSO_UI_IMAGE", "")
    if not reference:
        fail("live UI image setting is missing")
    expected_image_id = run("docker", "image", "inspect", reference, "--format", "{{.Id}}").strip()
    if before["image_id"] != expected_image_id:
        fail("running parent UI does not match the live image contract")
    required = {
        "HKU_UI_PUBLIC_URL=https://curr-planner.hku.hk",
        "HKU_UI_AUTH_MODE=trusted_headers",
        "HKU_UI_TRUSTED_PROXY_CIDRS=127.0.0.1/32",
        "FORWARDED_ALLOW_IPS=",
        "HKU_UI_ALLOWED_EMAIL_DOMAINS=hku.hk,connect.hku.hk",
        "HKU_GATEWAY_BASE_URL=http://127.0.0.1:28655/v1",
    }
    running_environment = set((inspect(UI).get("Config") or {}).get("Env") or [])
    missing = sorted(required - running_environment)
    if missing:
        fail("running SSO UI contract drifted: " + ", ".join(missing))
    print("running UI matches the authenticated parent release contract")


def compare_preserved(snapshot: Path) -> None:
    before = json.loads(snapshot.read_text(encoding="utf-8"))
    changed = [
        name
        for name, expected in before["preserved"].items()
        if normalized(name) != expected
    ]
    if changed:
        fail("preserved containers changed: " + ", ".join(changed))
    print("all non-UI SSO containers are unchanged")


def verify_ui_restored(snapshot: Path) -> None:
    before = json.loads(snapshot.read_text(encoding="utf-8"))["ui"]
    after = normalized(UI)
    for key in (
        "image_id",
        "network_mode",
        "pid_mode",
        "port_bindings",
        "mounts",
        "environment_sha256",
    ):
        if after[key] != before[key]:
            fail(f"rollback did not restore prior UI {key}")
    if after["state"] != "running" or after["health"] not in {"healthy", "none"}:
        fail("restored UI is not ready")
    print("prior UI image and authenticated runtime contract restored")


def main() -> None:
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)
    capture_parser = commands.add_parser("capture")
    capture_parser.add_argument("--output", type=Path, required=True)
    candidate = commands.add_parser("make-candidate")
    candidate.add_argument("--live", type=Path, required=True)
    candidate.add_argument("--contract", type=Path, required=True)
    candidate.add_argument("--output", type=Path, required=True)
    parent = commands.add_parser("validate-parent")
    parent.add_argument("--snapshot", type=Path, required=True)
    parent.add_argument("--live-env", type=Path, required=True)
    compare = commands.add_parser("compare-preserved")
    compare.add_argument("--snapshot", type=Path, required=True)
    restored = commands.add_parser("verify-ui-restored")
    restored.add_argument("--snapshot", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "capture":
        capture(args.output)
    elif args.command == "make-candidate":
        make_candidate(args.live, args.contract, args.output)
    elif args.command == "validate-parent":
        validate_parent(args.snapshot, args.live_env)
    elif args.command == "compare-preserved":
        compare_preserved(args.snapshot)
    else:
        verify_ui_restored(args.snapshot)


if __name__ == "__main__":
    main()
