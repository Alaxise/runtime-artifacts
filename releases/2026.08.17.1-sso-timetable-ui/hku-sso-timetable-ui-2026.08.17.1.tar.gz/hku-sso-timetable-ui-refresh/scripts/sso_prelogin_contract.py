#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path


LANDING_MARKERS = (
    "AI Student Curriculum Planner",
    "Terms and Conditions",
)


def validate_prelogin(
    *,
    public_status: int,
    public_body: str,
    api_me_status: int | None,
) -> None:
    if public_status in {302, 303}:
        return
    if public_status != 200:
        raise ValueError(f"public SSO pre-login path returned {public_status}")
    if api_me_status != 401:
        raise ValueError(
            "public SSO landing shell did not preserve anonymous /api/me access"
        )
    missing = [marker for marker in LANDING_MARKERS if marker not in public_body]
    if missing:
        raise ValueError(
            "public SSO pre-login 200 response is not the expected Terms landing shell"
        )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--public-status", type=int, required=True)
    parser.add_argument("--public-body", type=Path, required=True)
    parser.add_argument("--api-me-status", type=int)
    args = parser.parse_args()

    try:
        validate_prelogin(
            public_status=args.public_status,
            public_body=args.public_body.read_text(encoding="utf-8", errors="replace"),
            api_me_status=args.api_me_status,
        )
    except ValueError as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
