#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import subprocess
from pathlib import Path


RELEASE_ID = "hku-sso-timetable-ui-g5680a-2026.08.17.1"
EXPECTED_PACKAGE_FILES = {
    ".env.g5680a.sso-timetable-ui.example",
    "ApplySsoTimetableUIRefresh.sh",
    "CheckSsoTimetableUIRefresh.sh",
    "DEPLOY_G5680A_SSO_TIMETABLE_UI.md",
    "PackageSsoTimetableUIRefresh.sh",
    "RollbackSsoTimetableUIRefresh.sh",
    "compose.sso-timetable-ui.override.yml",
    "g5680a-sso-timetable-ui-components.lock.json",
    "image-list.sso-timetable-ui.g5680a.txt",
    "scripts/compose_no_sso.sh",
    "scripts/sso_poc04_target.py",
    "scripts/sso_prelogin_contract.py",
    "scripts/sso_ui_refresh_control.py",
    "scripts/verify_sso_timetable_ui_release.py",
}
FORBIDDEN_LABELS = ("her" + "mes", "no" + "us", "co" + "dex")


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def read_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line or line.startswith("#"):
            continue
        key, separator, value = line.partition("=")
        if not separator or key in values:
            fail(f"invalid contract: {path}")
        values[key] = value
    return values


def package_paths(package_script: Path) -> set[str]:
    content = package_script.read_text(encoding="utf-8")
    match = re.search(r"files=\(\n(.*?)\n\)", content, re.DOTALL)
    if not match:
        fail("package file list is missing")
    return {line.strip() for line in match.group(1).splitlines() if line.strip()}


def validate(root: Path) -> None:
    missing = sorted(path for path in EXPECTED_PACKAGE_FILES if not (root / path).is_file())
    if missing:
        fail("package files missing: " + ", ".join(missing))
    if package_paths(root / "PackageSsoTimetableUIRefresh.sh") != EXPECTED_PACKAGE_FILES:
        fail("packager scope differs from the reviewed package")

    contract = read_env(root / ".env.g5680a.sso-timetable-ui.example")
    manifest = json.loads((root / "g5680a-sso-timetable-ui-components.lock.json").read_text(encoding="utf-8"))
    if contract.get("REFRESH_RELEASE_ID") != RELEASE_ID or manifest["release"]["id"] != RELEASE_ID:
        fail("release identity changed")
    image = contract.get("REFRESH_CANDIDATE_UI_IMAGE", "")
    if "@sha256:" not in image or image != manifest["artifact"]["image"]:
        fail("candidate image is not consistently digest-pinned")
    if manifest["mutation_boundary"] != ["hku-sso-v4-ui"]:
        fail("mutation boundary expanded")

    for script_name in ("ApplySsoTimetableUIRefresh.sh", "RollbackSsoTimetableUIRefresh.sh"):
        script = (root / script_name).read_text(encoding="utf-8")
        if "up -d --no-deps web-ui" not in script:
            fail(f"{script_name} does not target the UI service")
        for service in ("agent-runtime", "rag-api", "entrypoint", "auth-gateway", "session-store"):
            if f"up -d --no-deps {service}" in script:
                fail(f"{script_name} expanded into preserved service {service}")
        for destructive in (" down", " rm ", "prune"):
            if destructive in script:
                fail(f"{script_name} contains destructive operation {destructive!r}")

    combined = "\n".join(
        (root / path).read_text(encoding="utf-8", errors="ignore")
        for path in EXPECTED_PACKAGE_FILES
    ).lower()
    for label in FORBIDDEN_LABELS:
        if label in combined:
            fail(f"package contains forbidden runtime label: {label}")
    print("SSO timetable-reference UI release package verified")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    validate(args.root.resolve())


if __name__ == "__main__":
    main()
