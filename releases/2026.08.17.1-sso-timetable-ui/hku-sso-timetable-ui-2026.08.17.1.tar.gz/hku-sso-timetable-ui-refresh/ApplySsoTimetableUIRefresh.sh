#!/usr/bin/env bash
set -euo pipefail

PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET_ROOT="/model/dockervolume/hku-custom-sso-v4"
PROJECT="hku-sso-v4"
CONTRACT="$PACKAGE_ROOT/.env.g5680a.sso-timetable-ui.example"
OVERRIDE="$PACKAGE_ROOT/compose.sso-timetable-ui.override.yml"
BASE_COMPOSE="$TARGET_ROOT/compose.sso-poc04.g5680a.yml"
RELEASE_ID="$(awk -F= '$1 == "REFRESH_RELEASE_ID" {print $2}' "$CONTRACT")"
UPDATE_ID="${SSO_TIMETABLE_UI_UPDATE_ID:-$(date -u +%Y%m%dT%H%M%SZ)-timetable-ui}"
UPDATE_DIR="$TARGET_ROOT/updates/$UPDATE_ID"
COMPOSE=("$PACKAGE_ROOT/scripts/compose_no_sso.sh" -p "$PROJECT" -f "$BASE_COMPOSE" -f "$OVERRIDE")

fail() { echo "ERROR: $*" >&2; exit 1; }
contract_value() { awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' "$CONTRACT"; }

wait_healthy() {
  local state=""
  for _ in $(seq 1 90); do
    state="$(docker inspect hku-sso-v4-ui --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' 2>/dev/null || true)"
    [[ "$state" == "healthy" ]] && return 0
    sleep 2
  done
  fail "candidate UI did not become healthy"
}

pull_image() {
  local reference="$1" tag_reference="${1%@sha256:*}" pinned_id="" tagged_id=""
  [[ "$reference" == *@sha256:* ]] || fail "candidate image is not digest-pinned"
  for attempt in $(seq 1 5); do
    if docker pull "$reference"; then
      pinned_id="$(docker image inspect "$reference" --format '{{.Id}}')"
      docker tag "$reference" "$tag_reference"
      tagged_id="$(docker image inspect "$tag_reference" --format '{{.Id}}')"
      [[ -n "$pinned_id" && "$tagged_id" == "$pinned_id" ]] || fail "candidate tag does not resolve to the approved digest"
      [[ "$pinned_id" == "$(contract_value REFRESH_CANDIDATE_UI_IMAGE_ID)" ]] || fail "candidate image ID differs from the rehearsed artifact"
      return 0
    fi
    sleep "$((attempt * 5))"
  done
  fail "candidate image pull failed"
}

[[ "$RELEASE_ID" == "hku-sso-timetable-ui-g5680a-2026.08.17.1" ]] || fail "release identity changed"
[[ "$(cd "$TARGET_ROOT" && pwd -P)" == "$TARGET_ROOT" && ! -L "$TARGET_ROOT" ]] || fail "target root changed"
[[ -f "$TARGET_ROOT/.env" && -f "$BASE_COMPOSE" && -f "$CONTRACT" && -f "$OVERRIDE" ]] || fail "release contract is incomplete"
[[ ! -e "$UPDATE_DIR" ]] || fail "update evidence directory already exists"

mkdir -p "$UPDATE_DIR"
chmod 700 "$UPDATE_DIR"
cp "$TARGET_ROOT/.env" "$UPDATE_DIR/before.env"
cp "$BASE_COMPOSE" "$UPDATE_DIR/compose.before.yml"
chmod 600 "$UPDATE_DIR/before.env" "$UPDATE_DIR/compose.before.yml"

python3 "$PACKAGE_ROOT/scripts/sso_ui_refresh_control.py" capture --output "$UPDATE_DIR/ui-refresh-before.json"
python3 "$PACKAGE_ROOT/scripts/sso_ui_refresh_control.py" validate-parent --snapshot "$UPDATE_DIR/ui-refresh-before.json" --live-env "$UPDATE_DIR/before.env"
python3 "$PACKAGE_ROOT/scripts/sso_ui_refresh_control.py" make-candidate --live "$UPDATE_DIR/before.env" --contract "$CONTRACT" --output "$UPDATE_DIR/candidate.env"
python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" --root "$TARGET_ROOT" --env "$UPDATE_DIR/candidate.env" capture --output "$UPDATE_DIR/control-before.json"

pull_image "$(contract_value REFRESH_CANDIDATE_UI_IMAGE)"
python3 "$PACKAGE_ROOT/scripts/sso_poc04_target.py" --root "$TARGET_ROOT" --env "$UPDATE_DIR/candidate.env" preflight

temporary="$(mktemp "$TARGET_ROOT/.env.candidate.XXXXXX")"
cp "$UPDATE_DIR/candidate.env" "$temporary"
chmod 600 "$temporary"
mv "$temporary" "$TARGET_ROOT/.env"

rollback_on_error() {
  local status=$?
  trap - EXIT INT TERM
  "$PACKAGE_ROOT/RollbackSsoTimetableUIRefresh.sh" "$UPDATE_DIR" || true
  exit "$status"
}
trap rollback_on_error EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

cd "$TARGET_ROOT"
cmp -s "$UPDATE_DIR/compose.before.yml" "$BASE_COMPOSE" || fail "live base Compose file drifted after capture"
"${COMPOSE[@]}" config >/dev/null
"${COMPOSE[@]}" up -d --no-deps web-ui
wait_healthy

"$PACKAGE_ROOT/CheckSsoTimetableUIRefresh.sh" "$UPDATE_DIR"
printf '%s\n' "$UPDATE_DIR" > "$TARGET_ROOT/runtime/latest-timetable-ui-refresh"
chmod 600 "$TARGET_ROOT/runtime/latest-timetable-ui-refresh"
trap - EXIT INT TERM
echo "Authenticated timetable-reference UI refresh applied and verified: $UPDATE_DIR"
