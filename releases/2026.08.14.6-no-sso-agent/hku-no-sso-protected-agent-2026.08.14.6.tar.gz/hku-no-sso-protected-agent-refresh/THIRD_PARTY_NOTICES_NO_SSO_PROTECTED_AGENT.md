# Third-party notices

This selective package preserves all infrastructure artifacts from its parent
non-SSO release except for the compatible protected search and application
agent images.

The application and search images retain the license and notice material for
their bundled runtime dependencies. The parent release continues to govern the
unchanged reverse proxy, UI, coordinator, object store, and vector engine.

This notice is an inventory aid, not a substitute for legal review of the
selected licenses or transitive image dependencies.
