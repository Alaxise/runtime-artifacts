#!/usr/bin/env bash
set -euo pipefail

SCRIPT_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
TARGET_ROOT="${1:-/model/dockervolume/hku-custom-no-sso-v3}"
EXPECTED_ROOT="/model/dockervolume/hku-custom-no-sso-v3"
PROJECT="hku-no-sso-v3"
COMPOSE_FILE="$TARGET_ROOT/compose.no-sso-rag-v2.g5680a.yml"
ENV_FILE="$TARGET_ROOT/.env"
UI_CONTAINER="hku-no-sso-v3-ui"
OLD_IMAGE="middletaste/hku-custom-web:no-sso-v4-f6bc882bfde8-arm64@sha256:7da63e25d5a9edb7260c4ab6aa699d02f445372b228a96b6fae3288d19e38fb3"
NEW_IMAGE="middletaste/hku-custom-web:no-sso-v5-0d2b570-arm64@sha256:90b4e0ecbf8139d24dc170d80c006865227ae748eb70ada078fd6bb44440c740"
NEW_IMAGE_ID="sha256:c1fd4c64c718f14c46fae5e1414107334d41837f4a46f575d1a051777256233a"
NEW_ENV_EXAMPLE="$SCRIPT_ROOT/.env.g5680a.no-sso-rag-v2.example"
NEW_MANIFEST="$SCRIPT_ROOT/g5680a-no-sso-rag-v2-components.lock.json"
NEW_IMAGE_LIST="$SCRIPT_ROOT/image-list.no-sso-rag-v2.g5680a.txt"
MUTATED=0

NON_UI_CONTAINERS=(
  hku-no-sso-v3-entrypoint
  hku-no-sso-v3-agent
  hku-no-sso-v3-search
  hku-no-sso-v3-coordinator
  hku-no-sso-v3-object
  hku-no-sso-v3-vector
)

fail() {
  echo "ERROR: $*" >&2
  return 1
}

snapshot_containers() {
  local output="$1"
  shift
  docker inspect "$@" | python3 -c '
import json
import sys

containers = json.load(sys.stdin)
records = []
for container in containers:
    state = container["State"]
    records.append(
        {
            "name": container["Name"].lstrip("/"),
            "id": container["Id"],
            "image_reference": container["Config"]["Image"],
            "image_id": container["Image"],
            "status": state["Status"],
            "health": state.get("Health", {}).get("Status", ""),
            "project": container["Config"].get("Labels", {}).get(
                "com.docker.compose.project", ""
            ),
            "mounts": sorted(
                (
                    mount["Type"],
                    mount["Source"],
                    mount["Destination"],
                    bool(mount["RW"]),
                )
                for mount in container.get("Mounts", [])
            ),
        }
    )
json.dump(records, sys.stdout, indent=2, sort_keys=True)
sys.stdout.write("\n")
' > "$output"
}

database_record() {
  local output="$1"
  local backup="${2:-}"
  local container_backup=""
  if [[ -n "$backup" ]]; then
    container_backup="/tmp/hku_ui.sqlite3.ui-refresh-$$"
  fi
  docker exec -i "$UI_CONTAINER" python3 - "$container_backup" <<'PY' > "$output"
import json
import sqlite3
import sys
from pathlib import Path

backup = Path(sys.argv[1]) if sys.argv[1] else None
source = sqlite3.connect("file:/data/hku_ui.sqlite3?mode=ro", uri=True)
try:
    integrity = source.execute("PRAGMA integrity_check").fetchone()[0]
    if integrity != "ok":
        raise SystemExit(f"SQLite integrity check failed: {integrity}")
    tables = [
        row[0]
        for row in source.execute(
            "SELECT name FROM sqlite_master "
            "WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
        )
    ]
    counts = {}
    for table in tables:
        quoted = '"' + table.replace('"', '""') + '"'
        counts[table] = source.execute(f"SELECT COUNT(*) FROM {quoted}").fetchone()[0]
    if backup is not None:
        target = sqlite3.connect(backup)
        try:
            source.backup(target)
        finally:
            target.close()
finally:
    source.close()
print(json.dumps({"integrity": "ok", "row_counts": counts}, indent=2, sort_keys=True))
PY
  if [[ -n "$backup" ]]; then
    docker cp "$UI_CONTAINER:$container_backup" "$backup" >/dev/null
  fi
}

restore_previous_ui() {
  local exit_code="$?"
  trap - ERR
  if [[ "$MUTATED" == "1" ]]; then
    echo "Candidate verification failed; restoring the previous UI image."
    cp -p "$EVIDENCE_DIR/env.before" "$ENV_FILE"
    docker-compose -p "$PROJECT" -f "$COMPOSE_FILE" config >/dev/null || true
    docker-compose -p "$PROJECT" -f "$COMPOSE_FILE" up -d --no-deps web-ui || true
  fi
  echo "Evidence preserved at $EVIDENCE_DIR" >&2
  exit "$exit_code"
}

[[ "$TARGET_ROOT" == "$EXPECTED_ROOT" ]] || fail "target root is not approved"
[[ -f "$COMPOSE_FILE" ]] || fail "target Compose file is missing"
[[ -f "$ENV_FILE" ]] || fail "target environment is missing"
[[ -f "$NEW_ENV_EXAMPLE" && -f "$NEW_MANIFEST" && -f "$NEW_IMAGE_LIST" ]] \
  || fail "release locks are missing"
for command in docker docker-compose python3 curl; do
  command -v "$command" >/dev/null 2>&1 || fail "required command is missing: $command"
done
cd "$TARGET_ROOT"

current_image="$(
  python3 - "$ENV_FILE" <<'PY'
from pathlib import Path
import sys

matches = [
    line.split("=", 1)[1]
    for line in Path(sys.argv[1]).read_text(encoding="utf-8").splitlines()
    if line.startswith("NO_SSO_UI_IMAGE=")
]
if len(matches) != 1:
    raise SystemExit("NO_SSO_UI_IMAGE must appear exactly once")
print(matches[0])
PY
)"
[[ "$current_image" == "$OLD_IMAGE" || "$current_image" == "$NEW_IMAGE" ]] \
  || fail "current UI image is outside the approved upgrade boundary"

all_containers=("$UI_CONTAINER" "${NON_UI_CONTAINERS[@]}")
for name in "${all_containers[@]}"; do
  [[ "$(docker inspect --format '{{index .Config.Labels "com.docker.compose.project"}}' "$name")" == "$PROJECT" ]] \
    || fail "container is not owned by the approved project: $name"
done

stamp="$(date -u +%Y%m%dT%H%M%SZ)"
EVIDENCE_DIR="$TARGET_ROOT/evidence/ui-refresh-$stamp"
mkdir -p "$EVIDENCE_DIR"
chmod 700 "$EVIDENCE_DIR"
cp -p "$ENV_FILE" "$EVIDENCE_DIR/env.before"
[[ ! -f "$TARGET_ROOT/.env.g5680a.no-sso-rag-v2.example" ]] \
  || cp -p \
    "$TARGET_ROOT/.env.g5680a.no-sso-rag-v2.example" \
    "$EVIDENCE_DIR/env-example.before"
[[ ! -f "$TARGET_ROOT/g5680a-no-sso-rag-v2-components.lock.json" ]] \
  || cp -p "$TARGET_ROOT/g5680a-no-sso-rag-v2-components.lock.json" "$EVIDENCE_DIR/manifest.before"
[[ ! -f "$TARGET_ROOT/image-list.no-sso-rag-v2.g5680a.txt" ]] \
  || cp -p "$TARGET_ROOT/image-list.no-sso-rag-v2.g5680a.txt" "$EVIDENCE_DIR/image-list.before"

snapshot_containers "$EVIDENCE_DIR/non-ui.before.json" "${NON_UI_CONTAINERS[@]}"
snapshot_containers "$EVIDENCE_DIR/ui.before.json" "$UI_CONTAINER"
python3 - "$EVIDENCE_DIR/non-ui.before.json" "$PROJECT" <<'PY'
import json
import sys

records = json.load(open(sys.argv[1], encoding="utf-8"))
project = sys.argv[2]
if len(records) != 6:
    raise SystemExit("expected six non-UI containers")
for record in records:
    if record["project"] != project or record["status"] != "running":
        raise SystemExit(f"control container is outside the release boundary: {record['name']}")
    if record["health"] and record["health"] != "healthy":
        raise SystemExit(f"control container is unhealthy: {record['name']}")
PY

docker exec "$UI_CONTAINER" test -f /data/hku_ui.sqlite3 \
  || fail "UI database is missing"
database_record \
  "$EVIDENCE_DIR/database.before.json" \
  "$EVIDENCE_DIR/hku_ui.sqlite3.before"

pulled=0
for attempt in 1 2 3 4 5; do
  if docker pull "$NEW_IMAGE"; then
    pulled=1
    break
  fi
  sleep "$((attempt * 3))"
done
[[ "$pulled" == "1" ]] || fail "unable to pull the candidate UI image"

docker image inspect "$NEW_IMAGE" | python3 -c '
import json
import sys

image = json.load(sys.stdin)[0]
if image["Id"] != sys.argv[1]:
    raise SystemExit("candidate image ID differs from the release lock")
if image["Os"] != "linux" or image["Architecture"] != "arm64":
    raise SystemExit("candidate image is not Linux ARM64")
if image["Config"].get("User") != "appuser":
    raise SystemExit("candidate image runtime user changed")
' "$NEW_IMAGE_ID"

python3 - "$ENV_FILE" "$OLD_IMAGE" "$NEW_IMAGE" <<'PY'
import os
import stat
import sys
import tempfile
from pathlib import Path

path = Path(sys.argv[1])
old_image = sys.argv[2]
new_image = sys.argv[3]
lines = path.read_text(encoding="utf-8").splitlines()
matches = [
    index for index, line in enumerate(lines) if line.startswith("NO_SSO_UI_IMAGE=")
]
if len(matches) != 1:
    raise SystemExit("NO_SSO_UI_IMAGE must appear exactly once")
index = matches[0]
current = lines[index].split("=", 1)[1]
if current not in {old_image, new_image}:
    raise SystemExit("current UI image is outside the approved upgrade boundary")
lines[index] = f"NO_SSO_UI_IMAGE={new_image}"
mode = stat.S_IMODE(path.stat().st_mode)
fd, temporary_name = tempfile.mkstemp(dir=path.parent, prefix=".env.ui-refresh.")
temporary = Path(temporary_name)
try:
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")
    temporary.chmod(mode)
    temporary.replace(path)
finally:
    temporary.unlink(missing_ok=True)
PY

MUTATED=1
trap restore_previous_ui ERR

docker-compose -p "$PROJECT" -f "$COMPOSE_FILE" config \
  > "$EVIDENCE_DIR/compose.rendered.txt"
docker-compose -p "$PROJECT" -f "$COMPOSE_FILE" up -d --no-deps web-ui

deadline=$((SECONDS + 120))
while true; do
  state="$(
    docker inspect "$UI_CONTAINER" | python3 -c '
import json
import sys

state = json.load(sys.stdin)[0]["State"]
print("{}|{}".format(state["Status"], state.get("Health", {}).get("Status", "")))
'
  )"
  [[ "$state" == "running|healthy" ]] && break
  (( SECONDS < deadline )) || fail "candidate UI did not become healthy"
  sleep 3
done

curl -fsS http://127.0.0.1:20180/healthz > "$EVIDENCE_DIR/ui-health.json"
curl -fsS http://127.0.0.1:20380/healthz > "$EVIDENCE_DIR/entrypoint-health.json"
curl -fsS http://127.0.0.1:20180/assets/app.js > "$EVIDENCE_DIR/ui-app.js"
python3 - "$EVIDENCE_DIR/ui-app.js" <<'PY'
import sys
from pathlib import Path

source = Path(sys.argv[1]).read_text(encoding="utf-8")
expected = (
    "I can help you compare course options, prerequisites, and enrollment steps. "
    "Please verify final decisions in SIS and official HKU sources."
)
if expected not in source:
    raise SystemExit("reviewed welcome message is absent from the candidate UI")
if "timetable conflicts" in source:
    raise SystemExit("removed welcome-message claim remains in the candidate UI")
PY

snapshot_containers "$EVIDENCE_DIR/non-ui.after.json" "${NON_UI_CONTAINERS[@]}"
snapshot_containers "$EVIDENCE_DIR/ui.after.json" "$UI_CONTAINER"
python3 - \
  "$EVIDENCE_DIR/non-ui.before.json" \
  "$EVIDENCE_DIR/non-ui.after.json" \
  "$EVIDENCE_DIR/ui.before.json" \
  "$EVIDENCE_DIR/ui.after.json" \
  "$NEW_IMAGE" \
  "$NEW_IMAGE_ID" <<'PY'
import json
import sys

before_controls = json.load(open(sys.argv[1], encoding="utf-8"))
after_controls = json.load(open(sys.argv[2], encoding="utf-8"))
before_ui = json.load(open(sys.argv[3], encoding="utf-8"))[0]
after_ui = json.load(open(sys.argv[4], encoding="utf-8"))[0]
new_image = sys.argv[5]
new_image_id = sys.argv[6]
if before_controls != after_controls:
    raise SystemExit("a non-UI container changed during the UI refresh")
if before_ui["mounts"] != after_ui["mounts"]:
    raise SystemExit("UI mounts changed during the UI refresh")
if after_ui["image_reference"] != new_image or after_ui["image_id"] != new_image_id:
    raise SystemExit("UI container does not use the locked candidate image")
if after_ui["status"] != "running" or after_ui["health"] != "healthy":
    raise SystemExit("UI container is not healthy after the refresh")
PY

database_record "$EVIDENCE_DIR/database.after.json"
python3 - "$EVIDENCE_DIR/database.before.json" "$EVIDENCE_DIR/database.after.json" <<'PY'
import json
import sys

before = json.load(open(sys.argv[1], encoding="utf-8"))
after = json.load(open(sys.argv[2], encoding="utf-8"))
if before != after:
    raise SystemExit("UI database row counts or integrity changed during the refresh")
PY

if [[ "$NEW_MANIFEST" != "$TARGET_ROOT/g5680a-no-sso-rag-v2-components.lock.json" ]]; then
  cp -p "$NEW_MANIFEST" "$TARGET_ROOT/g5680a-no-sso-rag-v2-components.lock.json"
fi
if [[ "$NEW_IMAGE_LIST" != "$TARGET_ROOT/image-list.no-sso-rag-v2.g5680a.txt" ]]; then
  cp -p "$NEW_IMAGE_LIST" "$TARGET_ROOT/image-list.no-sso-rag-v2.g5680a.txt"
fi
if [[ "$NEW_ENV_EXAMPLE" != "$TARGET_ROOT/.env.g5680a.no-sso-rag-v2.example" ]]; then
  cp -p "$NEW_ENV_EXAMPLE" "$TARGET_ROOT/.env.g5680a.no-sso-rag-v2.example"
fi
printf '%s\n' "$NEW_IMAGE" > "$EVIDENCE_DIR/applied-image.txt"
printf '%s\n' "passed" > "$EVIDENCE_DIR/result.txt"
trap - ERR

echo "UI refresh passed."
echo "Evidence: $EVIDENCE_DIR"
