# Protected non-SSO agent refresh

This package replaces only the compatible search API and application agent in
the existing `hku-no-sso-v3` lane on port `20380`. It does not recreate the
entrypoint, UI, vector services, or any authenticated lane. It additively
stages the qualified POC05 collection in the no-SSO lane-owned vector store.

## Release identity

- Release: `hku-no-sso-protected-agent-g5680a-2026.08.14.7`
- Supersedes: `.1` (irrelevant seed-directory preflight), `.2` (startup `503`
  escaped the bounded retry), `.3` (stale packaging tag), and `.4` (acceptance
  began before the healthy runtime had stabilized), and `.5` (the protected
  agent was incompatible with the older POC03 search API), and `.6` (POC05 was
  assumed present in the separate no-SSO vector store); do not deploy the
  superseded releases
- Parent: `hku-no-sso-poc03-family-uat-http-g5680a-2026.07.27.13+ui-2026.07.27.16`
- Target root: `/model/dockervolume/hku-custom-no-sso-v3`
- Compose project: `hku-no-sso-v3`
- Mutation boundary: `hku-no-sso-v3-search`, `hku-no-sso-v3-agent`
- Public authority: `planner.its.hku.hk`
- Public port: `20380`
- Qualified source lane: protected no-SSO `28480` on GB10

The protected image is digest-pinned for Linux ARM64 and was built with a
renamed application package, PyInstaller, a multi-stage container build,
application-source removal, and no dashboard.

The agent retains the live no-SSO lane's RAG URL and API key. The search and
agent are advanced together to the qualified POC05 contract because the
protected agent's course-search tool is not compatible with the older POC03
search API. The digest-pinned, previously qualified POC05 vector backup is
restored only when the collection is absent. The no-SSO vector container is not
recreated, and the authenticated lane's vector store is neither read nor
changed.

## Deployment

1. Read the local deployment playbook and compare it with a fresh read-only
   inventory.
2. Confirm the target root, project, parent image, mounts, listeners, and
   control lanes match the package contract.
3. Extract this archive outside the target root.
4. Run `./ApplyNoSSOProtectedAgentRefresh.sh`.
5. Open the canonical `planner.its.hku.hk` route and test timetable, curriculum,
   mixed, and nonexistent-course questions.

The apply script captures rollback state before mutation, validates the live
parent search and agent, pulls and verifies the approved agent, search, and
vector-seed images, verifies and additively restores POC05 into the lane-owned
store, recreates only `rag-api` and `agent-runtime`, and automatically restores
both application parents if qualification fails.

## Rollback

```bash
./RollbackNoSSOProtectedAgentRefresh.sh \
  /model/dockervolume/hku-custom-no-sso-v3/updates/<update-id>
```

Rollback restores the captured environment and parent search and agent, while
requiring all preserved target and control containers to remain unchanged.
The additive POC05 collection remains dormant for evidence and is not deleted.

## Deliberate exclusions

This is not an accuracy-tuning release. It does not alter the UI, ingress,
embedding endpoint, reranker, authentication, or scaling topology. It does not
modify or delete existing vector collections. Local playbooks, lane
registries, live secrets, and generated archives are excluded from the target
archive.
