#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ipaddress
import json
import socket
import subprocess
import tempfile
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from no_sso_target_config import (
    PORT_CONTRACT,
    VECTOR_ADDRESS_KEYS,
    read_env,
    require,
    update_env,
    validate_contract,
)


PROJECT = "hku-no-sso-v3"
SERVICES = {
    "hku-no-sso-v3-entrypoint": "host",
    "hku-no-sso-v3-ui": "host",
    "hku-no-sso-v3-agent": "host",
    "hku-no-sso-v3-search": "host",
    "hku-no-sso-v3-coordinator": "bridge",
    "hku-no-sso-v3-object": "bridge",
    "hku-no-sso-v3-vector": "bridge",
}
SEED_CONTAINER = "hku-no-sso-v3-poc05-seed"
TARGET_NAMES = set(SERVICES) | {SEED_CONTAINER}
PORT_OWNERS = {
    "NO_SSO_ENTRYPOINT_PORT": "hku-no-sso-v3-entrypoint",
    "NO_SSO_UI_HOST_PORT": "hku-no-sso-v3-ui",
    "NO_SSO_AGENT_HOST_PORT": "hku-no-sso-v3-agent",
    "NO_SSO_RAG_HOST_PORT": "hku-no-sso-v3-search",
}
IMAGE_OWNERS = {
    "hku-no-sso-v3-entrypoint": "NO_SSO_PROXY_IMAGE",
    "hku-no-sso-v3-ui": "NO_SSO_UI_IMAGE",
    "hku-no-sso-v3-agent": "NO_SSO_AGENT_IMAGE",
    "hku-no-sso-v3-search": "NO_SSO_RAG_IMAGE",
    "hku-no-sso-v3-coordinator": "NO_SSO_ETCD_IMAGE",
    "hku-no-sso-v3-object": "NO_SSO_MINIO_IMAGE",
    "hku-no-sso-v3-vector": "NO_SSO_MILVUS_IMAGE",
}
VECTOR_ADDRESS_OWNERS = {
    "NO_SSO_VECTOR_COORDINATOR_ADDRESS": "hku-no-sso-v3-coordinator",
    "NO_SSO_VECTOR_OBJECT_ADDRESS": "hku-no-sso-v3-object",
    "NO_SSO_VECTOR_ENGINE_ADDRESS": "hku-no-sso-v3-vector",
}
HOST_LISTENER_ADDRESSES = {
    "NO_SSO_ENTRYPOINT_PORT": "0.0.0.0",
    "NO_SSO_UI_HOST_PORT": "127.0.0.1",
    "NO_SSO_AGENT_HOST_PORT": "127.0.0.1",
    "NO_SSO_RAG_HOST_PORT": "127.0.0.1",
}

CONTAINER_LISTENER_PROBE = r'''
port_hex="$(printf '%04X' "$1")"
inodes="$(awk -v port="$port_hex" '
  NR > 1 {
    split($2, endpoint, ":")
    if (toupper(endpoint[2]) == port && $4 == "0A") print $10
  }
' /proc/net/tcp /proc/net/tcp6 2>/dev/null)"
[ -n "$inodes" ] || exit 3
for process in /proc/[0-9]*; do
  [ -d "$process/fd" ] || continue
  for descriptor in "$process"/fd/*; do
    target="$(readlink "$descriptor" 2>/dev/null || true)"
    for inode in $inodes; do
      [ "$target" = "socket:[$inode]" ] && exit 0
    done
  done
done
exit 4
'''


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def run(*command: str, check: bool = True) -> str:
    result = subprocess.run(command, check=False, capture_output=True, text=True)
    if check and result.returncode != 0:
        detail = result.stderr.strip() or result.stdout.strip() or f"exit {result.returncode}"
        fail(f"{' '.join(command[:3])} failed: {detail}")
    return result.stdout


def inspect_raw(name: str) -> dict[str, Any] | None:
    raw = run("docker", "inspect", name, check=False).strip()
    if not raw:
        return None
    items = json.loads(raw)
    if not items:
        return None
    if not isinstance(items, list) or len(items) != 1:
        fail(f"docker inspect returned an unexpected result for {name}")
    return items[0]


def normalized_container(name: str) -> dict[str, Any] | None:
    item = inspect_raw(name)
    if item is None:
        return None
    state = item.get("State") or {}
    config = item.get("Config") or {}
    labels = config.get("Labels") or {}
    network = item.get("NetworkSettings") or {}
    return {
        "id": item.get("Id", ""),
        "image_id": item.get("Image", ""),
        "state": state.get("Status", ""),
        "health": (state.get("Health") or {}).get("Status", "none"),
        "started_at": state.get("StartedAt", ""),
        "restart_count": item.get("RestartCount", 0),
        "project": labels.get("com.docker.compose.project", ""),
        "network_mode": (item.get("HostConfig") or {}).get("NetworkMode", ""),
        "pid_mode": (item.get("HostConfig") or {}).get("PidMode", ""),
        "ports": network.get("Ports") or {},
        "mounts": sorted(
            (
                {
                    "source": mount.get("Source", ""),
                    "destination": mount.get("Destination", ""),
                    "read_write": bool(mount.get("RW")),
                }
                for mount in item.get("Mounts") or []
            ),
            key=lambda value: (value["destination"], value["source"]),
        ),
    }


def all_existing_controls() -> dict[str, Any]:
    names = run("docker", "ps", "-a", "--format", "{{.Names}}").splitlines()
    return {
        name: inspected
        for name in sorted(names)
        if name not in TARGET_NAMES and (inspected := normalized_container(name)) is not None
    }


def health(url: str) -> dict[str, Any]:
    try:
        with urllib.request.urlopen(url, timeout=10) as response:
            body = response.read()
            return {"status": response.status, "bytes": len(body)}
    except (urllib.error.URLError, TimeoutError) as exc:
        fail(f"control endpoint is unavailable: {url}: {exc}")


def control_urls(values: dict[str, str]) -> tuple[str, ...]:
    return tuple(item.strip() for item in require(values, "NO_SSO_CONTROL_URLS").split(",") if item.strip())


def port_is_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind(("0.0.0.0", port))
        except OSError:
            return False
    return True


def tcp_listener_addresses(port: int) -> set[str]:
    result = subprocess.run(
        ("ss", "-H", "-ltn"),
        check=False,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        detail = result.stderr.strip() or result.stdout.strip() or f"exit {result.returncode}"
        fail(f"unable to inspect TCP listeners: {detail}")
    addresses: set[str] = set()
    for line in result.stdout.splitlines():
        fields = line.split()
        if len(fields) < 4:
            continue
        address, candidate_port = fields[3].rsplit(":", 1)
        if candidate_port == str(port):
            addresses.add(address.strip("[]"))
    return addresses


def container_owns_listener(name: str, port: int) -> bool:
    result = subprocess.run(
        (
            "docker",
            "exec",
            name,
            "sh",
            "-c",
            CONTAINER_LISTENER_PROBE,
            "listener-probe",
            str(port),
        ),
        check=False,
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        return True
    if result.returncode in {3, 4}:
        return False
    detail = result.stderr.strip() or result.stdout.strip() or f"exit {result.returncode}"
    fail(f"unable to inspect listener ownership in {name}: {detail}")


def has_published_ports(item: dict[str, Any]) -> bool:
    bindings = (item.get("HostConfig") or {}).get("PortBindings") or {}
    if bindings:
        return True
    ports = (item.get("NetworkSettings") or {}).get("Ports") or {}
    return any(bool(value) for value in ports.values())


def container_ipv4(item: dict[str, Any], name: str) -> str:
    networks = (item.get("NetworkSettings") or {}).get("Networks") or {}
    addresses = sorted(
        value.get("IPAddress", "")
        for value in networks.values()
        if value.get("IPAddress")
    )
    if len(addresses) != 1:
        fail(f"expected one private bridge address for {name}; found {addresses}")
    try:
        address = ipaddress.ip_address(addresses[0])
    except ValueError:
        fail(f"invalid bridge address for {name}: {addresses[0]}")
    if not isinstance(address, ipaddress.IPv4Address) or not address.is_private or address.is_loopback:
        fail(f"bridge address is not a private non-loopback IPv4 address for {name}: {address}")
    return str(address)


def image_id(reference: str) -> str:
    return run("docker", "image", "inspect", reference, "--format", "{{.Id}}", check=False).strip()


def preflight(root: Path, env_path: Path) -> None:
    values = read_env(env_path)
    validate_contract(values, root=root)
    for name, expected_mode in SERVICES.items():
        item = inspect_raw(name)
        if item is None:
            continue
        labels = (item.get("Config") or {}).get("Labels") or {}
        if labels.get("com.docker.compose.project") != PROJECT:
            fail(f"target container name belongs to another project: {name}")
        actual_mode = (item.get("HostConfig") or {}).get("NetworkMode", "")
        if expected_mode == "host" and actual_mode != "host":
            fail(f"existing target container has the wrong network mode: {name}")
        if expected_mode == "bridge" and actual_mode not in {"bridge", "default"}:
            fail(f"existing target container has the wrong network mode: {name}")
        if expected_mode == "bridge" and has_published_ports(item):
            fail(f"private vector dependency publishes a host port: {name}")

    seed = inspect_raw(SEED_CONTAINER)
    if seed is not None:
        expected_image_id = image_id(require(values, "NO_SSO_VECTOR_SEED_IMAGE"))
        if not expected_image_id or seed.get("Image") != expected_image_id:
            fail("existing vector seed container does not match the release image")

    for key in PORT_CONTRACT:
        port = int(require(values, key))
        if port_is_free(port):
            continue
        owner_name = PORT_OWNERS[key]
        raw_owner = inspect_raw(owner_name)
        owner = normalized_container(owner_name)
        if raw_owner is None or owner is None or owner.get("project") != PROJECT:
            fail(f"target port is occupied outside {PROJECT}: {port}")
        if owner.get("state") != "running":
            fail(f"target port is occupied while its expected owner is stopped: {port}")
        expected_address = HOST_LISTENER_ADDRESSES[key]
        if owner.get("network_mode") != "host" or owner.get("pid_mode") == "host":
            fail(f"cannot prove host listener ownership for {owner_name}")
        addresses = tcp_listener_addresses(port)
        if addresses != {expected_address}:
            fail(f"target port {port} has unexpected bind addresses: {sorted(addresses)}")
        if not container_owns_listener(owner_name, port):
            fail(f"target port {port} is not owned by {owner_name}")

    for key, name in VECTOR_ADDRESS_OWNERS.items():
        item = inspect_raw(name)
        expected_address = require(values, key)
        if item is None:
            if expected_address != "AUTO":
                fail(f"{key} is resolved but its target container is absent")
            continue
        state = (item.get("State") or {}).get("Status", "")
        if state == "running":
            actual_address = container_ipv4(item, name)
            if expected_address not in {"AUTO", actual_address}:
                fail(f"{key} does not match {name}: {expected_address} != {actual_address}")
    for url in control_urls(values):
        if health(url)["status"] != 200:
            fail(f"control endpoint did not return 200: {url}")
    print("no-SSO target preflight ok")


def sync_vector_addresses(env_path: Path) -> None:
    replacements: dict[str, str] = {}
    for key, name in VECTOR_ADDRESS_OWNERS.items():
        item = inspect_raw(name)
        if item is None:
            fail(f"private vector dependency is missing: {name}")
        labels = (item.get("Config") or {}).get("Labels") or {}
        host = item.get("HostConfig") or {}
        if labels.get("com.docker.compose.project") != PROJECT:
            fail(f"private vector dependency belongs to another project: {name}")
        if (item.get("State") or {}).get("Status") != "running":
            fail(f"private vector dependency is not running: {name}")
        if host.get("NetworkMode") not in {"bridge", "default"}:
            fail(f"private vector dependency left the default bridge: {name}")
        if has_published_ports(item):
            fail(f"private vector dependency publishes a host port: {name}")
        replacements[key] = container_ipv4(item, name)
    if len(set(replacements.values())) != len(replacements):
        fail("private vector dependencies do not have unique bridge addresses")
    update_env(env_path, replacements)
    print("private vector dependency addresses synchronized")


def capture(path: Path, env_path: Path) -> None:
    values = read_env(env_path)
    payload = {
        "schema_version": 1,
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "containers": all_existing_controls(),
        "health": {url: health(url) for url in control_urls(values)},
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as stream:
        json.dump(payload, stream, indent=2, sort_keys=True)
        stream.write("\n")
        temporary = Path(stream.name)
    temporary.chmod(0o600)
    temporary.replace(path)
    print(f"control snapshot written: {path}")


def compare(path: Path, env_path: Path) -> None:
    before = json.loads(path.read_text(encoding="utf-8"))
    after = all_existing_controls()
    values = read_env(env_path)
    errors: list[str] = []
    for name, expected in before["containers"].items():
        actual = after.get(name)
        if actual is None:
            errors.append(f"existing container disappeared: {name}")
        elif actual != expected:
            errors.append(f"existing container changed: {name}")
    for url in control_urls(values):
        if health(url)["status"] != 200:
            errors.append(f"control endpoint is unhealthy: {url}")
    if errors:
        fail("; ".join(errors))
    print("all pre-existing containers and control endpoints are unchanged")


def verify_target(root: Path, env_path: Path) -> None:
    values = read_env(env_path)
    validate_contract(values, root=root)
    errors: list[str] = []
    for name, expected_mode in SERVICES.items():
        item = inspect_raw(name)
        if item is None:
            errors.append(f"target container is missing: {name}")
            continue
        state = item.get("State") or {}
        labels = (item.get("Config") or {}).get("Labels") or {}
        host = item.get("HostConfig") or {}
        mode = host.get("NetworkMode", "")
        expected_image_id = image_id(require(values, IMAGE_OWNERS[name]))
        if state.get("Status") != "running":
            errors.append(f"target container is not running: {name}")
        health_status = (state.get("Health") or {}).get("Status", "none")
        if health_status not in {"healthy", "none"}:
            errors.append(f"target container health is {health_status}: {name}")
        if labels.get("com.docker.compose.project") != PROJECT:
            errors.append(f"target project label changed: {name}")
        if not expected_image_id or item.get("Image") != expected_image_id:
            errors.append(f"target image identity changed: {name}")
        if host.get("RestartPolicy", {}).get("Name") != "unless-stopped":
            errors.append(f"restart policy changed: {name}")
        if expected_mode == "host" and mode != "host":
            errors.append(f"host-network boundary changed: {name}")
        if expected_mode == "bridge" and mode not in {"bridge", "default"}:
            errors.append(f"default-bridge boundary changed: {name}")

        owned_port_keys = [key for key, owner in PORT_OWNERS.items() if owner == name]
        if expected_mode == "host":
            if host.get("PidMode", "") == "host":
                errors.append(f"host PID mode prevents listener ownership proof: {name}")
            for key in owned_port_keys:
                port = int(require(values, key))
                addresses = tcp_listener_addresses(port)
                if addresses != {HOST_LISTENER_ADDRESSES[key]}:
                    errors.append(f"host listener address changed: {name}: {sorted(addresses)}")
                elif not container_owns_listener(name, port):
                    errors.append(f"host listener is not owned by target container: {name}: {port}")
        elif has_published_ports(item):
            errors.append(f"private vector dependency publishes a host port: {name}")

        for mount in item.get("Mounts") or []:
            source = Path(mount.get("Source", "")).resolve()
            try:
                source.relative_to(root.resolve())
            except ValueError:
                errors.append(f"mount escapes the target root: {name}: {source}")
        if expected_mode == "bridge":
            address_key = next(
                key for key, owner in VECTOR_ADDRESS_OWNERS.items() if owner == name
            )
            actual_address = container_ipv4(item, name)
            if require(values, address_key) != actual_address:
                errors.append(f"private bridge address changed: {name}: {actual_address}")
    if errors:
        fail("; ".join(errors))
    print("no-SSO target ownership, persistence, and network boundaries verified")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--env", type=Path, default=Path.cwd() / ".env")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("preflight")
    capture_parser = subparsers.add_parser("capture")
    capture_parser.add_argument("--output", type=Path, required=True)
    compare_parser = subparsers.add_parser("compare")
    compare_parser.add_argument("--before", type=Path, required=True)
    subparsers.add_parser("verify-target")
    subparsers.add_parser("sync-vector-addresses")
    args = parser.parse_args()
    if args.command == "preflight":
        preflight(args.root, args.env)
    elif args.command == "capture":
        capture(args.output, args.env)
    elif args.command == "compare":
        compare(args.before, args.env)
    elif args.command == "verify-target":
        verify_target(args.root, args.env)
    else:
        sync_vector_addresses(args.env)


if __name__ == "__main__":
    main()
