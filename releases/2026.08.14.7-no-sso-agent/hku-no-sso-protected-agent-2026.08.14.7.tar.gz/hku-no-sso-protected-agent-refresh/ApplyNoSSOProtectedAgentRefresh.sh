#!/usr/bin/env bash
set -Eeuo pipefail

PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET_ROOT="/model/dockervolume/hku-custom-no-sso-v3"
PROJECT="hku-no-sso-v3"
CONTRACT="$PACKAGE_ROOT/.env.g5680a.no-sso-protected-agent.example"
OVERRIDE="$PACKAGE_ROOT/compose.no-sso-protected-agent.override.yml"
BASE_COMPOSE="$TARGET_ROOT/compose.no-sso-rag-v2.g5680a.yml"
RELEASE_ID="$(awk -F= '$1 == "REFRESH_RELEASE_ID" {print $2}' "$CONTRACT")"
UPDATE_ID="${NO_SSO_PROTECTED_AGENT_UPDATE_ID:-$(date -u +%Y%m%dT%H%M%SZ)-protected-agent}"
UPDATE_DIR="$TARGET_ROOT/updates/$UPDATE_ID"
COMPOSE=(
  "$PACKAGE_ROOT/scripts/compose_no_sso.sh"
  -p "$PROJECT"
  -f "$BASE_COMPOSE"
  -f "$OVERRIDE"
)
READINESS_SOAK_SECONDS="20"

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

contract_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' "$CONTRACT"
}

wait_healthy() {
  local container="$1"
  local state=""
  for _ in $(seq 1 90); do
    state="$(docker inspect "$container" --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' 2>/dev/null || true)"
    [[ "$state" == "healthy" ]] && return 0
    sleep 2
  done
  fail "candidate container did not become healthy: $container"
}

pull_image() {
  local reference="$1"
  local expected_id="$2"
  local tag_reference="${reference%@sha256:*}"
  local pinned_id=""
  local tagged_id=""
  [[ "$reference" == *@sha256:* ]] || fail "candidate image is not digest-pinned"
  for attempt in $(seq 1 5); do
    if docker pull "$reference"; then
      pinned_id="$(docker image inspect "$reference" --format '{{.Id}}')"
      docker tag "$reference" "$tag_reference"
      tagged_id="$(docker image inspect "$tag_reference" --format '{{.Id}}')"
      [[ -n "$pinned_id" && "$tagged_id" == "$pinned_id" ]] \
        || fail "candidate tag does not resolve to the approved digest"
      [[ "$pinned_id" == "$expected_id" ]] \
        || fail "candidate image ID differs from the GB10-qualified artifact"
      return 0
    fi
    sleep "$((attempt * 5))"
  done
  fail "candidate image pull failed"
}

[[ "$RELEASE_ID" == "hku-no-sso-protected-agent-g5680a-2026.08.14.7" ]] \
  || fail "release identity changed"
[[ "$(cd "$TARGET_ROOT" && pwd -P)" == "$TARGET_ROOT" ]] || fail "target root changed"
[[ ! -L "$TARGET_ROOT" ]] || fail "target root must not be a symbolic link"
[[ -f "$TARGET_ROOT/.env" && -f "$BASE_COMPOSE" ]] || fail "live release contract is incomplete"
[[ -f "$CONTRACT" && -f "$OVERRIDE" ]] || fail "candidate package is incomplete"
[[ ! -e "$UPDATE_DIR" ]] || fail "update evidence directory already exists"

mkdir -p "$UPDATE_DIR"
chmod 700 "$UPDATE_DIR"
cp "$TARGET_ROOT/.env" "$UPDATE_DIR/before.env"
cp "$BASE_COMPOSE" "$UPDATE_DIR/compose.before.yml"
chmod 600 "$UPDATE_DIR/before.env" "$UPDATE_DIR/compose.before.yml"

python3 "$PACKAGE_ROOT/scripts/no_sso_agent_refresh_control.py" \
  capture --output "$UPDATE_DIR/agent-refresh-before.json"
python3 "$PACKAGE_ROOT/scripts/no_sso_agent_refresh_control.py" \
  validate-parent \
  --snapshot "$UPDATE_DIR/agent-refresh-before.json" \
  --live-env "$UPDATE_DIR/before.env"
python3 "$PACKAGE_ROOT/scripts/no_sso_agent_refresh_control.py" \
  make-candidate \
  --live "$UPDATE_DIR/before.env" \
  --contract "$CONTRACT" \
  --output "$UPDATE_DIR/candidate.env"
python3 "$PACKAGE_ROOT/scripts/no_sso_target_control.py" \
  --root "$TARGET_ROOT" --env "$UPDATE_DIR/candidate.env" \
  capture --output "$UPDATE_DIR/control-before.json"

pull_image \
  "$(contract_value REFRESH_CANDIDATE_SEARCH_IMAGE)" \
  "$(contract_value REFRESH_CANDIDATE_SEARCH_IMAGE_ID)"
pull_image \
  "$(contract_value REFRESH_CANDIDATE_AGENT_IMAGE)" \
  "$(contract_value REFRESH_CANDIDATE_AGENT_IMAGE_ID)"
pull_image \
  "$(contract_value REFRESH_CANDIDATE_VECTOR_SEED_IMAGE)" \
  "$(contract_value REFRESH_CANDIDATE_VECTOR_SEED_IMAGE_ID)"

NO_SSO_ENV_FILE="$UPDATE_DIR/candidate.env" \
NO_SSO_OPERATION_EVIDENCE_DIR="$UPDATE_DIR" \
  "$PACKAGE_ROOT/StagePOC05.sh"
NO_SSO_ENV_FILE="$UPDATE_DIR/candidate.env" \
NO_SSO_OPERATION_EVIDENCE_DIR="$UPDATE_DIR" \
NO_SSO_OPERATION_RUNTIME_DIR="$UPDATE_DIR/runtime" \
  "$PACKAGE_ROOT/RestorePOC05.sh"

temporary="$(mktemp "$TARGET_ROOT/.env.candidate.XXXXXX")"
cp "$UPDATE_DIR/candidate.env" "$temporary"
chmod 600 "$temporary"
mv "$temporary" "$TARGET_ROOT/.env"

rollback_on_error() {
  local status=$?
  trap - EXIT INT TERM
  "$PACKAGE_ROOT/RollbackNoSSOProtectedAgentRefresh.sh" "$UPDATE_DIR" || true
  exit "$status"
}
trap rollback_on_error EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

cd "$TARGET_ROOT"
cmp -s "$UPDATE_DIR/compose.before.yml" "$BASE_COMPOSE" \
  || fail "live base Compose file drifted after capture"
"${COMPOSE[@]}" config >/dev/null
"${COMPOSE[@]}" up -d --no-deps --force-recreate rag-api
wait_healthy hku-no-sso-v3-search
"${COMPOSE[@]}" up -d --no-deps --force-recreate agent-runtime
wait_healthy hku-no-sso-v3-agent
sleep "$READINESS_SOAK_SECONDS"

"$PACKAGE_ROOT/CheckNoSSOProtectedAgentRefresh.sh" "$UPDATE_DIR"
printf '%s\n' "ACTIVE $RELEASE_ID $UPDATE_DIR" \
  > "$UPDATE_DIR/deployment-status.txt"
chmod 600 "$UPDATE_DIR/deployment-status.txt"
trap - EXIT INT TERM
echo "Protected no-SSO search and agent refresh applied and verified: $UPDATE_DIR"
