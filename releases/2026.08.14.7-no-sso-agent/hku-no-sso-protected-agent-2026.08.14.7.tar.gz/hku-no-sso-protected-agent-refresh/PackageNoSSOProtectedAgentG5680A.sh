#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

release_tag="$(awk -F= '$1 == "REFRESH_RELEASE_ID" {print $2; exit}' \
  .env.g5680a.no-sso-protected-agent.example)"
version="${release_tag##*-}"
[[ "$release_tag" == "hku-no-sso-protected-agent-g5680a-$version" ]] \
  || { echo "ERROR: Invalid release identity: $release_tag" >&2; exit 1; }
if [[ "$#" -gt 0 && "$1" != "$version" ]]; then
  echo "ERROR: This packager is locked to release $version." >&2
  exit 1
fi
archive="hku-no-sso-protected-agent-${version}.tar.gz"
release_dir="$ROOT/release"

[[ -z "$(git status --porcelain)" ]] \
  || { echo "ERROR: Refusing to package a dirty worktree." >&2; exit 1; }
[[ "$(git rev-parse HEAD)" == "$(git rev-parse "${release_tag}^{commit}")" ]] \
  || { echo "ERROR: HEAD must be the exact $release_tag release commit." >&2; exit 1; }
python3 scripts/verify_no_sso_protected_agent_release.py --root "$ROOT"

files=(
  .env.g5680a.no-sso-protected-agent.example
  ApplyNoSSOProtectedAgentRefresh.sh
  CheckNoSSOProtectedAgentRefresh.sh
  DEPLOY_G5680A_NO_SSO_PROTECTED_AGENT.md
  PackageNoSSOProtectedAgentG5680A.sh
  RestorePOC05.sh
  RollbackNoSSOProtectedAgentRefresh.sh
  StagePOC05.sh
  THIRD_PARTY_NOTICES_NO_SSO_PROTECTED_AGENT.md
  compose.no-sso-protected-agent.override.yml
  image-list.no-sso-protected-agent.g5680a.txt
  no-sso-protected-agent-refresh.lock.json
  scripts/compose_no_sso.sh
  scripts/no_sso_agent_refresh_control.py
  scripts/no_sso_target_config.py
  scripts/no_sso_target_control.py
  scripts/verify_vector_seed.py
  scripts/verify_no_sso_protected_agent_release.py
  tests/e2e_no_sso_protected_agent.py
)

mkdir -p "$release_dir"
git archive --format=tar --prefix=hku-no-sso-protected-agent-refresh/ "$release_tag" -- "${files[@]}" \
  | gzip -n -9 > "$release_dir/$archive"

if command -v sha256sum >/dev/null 2>&1; then
  (cd "$release_dir" && sha256sum "$archive" > "$archive.sha256")
else
  digest="$(shasum -a 256 "$release_dir/$archive" | awk '{print $1}')"
  printf '%s  %s\n' "$digest" "$archive" > "$release_dir/$archive.sha256"
fi

echo "$release_dir/$archive"
echo "$release_dir/$archive.sha256"
