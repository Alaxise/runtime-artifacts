#!/usr/bin/env bash
set -euo pipefail

SCRIPT_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
TARGET_ROOT="${1:-/model/dockervolume/hku-custom-no-sso-v3}"
EXPECTED_ROOT="/model/dockervolume/hku-custom-no-sso-v3"
PROJECT="hku-no-sso-v3"
COMPOSE_FILE="$TARGET_ROOT/compose.no-sso-rag-v2.g5680a.yml"
ENV_FILE="$TARGET_ROOT/.env"

OLD_PROXY_IMAGES=(
  "nginx:1.27-alpine@sha256:65645c7bb6a0661892a8b03b89d0743208a18dd2f3f17a54ef4b76fb8e2f2a10"
  "nginx:1.30.4-alpine@sha256:97d490c12ba55b4946b01546d1c3ed324e8d41ab1c9fcb2a616aa470620e5b46"
)
OLD_UI_IMAGES=(
  "middletaste/hku-custom-web:no-sso-v2-d6620b808330-arm64@sha256:db3a35c168d9fb729348f8bdcde1feca734c88e0f532ca6a647eabbd07d14b66"
  "middletaste/hku-custom-web:no-sso-v3-f0d66beec43d-arm64@sha256:f068dd8e855ea40b929f3ee9cb79ca5ea937063f3a80ee459e06d57219ec924b"
  "middletaste/hku-custom-web:no-sso-v4-59c237429d40-arm64@sha256:6122a3755092c4f28143b9ec50b0c831705aee0e6f31d290206df269a96204df"
)
OLD_AGENT_IMAGES=(
  "middletaste/hku-custom-core:no-sso-v2-37162016e4ca-arm64@sha256:628c4a7e7fdc4766c094bfd32928eb72a57658e3f9e15fa3f899d9b3d44f3449"
  "middletaste/hku-custom-core:poc03-latest-942fed8-arm64@sha256:9ba0344a7efa8aa38d2f1cf426c5ecbe4cb9a3d13f9ca33a269dc43d2ada3c5a"
  "middletaste/hku-custom-core:poc03-family-d38e4bf-arm64@sha256:f3c8e9dbf105ae61a988fd29f26172cc5a431badd35727829e19fe281b1fceab"
  "middletaste/hku-custom-core:poc03-family-f05cc96e5106-arm64@sha256:5faab8a03368a2ab2e980e106de42f480095e714e7db7ce90b49b5c95e8b5e36"
)
OLD_RAG_IMAGES=(
  "middletaste/hku-custom-search:no-sso-v2-d13b3054f68d-arm64@sha256:c5cde614860ef5abce423e31bf86015df4304b1f9bf1b6a8010950a610dc5d53"
  "middletaste/hku-custom-search:poc03-latest-20bab76-arm64@sha256:1123d1d1a92b85fc602472951d6d1e0e0cd1f31468b122f78625d9838c131692"
  "middletaste/hku-custom-search:poc03-family-bfd6e8c-arm64@sha256:e84172e5b05085b79d0ba5f8012aef7012275710c47c359771c222e184f34105"
)

NEW_PROXY_IMAGE="nginx:1.30.4-alpine@sha256:97d490c12ba55b4946b01546d1c3ed324e8d41ab1c9fcb2a616aa470620e5b46"
NEW_UI_IMAGE="middletaste/hku-custom-web:no-sso-v4-f6bc882bfde8-arm64@sha256:7da63e25d5a9edb7260c4ab6aa699d02f445372b228a96b6fae3288d19e38fb3"
NEW_AGENT_IMAGE="middletaste/hku-custom-core:poc03-family-f05cc96e5106-arm64@sha256:5faab8a03368a2ab2e980e106de42f480095e714e7db7ce90b49b5c95e8b5e36"
NEW_RAG_IMAGE="middletaste/hku-custom-search:poc03-family-bfd6e8c-arm64@sha256:e84172e5b05085b79d0ba5f8012aef7012275710c47c359771c222e184f34105"
NEW_PROXY_IMAGE_IDS=(
  "sha256:cf0b9341d232ba527fecfbf887d8515a80d5012e04cb044799f71240c2ee35b1"
  "sha256:d64d001f60e9a65d45980907e9070fc46d418980f311052e73c0df2eccc3cc30"
)
NEW_UI_IMAGE_ID="sha256:f4595e72493d8a70cf9ca9e5d999a5b52f3501503b615c0f220db5501bf53123"
NEW_AGENT_IMAGE_ID="sha256:6d6b7a617da61d6883fa0f2b194e920ef66dc9f986d0ce19c6064a3f994db7d4"
NEW_RAG_IMAGE_ID="sha256:c95262c8b4bc4a0a9d0a7dfac4e8f66e440e27797d95186cf14dd4c772a4a5f9"
NEW_VECTOR_SEED_IMAGE="middletaste/hku-custom-vector-seed:poc03-family-20260725T163343Z-arm64@sha256:c829eb3fcf6a59bbc5702f7eb68833850605aaa45bbf2472d7a9758c4c9f3174"
NEW_VECTOR_SEED_IMAGE_ID="sha256:78819d57fb2dd8bd8161067a79197d0cfaf1e4629f491c43a3deee688804847a"
NEW_COLLECTION="DATASET_HKU_GB10_POC_03_LATEST_FAMILY_V1"
NEW_BACKUP_NAME="hku_poc03_family_20260725T163343Z"
NEW_BACKUP_SHA256="e719a441ccf7f939464d88615270c197611b89c53dfaf6d8d6aaee50e4dc1252"
NEW_SEED_CONTAINER="hku-no-sso-v3-seed-family"
NEW_VECTOR_SEED_ROOT="$TARGET_ROOT/runtime/vector-seed-family"
NEW_MANIFEST="$SCRIPT_ROOT/g5680a-no-sso-rag-v2-components.lock.json"
NEW_IMAGE_LIST="$SCRIPT_ROOT/image-list.no-sso-rag-v2.g5680a.txt"

PRESERVED_CONTAINERS=(
  hku-no-sso-v3-coordinator
  hku-no-sso-v3-object
  hku-no-sso-v3-vector
)
APPLICATION_CONTAINERS=(
  hku-no-sso-v3-entrypoint
  hku-no-sso-v3-ui
  hku-no-sso-v3-agent
  hku-no-sso-v3-search
)
RELEASE_FILES=(
  CheckNoSSOG5680A.sh
  compose.no-sso-rag-v2.g5680a.yml
  entrypoint/no-sso.g5680a.template.conf
  g5680a-no-sso-rag-v2-components.lock.json
  image-list.no-sso-rag-v2.g5680a.txt
  scripts/no_sso_target_config.py
  scripts/no_sso_target_control.py
  scripts/verify_no_sso_ingress.py
)

MUTATED=0

fail() {
  echo "ERROR: $*" >&2
  return 1
}

env_value() {
  local key="$1"
  awk -F= -v key="$key" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' "$ENV_FILE"
}

contains_value() {
  local candidate="$1"
  shift
  local value
  for value in "$@"; do
    [[ "$candidate" == "$value" ]] && return 0
  done
  return 1
}

wait_http() {
  local url="$1"
  local label="$2"
  local deadline=$((SECONDS + 180))
  until curl -fsS "$url" >/dev/null 2>&1; do
    (( SECONDS < deadline )) || fail "$label did not become ready: $url"
    sleep 3
  done
}

snapshot_containers() {
  local output="$1"
  shift
  docker inspect "$@" | python3 -c '
import json
import sys

records = []
for item in json.load(sys.stdin):
    state = item["State"]
    records.append(
        {
            "name": item["Name"].lstrip("/"),
            "id": item["Id"],
            "image_reference": item["Config"]["Image"],
            "image_id": item["Image"],
            "status": state["Status"],
            "health": (state.get("Health") or {}).get("Status", ""),
            "project": (item["Config"].get("Labels") or {}).get(
                "com.docker.compose.project", ""
            ),
            "mounts": sorted(
                (
                    mount["Type"],
                    mount["Source"],
                    mount["Destination"],
                    bool(mount["RW"]),
                )
                for mount in item.get("Mounts", [])
            ),
        }
    )
json.dump(sorted(records, key=lambda value: value["name"]), sys.stdout, indent=2)
sys.stdout.write("\n")
' > "$output"
}

database_record() {
  local database="$1"
  local output="$2"
  local backup="${3:-}"
  python3 - "$database" "$output" "$backup" <<'PY'
import json
import sqlite3
import sys
from pathlib import Path

database = Path(sys.argv[1])
output = Path(sys.argv[2])
backup = Path(sys.argv[3]) if sys.argv[3] else None
source = sqlite3.connect(f"file:{database}?mode=ro", uri=True)
try:
    integrity = source.execute("PRAGMA integrity_check").fetchone()[0]
    if integrity != "ok":
        raise SystemExit(f"SQLite integrity check failed: {integrity}")
    tables = [
        row[0]
        for row in source.execute(
            "SELECT name FROM sqlite_master "
            "WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
        )
    ]
    counts = {}
    for table in tables:
        quoted = '"' + table.replace('"', '""') + '"'
        counts[table] = source.execute(f"SELECT COUNT(*) FROM {quoted}").fetchone()[0]
    if backup is not None:
        target = sqlite3.connect(backup)
        try:
            source.backup(target)
        finally:
            target.close()
finally:
    source.close()
output.write_text(
    json.dumps({"integrity": "ok", "row_counts": counts}, indent=2, sort_keys=True)
    + "\n",
    encoding="utf-8",
)
PY
}

pull_image() {
  local image="$1"
  local attempt
  for attempt in 1 2 3 4 5; do
    docker pull "$image" && return 0
    sleep "$((attempt * 5))"
  done
  fail "unable to pull locked image: $image"
}

verify_image() {
  local image="$1"
  local image_id="$2"
  local runtime_user="$3"
  docker image inspect "$image" | python3 -c '
import json
import sys

expected_id = sys.argv[1]
expected_user = sys.argv[2]
item = json.load(sys.stdin)[0]
if item["Id"] != expected_id:
    raise SystemExit("image ID differs from the release lock")
if item["Os"] != "linux" or item["Architecture"] != "arm64":
    raise SystemExit("image is not Linux ARM64")
if expected_user != "-" and item["Config"].get("User") != expected_user:
    raise SystemExit("runtime user differs from the release lock")
' "$image_id" "$runtime_user"
}

verify_proxy_image() {
  local image="$1"
  local actual_id
  actual_id="$(docker image inspect "$image" --format '{{.Id}}')"
  contains_value "$actual_id" "${NEW_PROXY_IMAGE_IDS[@]}" \
    || fail "entrypoint image ID differs from the release lock"
  docker image inspect "$image" | python3 -c '
import json
import sys

item = json.load(sys.stdin)[0]
if item["Os"] != "linux" or item["Architecture"] != "arm64":
    raise SystemExit("entrypoint image is not Linux ARM64")
'
}

update_release_values() {
  local proxy_image="$1"
  local ui_image="$2"
  local agent_image="$3"
  local rag_image="$4"
  python3 - \
    "$ENV_FILE" \
    "$proxy_image" \
    "$ui_image" \
    "$agent_image" \
    "$rag_image" \
    "$NEW_VECTOR_SEED_IMAGE" \
    "$NEW_COLLECTION" \
    "$NEW_BACKUP_NAME" \
    "$NEW_BACKUP_SHA256" \
    "$NEW_SEED_CONTAINER" \
    "$NEW_VECTOR_SEED_ROOT" <<'PY'
import os
import stat
import sys
import tempfile
from pathlib import Path

path = Path(sys.argv[1])
updates = {
    "NO_SSO_PROXY_IMAGE": sys.argv[2],
    "NO_SSO_UI_IMAGE": sys.argv[3],
    "NO_SSO_AGENT_IMAGE": sys.argv[4],
    "NO_SSO_RAG_IMAGE": sys.argv[5],
    "NO_SSO_VECTOR_SEED_IMAGE": sys.argv[6],
    "NO_SSO_COLLECTION": sys.argv[7],
    "NO_SSO_VECTOR_BACKUP_NAME": sys.argv[8],
    "NO_SSO_VECTOR_BACKUP_SHA256": sys.argv[9],
    "NO_SSO_SEED_CONTAINER": sys.argv[10],
    "NO_SSO_VECTOR_SEED_ROOT": sys.argv[11],
}
lines = path.read_text(encoding="utf-8").splitlines()
seen = {key: 0 for key in updates}
for index, line in enumerate(lines):
    key = line.split("=", 1)[0] if "=" in line else ""
    if key in updates:
        seen[key] += 1
        lines[index] = f"{key}={updates[key]}"
for key, count in seen.items():
    if count > 1:
        raise SystemExit(f"environment key appears more than once: {key}")
    if count == 0:
        lines.append(f"{key}={updates[key]}")
mode = stat.S_IMODE(path.stat().st_mode)
descriptor, temporary_name = tempfile.mkstemp(
    dir=path.parent, prefix=".env.integrated-refresh."
)
temporary = Path(temporary_name)
try:
    with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")
    temporary.chmod(mode)
    temporary.replace(path)
finally:
    temporary.unlink(missing_ok=True)
PY
}

restore_previous_application() {
  local status="$?"
  trap - ERR
  if [[ "$MUTATED" == "1" ]]; then
    echo "Candidate validation failed; restoring the complete previous release boundary." >&2
    cp -p "$EVIDENCE_DIR/env.before" "$ENV_FILE"
    for relative in "${RELEASE_FILES[@]}"; do
      backup="$EVIDENCE_DIR/files/$relative"
      [[ ! -f "$backup" ]] || cp -p "$backup" "$TARGET_ROOT/$relative"
    done
    [[ ! -f "$EVIDENCE_DIR/runtime/no-sso-entrypoint.conf" ]] \
      || cp -p \
        "$EVIDENCE_DIR/runtime/no-sso-entrypoint.conf" \
        "$TARGET_ROOT/runtime/no-sso-entrypoint.conf"
    docker-compose -p "$PROJECT" -f "$COMPOSE_FILE" config >/dev/null || true
    docker-compose -p "$PROJECT" -f "$COMPOSE_FILE" up -d --no-deps rag-api || true
    wait_http "http://127.0.0.1:$(env_value NO_SSO_RAG_HOST_PORT)/health" "previous search API" || true
    docker-compose -p "$PROJECT" -f "$COMPOSE_FILE" up -d --no-deps agent-runtime || true
    wait_http "http://127.0.0.1:$(env_value NO_SSO_AGENT_HOST_PORT)/health" "previous agent runtime" || true
    docker-compose -p "$PROJECT" -f "$COMPOSE_FILE" up -d --no-deps web-ui || true
    wait_http "http://127.0.0.1:$(env_value NO_SSO_UI_HOST_PORT)/healthz" "previous UI" || true
    docker-compose -p "$PROJECT" -f "$COMPOSE_FILE" up -d --no-deps entrypoint || true
    wait_http "http://127.0.0.1:$(env_value NO_SSO_ENTRYPOINT_PORT)/healthz" "previous entrypoint" || true
  fi
  echo "Evidence preserved at $EVIDENCE_DIR" >&2
  exit "$status"
}

[[ "$TARGET_ROOT" == "$EXPECTED_ROOT" ]] || fail "target root is not approved"
[[ -f "$COMPOSE_FILE" && -f "$ENV_FILE" ]] || fail "target deployment is incomplete"
[[ -f "$NEW_MANIFEST" && -f "$NEW_IMAGE_LIST" ]] || fail "release locks are missing"
for command in docker docker-compose python3 curl; do
  command -v "$command" >/dev/null 2>&1 || fail "required command is missing: $command"
done

for name in "${PRESERVED_CONTAINERS[@]}" "${APPLICATION_CONTAINERS[@]}"; do
  project="$(
    docker inspect "$name" \
      --format '{{index .Config.Labels "com.docker.compose.project"}}' 2>/dev/null
  )"
  [[ "$project" == "$PROJECT" ]] || fail "container is outside the approved project: $name"
done

current_proxy="$(env_value NO_SSO_PROXY_IMAGE)"
current_ui="$(env_value NO_SSO_UI_IMAGE)"
current_agent="$(env_value NO_SSO_AGENT_IMAGE)"
current_rag="$(env_value NO_SSO_RAG_IMAGE)"
contains_value "$current_proxy" "${OLD_PROXY_IMAGES[@]}" \
  || fail "current entrypoint image is outside the approved upgrade boundary"
contains_value "$current_ui" "${OLD_UI_IMAGES[@]}" \
  || fail "current UI image is outside the approved upgrade boundary"
contains_value "$current_agent" "${OLD_AGENT_IMAGES[@]}" \
  || fail "current agent image is outside the approved upgrade boundary"
contains_value "$current_rag" "${OLD_RAG_IMAGES[@]}" \
  || fail "current search image is outside the approved upgrade boundary"

stamp="$(date -u +%Y%m%dT%H%M%SZ)"
EVIDENCE_DIR="$TARGET_ROOT/evidence/integrated-refresh-$stamp"
mkdir -p "$EVIDENCE_DIR/files/entrypoint" "$EVIDENCE_DIR/files/scripts" "$EVIDENCE_DIR/runtime"
chmod 700 "$EVIDENCE_DIR"
cp -p "$ENV_FILE" "$EVIDENCE_DIR/env.before"
for relative in "${RELEASE_FILES[@]}"; do
  [[ ! -f "$TARGET_ROOT/$relative" ]] \
    || cp -p "$TARGET_ROOT/$relative" "$EVIDENCE_DIR/files/$relative"
done
[[ ! -f "$TARGET_ROOT/runtime/no-sso-entrypoint.conf" ]] \
  || cp -p \
    "$TARGET_ROOT/runtime/no-sso-entrypoint.conf" \
    "$EVIDENCE_DIR/runtime/no-sso-entrypoint.conf"
[[ ! -f "$TARGET_ROOT/g5680a-no-sso-rag-v2-components.lock.json" ]] \
  || cp -p "$TARGET_ROOT/g5680a-no-sso-rag-v2-components.lock.json" "$EVIDENCE_DIR/manifest.before"
[[ ! -f "$TARGET_ROOT/image-list.no-sso-rag-v2.g5680a.txt" ]] \
  || cp -p "$TARGET_ROOT/image-list.no-sso-rag-v2.g5680a.txt" "$EVIDENCE_DIR/image-list.before"

snapshot_containers "$EVIDENCE_DIR/preserved.before.json" "${PRESERVED_CONTAINERS[@]}"
snapshot_containers "$EVIDENCE_DIR/application.before.json" "${APPLICATION_CONTAINERS[@]}"
python3 "$SCRIPT_ROOT/scripts/no_sso_target_control.py" \
  --root "$TARGET_ROOT" --env "$ENV_FILE" \
  capture --output "$EVIDENCE_DIR/control.before.json"

database="$TARGET_ROOT/data/ui/hku_ui.sqlite3"
[[ -f "$database" ]] || fail "UI database is missing"
database_record \
  "$database" \
  "$EVIDENCE_DIR/database.before.json" \
  "$EVIDENCE_DIR/hku_ui.sqlite3.before"

pull_image "$NEW_PROXY_IMAGE"
pull_image "$NEW_UI_IMAGE"
pull_image "$NEW_AGENT_IMAGE"
pull_image "$NEW_RAG_IMAGE"
pull_image "$NEW_VECTOR_SEED_IMAGE"
verify_proxy_image "$NEW_PROXY_IMAGE"
verify_image "$NEW_UI_IMAGE" "$NEW_UI_IMAGE_ID" appuser
verify_image "$NEW_AGENT_IMAGE" "$NEW_AGENT_IMAGE_ID" agent
verify_image "$NEW_RAG_IMAGE" "$NEW_RAG_IMAGE_ID" appuser
verify_image "$NEW_VECTOR_SEED_IMAGE" "$NEW_VECTOR_SEED_IMAGE_ID" -

MUTATED=1
trap restore_previous_application ERR

for relative in "${RELEASE_FILES[@]}"; do
  install -D -m 0644 "$SCRIPT_ROOT/$relative" "$TARGET_ROOT/$relative"
done
chmod 0755 \
  "$TARGET_ROOT/CheckNoSSOG5680A.sh" \
  "$TARGET_ROOT/scripts/no_sso_target_config.py" \
  "$TARGET_ROOT/scripts/no_sso_target_control.py" \
  "$TARGET_ROOT/scripts/verify_no_sso_ingress.py"

update_release_values \
  "$NEW_PROXY_IMAGE" \
  "$NEW_UI_IMAGE" \
  "$NEW_AGENT_IMAGE" \
  "$NEW_RAG_IMAGE"
python3 "$TARGET_ROOT/scripts/no_sso_target_config.py" render --env "$ENV_FILE"
NO_SSO_ENV_FILE="$ENV_FILE" "$SCRIPT_ROOT/StagePOC03.sh"
NO_SSO_ENV_FILE="$ENV_FILE" "$SCRIPT_ROOT/RestorePOC03.sh"

docker-compose -p "$PROJECT" -f "$COMPOSE_FILE" config >/dev/null
printf '%s\n' "passed" > "$EVIDENCE_DIR/compose-validation.txt"
docker-compose -p "$PROJECT" -f "$COMPOSE_FILE" up -d --no-deps rag-api
wait_http "http://127.0.0.1:$(env_value NO_SSO_RAG_HOST_PORT)/health" "search API"
docker-compose -p "$PROJECT" -f "$COMPOSE_FILE" up -d --no-deps agent-runtime
wait_http "http://127.0.0.1:$(env_value NO_SSO_AGENT_HOST_PORT)/health" "agent runtime"
docker-compose -p "$PROJECT" -f "$COMPOSE_FILE" up -d --no-deps web-ui
wait_http "http://127.0.0.1:$(env_value NO_SSO_UI_HOST_PORT)/healthz" "application UI"
docker-compose -p "$PROJECT" -f "$COMPOSE_FILE" up -d --no-deps entrypoint
wait_http "http://127.0.0.1:$(env_value NO_SSO_ENTRYPOINT_PORT)/healthz" "entrypoint"

actual_prompt="$(
  docker exec hku-no-sso-v3-agent \
    sha256sum /opt/hku-runtime/.hku_agent/profiles/hku-chatbot-no-sso-rag-v2/SOUL.md \
    | awk '{print $1}'
)"
[[ "$actual_prompt" == "1f60880e86ded79e265de0e41324d2659cf855218883b5810b4987d843d14a9d" ]] \
  || fail "embedded prompt hash differs from the release lock"
docker exec hku-no-sso-v3-agent sh -ec \
  'test -z "$(find /opt/hku-runtime/bin -type f \( -name "*.py" -o -name "*.pyc" \) -print -quit)"' \
  || fail "agent application source is present"
docker exec hku-no-sso-v3-search sh -ec \
  'test -z "$(find /opt/hku-search/runtime -type f \( -name "*.py" -o -name "*.pyc" \) -print -quit)"' \
  || fail "search application source is present"
docker exec hku-no-sso-v3-ui sh -ec \
  'test -z "$(find /opt/hku-ui -type f \( -name "*.py" -o -name "*.pyc" \) -print -quit)"' \
  || fail "UI application source is present"

export NO_SSO_AGENT_API_KEY="$(env_value NO_SSO_AGENT_API_KEY)"
python3 "$SCRIPT_ROOT/tests/e2e_no_sso_rehearsal.py" \
  --ui-base-url "http://127.0.0.1:$(env_value NO_SSO_ENTRYPOINT_PORT)" \
  --rag-base-url "http://127.0.0.1:$(env_value NO_SSO_RAG_HOST_PORT)" \
  --agent-base-url "http://127.0.0.1:$(env_value NO_SSO_AGENT_HOST_PORT)" \
  --agent-api-key-env NO_SSO_AGENT_API_KEY \
  --output "$EVIDENCE_DIR/e2e-integrated-refresh.json"
python3 "$SCRIPT_ROOT/tests/e2e_agent_stream_regression.py" \
  --base-url "http://127.0.0.1:$(env_value NO_SSO_AGENT_HOST_PORT)" \
  --api-key-env NO_SSO_AGENT_API_KEY \
  --output "$EVIDENCE_DIR/six-case-stream-regression.json"
unset NO_SSO_AGENT_API_KEY

snapshot_containers "$EVIDENCE_DIR/preserved.after.json" "${PRESERVED_CONTAINERS[@]}"
snapshot_containers "$EVIDENCE_DIR/application.after.json" "${APPLICATION_CONTAINERS[@]}"
python3 - \
  "$EVIDENCE_DIR/preserved.before.json" \
  "$EVIDENCE_DIR/preserved.after.json" \
  "$EVIDENCE_DIR/application.before.json" \
  "$EVIDENCE_DIR/application.after.json" \
  "$NEW_PROXY_IMAGE" "${NEW_PROXY_IMAGE_IDS[0]}" "${NEW_PROXY_IMAGE_IDS[1]}" \
  "$NEW_UI_IMAGE" "$NEW_UI_IMAGE_ID" \
  "$NEW_AGENT_IMAGE" "$NEW_AGENT_IMAGE_ID" \
  "$NEW_RAG_IMAGE" "$NEW_RAG_IMAGE_ID" <<'PY'
import json
import sys

preserved_before = json.load(open(sys.argv[1], encoding="utf-8"))
preserved_after = json.load(open(sys.argv[2], encoding="utf-8"))
application_before = {
    value["name"]: value for value in json.load(open(sys.argv[3], encoding="utf-8"))
}
application_after = {
    value["name"]: value for value in json.load(open(sys.argv[4], encoding="utf-8"))
}
expected = {
    "hku-no-sso-v3-entrypoint": (sys.argv[5], {sys.argv[6], sys.argv[7]}),
    "hku-no-sso-v3-ui": (sys.argv[8], {sys.argv[9]}),
    "hku-no-sso-v3-agent": (sys.argv[10], {sys.argv[11]}),
    "hku-no-sso-v3-search": (sys.argv[12], {sys.argv[13]}),
}
if preserved_before != preserved_after:
    raise SystemExit("a preserved container changed during the application refresh")
if set(application_before) != set(expected) or set(application_after) != set(expected):
    raise SystemExit("application container inventory changed")
for name, (image_reference, image_ids) in expected.items():
    before = application_before[name]
    after = application_after[name]
    if before["mounts"] != after["mounts"]:
        raise SystemExit(f"application mounts changed: {name}")
    if after["image_reference"] != image_reference or after["image_id"] not in image_ids:
        raise SystemExit(f"application image differs from the release lock: {name}")
    if after["status"] != "running" or after["health"] != "healthy":
        raise SystemExit(f"application container is not healthy: {name}")
PY

database_record "$database" "$EVIDENCE_DIR/database.after.json"
python3 - "$EVIDENCE_DIR/database.before.json" "$EVIDENCE_DIR/database.after.json" <<'PY'
import json
import sys

before = json.load(open(sys.argv[1], encoding="utf-8"))
after = json.load(open(sys.argv[2], encoding="utf-8"))
if before != after:
    raise SystemExit("UI database row counts or integrity changed")
PY

python3 "$SCRIPT_ROOT/scripts/no_sso_target_control.py" \
  --root "$TARGET_ROOT" --env "$ENV_FILE" \
  compare --before "$EVIDENCE_DIR/control.before.json"

cp -p "$NEW_MANIFEST" "$TARGET_ROOT/g5680a-no-sso-rag-v2-components.lock.json"
cp -p "$NEW_IMAGE_LIST" "$TARGET_ROOT/image-list.no-sso-rag-v2.g5680a.txt"
printf '%s\n' "$NEW_PROXY_IMAGE" "$NEW_UI_IMAGE" "$NEW_AGENT_IMAGE" "$NEW_RAG_IMAGE" \
  > "$EVIDENCE_DIR/applied-images.txt"
printf '%s\n' "passed" > "$EVIDENCE_DIR/result.txt"
trap - ERR

echo "Integrated ingress and application refresh passed."
echo "Evidence: $EVIDENCE_DIR"
