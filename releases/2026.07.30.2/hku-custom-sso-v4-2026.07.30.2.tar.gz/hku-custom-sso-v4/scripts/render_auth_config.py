#!/usr/bin/env python3
from __future__ import annotations

import ipaddress
import json
import os
import re
import sys
import urllib.parse
import uuid
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ENV_FILE = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / ".env.auth"
OUTPUT = Path(sys.argv[2]) if len(sys.argv) > 2 else ROOT / "runtime" / "auth-gateway.cfg"
SESSION_OUTPUT = Path(sys.argv[3]) if len(sys.argv) > 3 else ROOT / "runtime" / "session-store.conf"
ALPHA_OUTPUT = Path(sys.argv[4]) if len(sys.argv) > 4 else None


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def read_env(path: Path) -> dict[str, str]:
    if not path.is_file():
        fail(f"environment file is missing: {path}")
    values: dict[str, str] = {}
    for number, raw_line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            fail(f"invalid environment entry at {path}:{number}")
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def require(values: dict[str, str], key: str) -> str:
    value = values.get(key, "").strip()
    if not value:
        fail(f"{key} is required")
    return value


def read_text_secret(path: Path, minimum: int) -> str:
    if not path.is_file():
        fail(f"secret file is missing: {path}")
    raw = path.read_bytes()
    if b"\n" in raw or b"\r" in raw:
        fail(f"secret file must not contain a newline: {path}")
    try:
        value = raw.decode("utf-8")
    except UnicodeDecodeError:
        fail(f"secret file must contain UTF-8 text: {path}")
    if len(value) < minimum:
        fail(f"secret file is too short: {path}")
    return value


def split_csv(value: str) -> list[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


def quoted(value: str) -> str:
    return json.dumps(value, ensure_ascii=True)


def string_list(values: list[str]) -> str:
    return "[" + ", ".join(quoted(value) for value in values) + "]"


def validate_url(
    value: str,
    name: str,
    *,
    require_https: bool,
    allow_path: bool,
) -> urllib.parse.ParseResult:
    parsed = urllib.parse.urlparse(value)
    if not parsed.hostname or parsed.username or parsed.password or parsed.params or parsed.query or parsed.fragment:
        fail(f"{name} must not contain credentials, parameters, a query, or a fragment")
    if not allow_path and parsed.path not in {"", "/"}:
        fail(f"{name} must be an origin without a path")
    if require_https and parsed.scheme != "https":
        fail(f"{name} must use https")
    if parsed.scheme not in {"http", "https"}:
        fail(f"{name} must use http or https")
    return parsed


def write_readonly(path: Path, content: str) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp.{os.getpid()}")
    temporary.write_text(content, encoding="utf-8")
    os.chmod(path.parent, 0o700)
    os.chmod(temporary, 0o444)
    os.replace(temporary, path)


def main() -> None:
    values = read_env(ENV_FILE)
    mode = require(values, "AUTH_MODE")
    if mode not in {"mock", "entra", "hku"}:
        fail("AUTH_MODE must be mock, entra, or hku")

    public_url = require(values, "AUTH_PUBLIC_URL").rstrip("/")
    validate_url(public_url, "AUTH_PUBLIC_URL", require_https=True, allow_path=False)
    issuer_url = require(values, "AUTH_OIDC_ISSUER_URL").rstrip("/")
    issuer = validate_url(
        issuer_url,
        "AUTH_OIDC_ISSUER_URL",
        require_https=mode != "mock",
        allow_path=True,
    )
    if mode == "mock" and issuer.hostname != "test-identity":
        fail("mock issuer must be the isolated test-identity service")
    if mode == "hku" and issuer_url not in {
        "https://oidp.hku.hk/oidc",
        "https://oidp-test.hku.hk/oidc",
    }:
        fail("hku issuer must be the documented HKU production or development issuer")
    if mode == "entra":
        if issuer.hostname != "login.microsoftonline.com":
            fail("entra issuer must use login.microsoftonline.com")
        path_parts = issuer.path.strip("/").split("/")
        if len(path_parts) != 2 or path_parts[1] != "v2.0":
            fail("entra issuer must use a tenant-specific /<tenant-id>/v2.0 path")
        try:
            uuid.UUID(path_parts[0])
        except ValueError:
            fail("entra issuer must contain a tenant UUID, not common or organizations")

    client_id = require(values, "AUTH_OIDC_CLIENT_ID")
    scopes = split_csv(require(values, "AUTH_OIDC_SCOPES").replace(" ", ","))
    if "openid" not in scopes:
        fail("AUTH_OIDC_SCOPES must include openid")

    email_domains = [value.lower().lstrip("@") for value in split_csv(require(values, "AUTH_ALLOWED_EMAIL_DOMAINS"))]
    if mode != "mock" and "*" in email_domains:
        fail("production identity profiles may not allow every email domain")

    allowed_groups = split_csv(values.get("AUTH_ALLOWED_GROUPS", ""))
    network_mode = values.get("AUTH_NETWORK_MODE", "bridge").strip().lower()
    if network_mode == "host":
        gateway_ip = ipaddress.ip_address("127.0.0.1")
        gateway_port = int(require(values, "AUTH_GATEWAY_HOST_PORT"))
        session_port = int(require(values, "AUTH_SESSION_HOST_PORT"))
        for name, port in (("AUTH_GATEWAY_HOST_PORT", gateway_port), ("AUTH_SESSION_HOST_PORT", session_port)):
            if not 1024 <= port <= 65535:
                fail(f"{name} must be an unprivileged TCP port")
        redis_host = "127.0.0.1"
        service_bind = "127.0.0.1"
    elif network_mode == "bridge":
        edge_subnet = ipaddress.ip_network(require(values, "AUTH_EDGE_SUBNET"), strict=True)
        gateway_ip = ipaddress.ip_address(require(values, "AUTH_ENTRYPOINT_IP"))
        if gateway_ip not in edge_subnet:
            fail("AUTH_ENTRYPOINT_IP must belong to AUTH_EDGE_SUBNET")
        gateway_port = 4180
        session_port = 6379
        redis_host = "session-store"
        service_bind = "0.0.0.0"
    else:
        fail("AUTH_NETWORK_MODE must be bridge or host")

    secret_dir = ROOT / "secrets"
    client_secret = read_text_secret(secret_dir / "oidc-client-secret", 8)
    cookie_secret_path = secret_dir / "cookie-secret"
    if not cookie_secret_path.is_file() or len(cookie_secret_path.read_bytes()) != 32:
        fail("cookie-secret must contain exactly 32 raw bytes")
    session_password = read_text_secret(secret_dir / "session-password", 32)
    if not re.fullmatch(r"[A-Za-z0-9_-]{32,}", session_password):
        fail("session-password may contain only letters, numbers, underscores, and hyphens")

    if client_id in client_secret:
        fail("OIDC client secret must not duplicate the public client ID")

    common_settings = [
        'session_store_type = "redis"',
        f'redis_connection_url = "redis://{redis_host}:{session_port}/0"',
        f"redis_password = {quoted(session_password)}",
        'cookie_name = "__Host-hku_auth"',
        'cookie_secret_file = "/run/secrets/cookie-secret"',
        'cookie_path = "/"',
        f"cookie_expire = {quoted(values.get('AUTH_COOKIE_EXPIRE', '8h'))}",
        'cookie_refresh = "0"',
        'cookie_secure = true',
        'cookie_httponly = true',
        'cookie_samesite = "lax"',
        'cookie_csrf_per_request = true',
        'cookie_csrf_per_request_limit = 5',
        'cookie_csrf_expire = "15m"',
        'cookie_csrf_samesite = "lax"',
        'reverse_proxy = true',
        f"trusted_proxy_ips = {string_list([str(gateway_ip) + '/32'])}",
        'real_client_ip_header = "X-Real-IP"',
        'relative_redirect_url = true',
        'force_https = false',
        'skip_provider_button = true',
        'standard_logging = true',
        'auth_logging = false',
        'request_logging = true',
        'request_logging_format = "{{.Timestamp}} {{.RequestMethod}} {{.Host}} {{.StatusCode}} {{.ResponseSize}} {{.RequestDuration}}"',
        'silence_ping_logging = true',
    ]

    legacy_provider_settings = [
        f'http_address = "{service_bind}:{gateway_port}"',
        'provider = "oidc"',
        'provider_display_name = "HKU sign-in"',
        f"oidc_issuer_url = {quoted(issuer_url)}",
        f"client_id = {quoted(client_id)}",
        'client_secret_file = "/run/secrets/oidc-client-secret"',
        f"redirect_url = {quoted(public_url + '/oauth2/callback')}",
        f"scope = {quoted(' '.join(scopes))}",
        'oidc_email_claim = "email"',
        'oidc_groups_claim = "groups"',
        'oidc_enabled_signing_algs = ["RS256"]',
        f"email_domains = {string_list(email_domains)}",
        f"allowed_groups = {string_list(allowed_groups)}",
        'upstreams = ["static://202"]',
        'code_challenge_method = "S256"',
        'insecure_oidc_allow_unverified_email = false',
        'insecure_oidc_skip_issuer_verification = false',
        'insecure_oidc_skip_nonce = false',
        'ssl_insecure_skip_verify = false',
        'set_xauthrequest = true',
        'pass_access_token = false',
        'pass_authorization_header = false',
        'set_authorization_header = false',
        'pass_basic_auth = false',
        'pass_user_headers = false',
    ]

    if ALPHA_OUTPUT is None:
        settings = legacy_provider_settings + common_settings
    else:
        if mode != "hku":
            fail("structured target configuration is supported only for AUTH_MODE=hku")
        if allowed_groups:
            fail(
                "AUTH_ALLOWED_GROUPS is not enforceable with the structured HKU provider; "
                "restrict pilot access in the HKU client assignment"
            )
        logout_url = (
            issuer_url
            + "/session/end?id_token_hint={id_token}&post_logout_redirect_uri="
            + urllib.parse.quote(public_url + "/", safe="")
        )
        settings = [
            f"redirect_url = {quoted(public_url + '/oauth2/callback')}",
            f"email_domains = {string_list(email_domains)}",
            'ssl_insecure_skip_verify = false',
        ] + common_settings
        alpha_settings = [
            "server:",
            f'  bindAddress: "{service_bind}:{gateway_port}"',
            "upstreamConfig:",
            "  upstreams:",
            "    - id: static-auth-response",
            '      path: "/"',
            "      static: true",
            "      staticCode: 202",
            "injectResponseHeaders:",
            "  - name: X-Auth-Request-User",
            "    values:",
            "      - claimSource:",
            '          claim: "sub"',
            "  - name: X-Auth-Request-Email",
            "    values:",
            "      - claimSource:",
            '          claim: "email"',
            "  - name: X-Auth-Request-Preferred-Username",
            "    values:",
            "      - claimSource:",
            '          claim: "name"',
            "  - name: X-Auth-Request-Groups",
            "    values:",
            "      - claimSource:",
            '          claim: "groups"',
            "  - name: X-HKU-Auth-HKU-No",
            "    values:",
            "      - claimSource:",
            '          claim: "hkuno"',
            "  - name: X-HKU-Auth-UID",
            "    values:",
            "      - claimSource:",
            '          claim: "uid"',
            "  - name: X-HKU-Auth-Account-Type",
            "    values:",
            "      - claimSource:",
            '          claim: "account_type"',
            "providers:",
            "  - id: hku",
            "    provider: oidc",
            '    name: "HKU sign-in"',
            f"    clientID: {quoted(client_id)}",
            '    clientSecretFile: "/run/secrets/oidc-client-secret"',
            f"    scope: {quoted(' '.join(scopes))}",
            "    code_challenge_method: S256",
            f"    backendLogoutURL: {quoted(logout_url)}",
            "    skipClaimsFromProfileURL: true",
            "    additionalClaims:",
            "      - sub",
            "      - name",
            "      - hkuno",
            "      - uid",
            "      - account_type",
            "    oidcConfig:",
            f"      issuerURL: {quoted(issuer_url)}",
            "      insecureAllowUnverifiedEmail: false",
            "      insecureSkipIssuerVerification: false",
            "      insecureSkipNonce: false",
            '      emailClaim: "email"',
            '      groupsClaim: "groups"',
            # v7.15.x treats a non-email userIDClaim as a deprecated override
            # for emailClaim. Keep email validation here and expose the stable
            # subject through additionalClaims/X-Auth-Request-User above.
            '      userIDClaim: "email"',
            "      audienceClaims:",
            "        - aud",
            "      enabledSigningAlgs:",
            "        - RS256",
        ]
        write_readonly(ALPHA_OUTPUT, "\n".join(alpha_settings) + "\n")

    session_settings = [
        f"bind {service_bind}",
        f"port {session_port}",
        "protected-mode yes",
        "dir /data",
        "appendonly yes",
        "appendfsync everysec",
        "save 300 10",
        f"requirepass {session_password}",
    ]

    write_readonly(OUTPUT, "\n".join(settings) + "\n")
    write_readonly(SESSION_OUTPUT, "\n".join(session_settings) + "\n")
    print(f"Rendered authentication gateway config for {mode} at {OUTPUT}")


if __name__ == "__main__":
    main()
