#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ipaddress
import os
import re
import tempfile
from pathlib import Path


HOST_PLACEHOLDER = "__HKU_EXPECTED_HOST__"
PROOF_PLACEHOLDER = "__HKU_UI_PROXY_SECRET__"


def read_expected_host(value: str) -> str:
    host = value.strip().lower().rstrip(".")
    if not host or "/" in host or ":" in host:
        raise SystemExit("expected host must be a hostname or IPv4 address without a port")
    try:
        ipaddress.ip_address(host)
        return host
    except ValueError:
        pass
    if len(host) > 253 or not re.fullmatch(
        r"(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*"
        r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?",
        host,
    ):
        raise SystemExit("expected host is not a valid DNS hostname")
    return host


def read_proxy_secret(path: Path) -> str:
    raw = path.read_bytes()
    if len(raw) != 64 or not re.fullmatch(rb"[0-9a-f]{64}", raw):
        raise SystemExit("proxy secret must contain exactly 64 lowercase hexadecimal characters")
    return raw.decode("ascii")


def render(template: Path, output: Path, secret_file: Path, expected_host: str) -> None:
    source = template.read_text(encoding="utf-8")
    if source.count(PROOF_PLACEHOLDER) != 1:
        raise SystemExit(f"entrypoint template must contain exactly one {PROOF_PLACEHOLDER} placeholder")
    if source.count(HOST_PLACEHOLDER) != 1:
        raise SystemExit(f"entrypoint template must contain exactly one {HOST_PLACEHOLDER} placeholder")
    rendered = source.replace(PROOF_PLACEHOLDER, read_proxy_secret(secret_file))
    rendered = rendered.replace(HOST_PLACEHOLDER, read_expected_host(expected_host))
    output.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=output.parent, delete=False) as stream:
        stream.write(rendered)
        temporary = Path(stream.name)
    os.chmod(output.parent, 0o700)
    # The bind-mounted file is consumed by a non-root container UID. The
    # owner-only parent directory remains 0700 on the host.
    os.chmod(temporary, 0o444)
    os.replace(temporary, output)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("template", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("secret_file", type=Path)
    parser.add_argument("expected_host")
    args = parser.parse_args()
    render(args.template, args.output, args.secret_file, args.expected_host)


if __name__ == "__main__":
    main()
