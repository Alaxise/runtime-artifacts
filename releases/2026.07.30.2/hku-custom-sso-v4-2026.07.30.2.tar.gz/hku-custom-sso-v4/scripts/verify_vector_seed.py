#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def tree_digest(root: Path) -> tuple[str, int, int]:
    digest = hashlib.sha256()
    files = sorted(path for path in root.rglob("*") if path.is_file())
    total = 0
    for path in files:
        relative = path.relative_to(root).as_posix()
        size = path.stat().st_size
        total += size
        digest.update(relative.encode("utf-8") + b"\0")
        digest.update(str(size).encode("ascii") + b"\0")
        digest.update(sha256(path).encode("ascii") + b"\n")
    return digest.hexdigest(), len(files), total


def verify(
    root: Path,
    collection: str,
    rows: int,
    backup_name: str,
    expected_backup_sha256: str,
) -> dict[str, object]:
    manifest_path = root / "manifest.json"
    checksum_path = root / "SHA256SUMS"
    binary = root / "milvus-backup"
    backup = root / "backup" / backup_name
    for path in (manifest_path, checksum_path, binary, backup):
        if not path.exists():
            fail(f"vector seed payload is incomplete: {path}")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    expected = {
        "source_collection": collection,
        "row_count": rows,
        "backup_name": backup_name,
        "milvus_version": "2.6.3",
        "is_latest_field": True,
    }
    for key, value in expected.items():
        if manifest.get(key) != value:
            fail(f"vector seed manifest mismatch for {key}")

    checked = 0
    for number, line in enumerate(checksum_path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        digest, separator, relative = line.partition("  ")
        if not separator or not re_full_sha256(digest):
            fail(f"invalid checksum record at line {number}")
        candidate = (root / relative).resolve()
        try:
            candidate.relative_to(root.resolve())
        except ValueError:
            fail(f"checksum path escapes payload root: {relative}")
        if not candidate.is_file() or sha256(candidate) != digest:
            fail(f"vector seed checksum mismatch: {relative}")
        checked += 1
    if checked < 3:
        fail("vector seed checksum manifest is unexpectedly small")

    backup_digest, file_count, byte_count = tree_digest(backup)
    if backup_digest != expected_backup_sha256:
        fail("vector seed backup digest does not match the release contract")
    return {
        "backup_name": backup_name,
        "backup_sha256": backup_digest,
        "collection": collection,
        "files": file_count,
        "bytes": byte_count,
        "rows": rows,
        "checksums_verified": checked,
    }


def re_full_sha256(value: str) -> bool:
    return len(value) == 64 and all(character in "0123456789abcdef" for character in value)


def main() -> None:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    verify_parser = subparsers.add_parser("verify")
    verify_parser.add_argument("--root", type=Path, required=True)
    verify_parser.add_argument("--collection", required=True)
    verify_parser.add_argument("--rows", type=int, required=True)
    verify_parser.add_argument("--backup-name", required=True)
    verify_parser.add_argument("--expected-backup-sha256", required=True)
    compare_parser = subparsers.add_parser("compare")
    compare_parser.add_argument("--left", type=Path, required=True)
    compare_parser.add_argument("--right", type=Path, required=True)
    args = parser.parse_args()

    if args.command == "verify":
        result = verify(
            args.root,
            args.collection,
            args.rows,
            args.backup_name,
            args.expected_backup_sha256,
        )
    else:
        left = tree_digest(args.left)
        right = tree_digest(args.right)
        if left != right:
            fail("existing lane-owned backup payload differs from the release seed")
        result = {"tree_sha256": left[0], "files": left[1], "bytes": left[2]}
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
