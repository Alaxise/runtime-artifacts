#!/usr/bin/env python3
"""Generate and validate private runtime bearer keys."""

from __future__ import annotations

import argparse
import os
import secrets
import tempfile
from pathlib import Path


KEY_NAME = "AUTH_AGENT_API_KEY"
RAG_KEY_NAME = "RAG_API_KEY"
SUPPORTED_KEY_NAMES = (KEY_NAME, RAG_KEY_NAME)
MINIMUM_LENGTH = 48
PLACEHOLDER_MARKERS = ("REPLACE_WITH_", "CHANGEME", "DEFAULT", "EXAMPLE")


def is_strong_agent_api_key(value: str) -> bool:
    if len(value) < MINIMUM_LENGTH or any(character.isspace() for character in value):
        return False
    upper = value.upper()
    if any(marker in upper for marker in PLACEHOLDER_MARKERS):
        return False
    character_classes = sum(
        (
            any(character.islower() for character in value),
            any(character.isupper() for character in value),
            any(character.isdigit() for character in value),
            any(not character.isalnum() for character in value),
        )
    )
    return character_classes >= 2 and len(set(value)) >= 12


def read_key(lines: list[str], key_name: str = KEY_NAME) -> tuple[int | None, str]:
    if key_name not in SUPPORTED_KEY_NAMES:
        raise ValueError(f"unsupported key name: {key_name}")
    matches = [
        (index, line.removeprefix(f"{key_name}=").rstrip("\r\n"))
        for index, line in enumerate(lines)
        if line.startswith(f"{key_name}=")
    ]
    if len(matches) > 1:
        raise SystemExit(f"{key_name} must appear exactly once")
    return matches[0] if matches else (None, "")


def ensure_api_key(env_file: Path, key_name: str) -> bool:
    if not env_file.is_file():
        raise SystemExit(f"environment file is missing: {env_file}")

    original = env_file.stat()
    lines = env_file.read_text(encoding="utf-8").splitlines(keepends=True)
    index, value = read_key(lines, key_name)
    if is_strong_agent_api_key(value):
        return False

    replacement = secrets.token_hex(32)
    while not is_strong_agent_api_key(replacement):
        replacement = secrets.token_hex(32)
    line = f"{key_name}={replacement}\n"
    if index is None:
        if lines and not lines[-1].endswith(("\n", "\r")):
            lines[-1] += "\n"
        lines.append(line)
    else:
        lines[index] = line

    with tempfile.NamedTemporaryFile(
        "w",
        encoding="utf-8",
        dir=env_file.parent,
        prefix=f".{env_file.name}.",
        delete=False,
    ) as stream:
        stream.writelines(lines)
        temporary = Path(stream.name)
    try:
        os.chmod(temporary, original.st_mode & 0o777)
        try:
            os.chown(temporary, original.st_uid, original.st_gid)
        except PermissionError:
            pass
        os.replace(temporary, env_file)
    finally:
        temporary.unlink(missing_ok=True)
    return True


def ensure_agent_api_key(env_file: Path) -> bool:
    return ensure_api_key(env_file, KEY_NAME)


def check_api_key(env_file: Path, key_name: str) -> None:
    if not env_file.is_file():
        raise SystemExit(f"environment file is missing: {env_file}")
    _, value = read_key(
        env_file.read_text(encoding="utf-8").splitlines(keepends=True),
        key_name,
    )
    if not is_strong_agent_api_key(value):
        raise SystemExit(
            f"{key_name} must be an independently generated secret of at least "
            f"{MINIMUM_LENGTH} characters"
        )


def check_agent_api_key(env_file: Path) -> None:
    check_api_key(env_file, KEY_NAME)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("ensure", "check"))
    parser.add_argument("env_file", type=Path)
    parser.add_argument("--key-name", choices=SUPPORTED_KEY_NAMES, default=KEY_NAME)
    args = parser.parse_args()
    if args.command == "ensure":
        changed = ensure_api_key(args.env_file, args.key_name)
        print(f"{args.key_name} generated" if changed else f"{args.key_name} preserved")
    else:
        check_api_key(args.env_file, args.key_name)
        print(f"{args.key_name} contract ok")


if __name__ == "__main__":
    main()
