#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

[[ -f .env ]] || { echo "ERROR: Missing .env" >&2; exit 1; }

env_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' .env
}

pull_image() {
  local image="$1"
  local attempt=1
  while ! docker pull "$image"; do
    if [[ "$attempt" -ge 5 ]]; then
      echo "ERROR: Image pull failed after $attempt attempts: $image" >&2
      return 1
    fi
    sleep "$((attempt * 5))"
    attempt=$((attempt + 1))
  done
}

for key in \
  AUTH_PROXY_IMAGE \
  AUTH_GATEWAY_IMAGE \
  AUTH_SESSION_IMAGE \
  NO_SSO_UI_IMAGE \
  NO_SSO_AGENT_IMAGE \
  NO_SSO_RAG_IMAGE \
  NO_SSO_VECTOR_SEED_IMAGE \
  NO_SSO_ETCD_IMAGE \
  NO_SSO_MINIO_IMAGE \
  NO_SSO_MILVUS_IMAGE; do
  image="$(env_value "$key")"
  [[ -n "$image" ]] || { echo "ERROR: Missing image reference: $key" >&2; exit 1; }
  pull_image "$image"
done

echo "Pulled all immutable SSO POC04 images without starting containers."
