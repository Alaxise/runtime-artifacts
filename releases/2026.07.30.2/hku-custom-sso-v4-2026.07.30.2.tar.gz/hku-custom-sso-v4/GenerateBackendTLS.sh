#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
ENV_FILE="${1:-$ROOT/.env}"
CERT_DIR="$ROOT/certs"
CERTIFICATE="$CERT_DIR/tls.crt"
PRIVATE_KEY="$CERT_DIR/tls.key"
EXPECTED_OWNER_UID="${AUTH_TLS_OWNER_UID:-0}"

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

env_value() {
  awk -F= -v key="$1" '$1 == key { sub(/^[^=]*=/, ""); print; exit }' "$ENV_FILE"
}

[[ -f "$ENV_FILE" ]] || fail "Environment file is missing: $ENV_FILE"
command -v openssl >/dev/null 2>&1 || fail "openssl is required"
[[ "$EXPECTED_OWNER_UID" =~ ^[0-9]+$ ]] || fail "AUTH_TLS_OWNER_UID must be a numeric uid"
if [[ "$(id -u)" != "0" && "$(id -u)" != "$EXPECTED_OWNER_UID" ]]; then
  fail "Run as root, or set AUTH_TLS_OWNER_UID to the current deployment uid"
fi

expected_host="$(env_value AUTH_EXPECTED_HOST)"
expected_ip="$(env_value AUTH_BACKEND_CERT_IP)"
[[ -n "$expected_host" ]] || fail "AUTH_EXPECTED_HOST is required"
[[ -n "$expected_ip" ]] || fail "AUTH_BACKEND_CERT_IP is required"
python3 - "$expected_ip" <<'PY'
import ipaddress
import sys

ipaddress.ip_address(sys.argv[1])
PY

if [[ -e "$CERTIFICATE" || -L "$CERTIFICATE" || -e "$PRIVATE_KEY" || -L "$PRIVATE_KEY" ]]; then
  [[ -f "$CERTIFICATE" && -f "$PRIVATE_KEY" ]] \
    || fail "Refusing to replace an incomplete TLS certificate/key pair"
  [[ "$(stat -c '%u' "$PRIVATE_KEY")" == "$EXPECTED_OWNER_UID" ]] \
    || fail "Refusing to use a TLS private key owned by an unexpected uid"
  echo "Backend TLS material already exists; preserving it without modification."
  exit 0
fi

umask 077
install -d -m 700 "$CERT_DIR"
temporary="$(mktemp -d "$CERT_DIR/.generate.XXXXXX")"
trap 'rm -rf "$temporary"' EXIT

openssl req -x509 -newkey rsa:2048 -sha256 -nodes -days 365 \
  -subj "/CN=$expected_host" \
  -addext "subjectAltName=DNS:$expected_host,IP:$expected_ip" \
  -keyout "$temporary/tls.key" \
  -out "$temporary/tls.crt" >/dev/null 2>&1

openssl x509 -in "$temporary/tls.crt" -noout -checkend 86400 >/dev/null
openssl pkey -in "$temporary/tls.key" -noout >/dev/null
certificate_key="$(openssl x509 -in "$temporary/tls.crt" -pubkey -noout)"
private_key="$(openssl pkey -in "$temporary/tls.key" -pubout)"
[[ "$certificate_key" == "$private_key" ]] || fail "Generated certificate and private key do not match"

install -m 444 "$temporary/tls.crt" "$CERTIFICATE"
install -m 400 "$temporary/tls.key" "$PRIVATE_KEY"
if [[ "$(id -u)" == "0" ]]; then
  chown "$EXPECTED_OWNER_UID" "$CERT_DIR" "$CERTIFICATE" "$PRIVATE_KEY"
fi
echo "Generated a self-signed RSA-2048 backend certificate for $expected_host and $expected_ip."
