#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET_ROOT="/model/dockervolume/hku-custom-sso-v4"
cd "$ROOT"

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

env_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' .env
}

set_env_value() {
  local key="$1"
  local value="$2"
  local count
  local temporary
  count="$(grep -c "^${key}=" .env || true)"
  [[ "$count" -le 1 ]] || fail "Duplicate environment key: $key"
  if [[ "$count" -eq 0 ]]; then
    printf '%s=%s\n' "$key" "$value" >> .env
    return
  fi
  temporary="$(mktemp "$ROOT/.env.prepare.XXXXXX")"
  awk -F= -v key="$key" -v value="$value" \
    '$1 == key {print key "=" value; next} {print}' .env > "$temporary"
  chmod 600 "$temporary"
  mv "$temporary" .env
}

[[ "$(pwd -P)" == "$TARGET_ROOT" ]] \
  || fail "Preparation is allowed only at $TARGET_ROOT"
[[ ! -L "$ROOT" ]] || fail "The target root must not be a symbolic link"
[[ -f .env ]] \
  || fail "Missing .env. Start from .env.g5680a.sso-poc04.example"

chmod 600 .env
python3 scripts/agent_api_key.py ensure .env
python3 scripts/agent_api_key.py ensure .env --key-name RAG_API_KEY
set_env_value AUTH_TLS_OWNER_UID "$(id -u)"
if [[ "$(env_value NO_SSO_MINIO_ROOT_PASSWORD)" == REPLACE_WITH_* ]]; then
  set_env_value NO_SSO_MINIO_ROOT_PASSWORD "$(openssl rand -hex 32 | tr -d '\n')"
fi

if grep -q 'REPLACE_WITH_' .env; then
  fail "Replace the HKU client ID and model API key placeholders before preparation"
fi

umask 077
mkdir -p \
  certs \
  data/session \
  data/ui \
  data/coordinator \
  data/object \
  data/vector \
  evidence \
  runtime \
  secrets
chmod 700 data data/session data/ui evidence runtime secrets certs

if [[ "$(id -u)" == "0" ]]; then
  chown 999:1000 data/session
  chown 1000:1000 data/ui
else
  command -v setfacl >/dev/null 2>&1 \
    || fail "setfacl is required for the isolated UI and session data boundaries"
  setfacl -b data data/session data/ui
  setfacl -k data data/session data/ui
  setfacl -m u:999:--x,u:1000:--x,g::---,m::--x,o::--- data
  setfacl -m u:999:rwx,g::---,m::rwx,o::--- data/session
  setfacl -d -m u::rwx,u:999:rwx,g::---,m::rwx,o::--- data/session
  setfacl -m u:1000:rwx,g::---,m::rwx,o::--- data/ui
  setfacl -d -m u::rwx,u:1000:rwx,g::---,m::rwx,o::--- data/ui
fi

[[ -s secrets/oidc-client-secret ]] \
  || fail "Place the newline-free HKU client secret in secrets/oidc-client-secret"
python3 - <<'PY'
from pathlib import Path

raw = Path("secrets/oidc-client-secret").read_bytes()
if b"\n" in raw or b"\r" in raw:
    raise SystemExit("ERROR: The HKU client secret file must not contain a newline")
PY

generate_hex_secret() {
  local path="$1"
  local bytes="$2"
  if [[ ! -s "$path" ]]; then
    openssl rand -hex "$bytes" | tr -d '\n' > "$path"
  fi
}

generate_hex_secret secrets/session-password 32
generate_hex_secret secrets/ui-proxy-secret 32
if [[ ! -s secrets/cookie-secret ]]; then
  openssl rand 32 > secrets/cookie-secret
fi
[[ "$(wc -c < secrets/cookie-secret | tr -d ' ')" == "32" ]] \
  || fail "The cookie secret must contain exactly 32 bytes"

AUTH_TLS_OWNER_UID="$(id -u)" ./GenerateBackendTLS.sh .env
chmod 444 \
  secrets/oidc-client-secret \
  secrets/session-password \
  secrets/ui-proxy-secret \
  secrets/cookie-secret \
  certs/tls.crt
chmod 400 certs/tls.key

python3 scripts/render_auth_config.py \
  .env \
  runtime/auth-gateway.cfg \
  runtime/session-store.conf \
  runtime/auth-gateway-alpha.yaml
python3 scripts/render_sso_entrypoint.py \
  entrypoint/sso-poc04.g5680a.conf.template \
  runtime/auth-entrypoint.conf \
  secrets/ui-proxy-secret \
  "$(env_value AUTH_EXPECTED_HOST)"
chmod 444 \
  runtime/auth-gateway.cfg \
  runtime/auth-gateway-alpha.yaml \
  runtime/session-store.conf
chmod 400 runtime/auth-entrypoint.conf
chmod 600 .env

python3 scripts/sso_poc04_target.py --root "$ROOT" --env "$ROOT/.env" check-config
echo "Prepared the isolated SSO POC04 lane under $ROOT"
