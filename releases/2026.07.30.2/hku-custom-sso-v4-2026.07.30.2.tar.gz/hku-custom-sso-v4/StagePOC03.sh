#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT"
ENV_FILE="${NO_SSO_ENV_FILE:-$ROOT/.env}"
EVIDENCE_ROOT="${NO_SSO_OPERATION_EVIDENCE_DIR:-$ROOT/evidence}"

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

env_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' "$ENV_FILE"
}

[[ -f "$ENV_FILE" ]] || fail "Missing environment file: $ENV_FILE"
mkdir -p "$EVIDENCE_ROOT"
collection="$(env_value NO_SSO_COLLECTION)"
expected_rows="$(env_value NO_SSO_EXPECTED_ROWS)"
backup_name="$(env_value NO_SSO_VECTOR_BACKUP_NAME)"
backup_sha256="$(env_value NO_SSO_VECTOR_BACKUP_SHA256)"
seed_image="$(env_value NO_SSO_VECTOR_SEED_IMAGE)"
data_root="$(env_value NO_SSO_DATA_ROOT)"
seed_container="$(env_value NO_SSO_SEED_CONTAINER)"
seed_container="${seed_container:-hku-no-sso-v3-seed}"
payload="$(env_value NO_SSO_VECTOR_SEED_ROOT)"
payload="${payload:-$ROOT/runtime/vector-seed}"
payload_image_id="$payload/.seed-image-id"
source_backup="$payload/backup/$backup_name"
target_backup="$data_root/object/a-bucket/backup/hku-sync/$backup_name"

expected_image_id="$(docker image inspect "$seed_image" --format '{{.Id}}')"
if docker inspect "$seed_container" >/dev/null 2>&1; then
  actual_image_id="$(docker inspect "$seed_container" --format '{{.Image}}')"
  [[ "$actual_image_id" == "$expected_image_id" ]] \
    || fail "The existing vector seed container belongs to another artifact"
else
  docker create --name "$seed_container" "$seed_image" true >/dev/null
fi

if [[ ! -f "$payload/manifest.json" ]]; then
  mkdir -p "$payload"
  [[ -z "$(find "$payload" -mindepth 1 -print -quit)" ]] \
    || fail "The seed extraction directory is non-empty but incomplete"
  docker cp "$seed_container:/payload/." "$payload/"
  printf '%s\n' "$expected_image_id" > "$payload_image_id"
  chmod 444 "$payload_image_id"
else
  [[ -f "$payload_image_id" ]] || fail "The existing seed extraction has no image provenance marker"
  [[ "$(cat "$payload_image_id")" == "$expected_image_id" ]] \
    || fail "The existing seed extraction belongs to another image"
fi

python3 scripts/verify_vector_seed.py verify \
  --root "$payload" \
  --collection "$collection" \
  --rows "$expected_rows" \
  --backup-name "$backup_name" \
  --expected-backup-sha256 "$backup_sha256" \
  > "$EVIDENCE_ROOT/vector-seed-verification.json"

if [[ -d "$target_backup" ]]; then
  python3 scripts/verify_vector_seed.py compare --left "$source_backup" --right "$target_backup" \
    > "$EVIDENCE_ROOT/vector-seed-existing-tree.json"
else
  mkdir -p "$(dirname "$target_backup")"
  cp -a "$source_backup" "$target_backup"
  python3 scripts/verify_vector_seed.py compare --left "$source_backup" --right "$target_backup" \
    > "$EVIDENCE_ROOT/vector-seed-copied-tree.json"
fi

chmod 700 "$payload/milvus-backup"
echo "POC03 backup payload is staged in the lane-owned object store."
