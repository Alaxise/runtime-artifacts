# g5680a SSO POC04 Deployment

## Release Boundary

This archive installs one isolated authentication lane:

| Resource | Locked value |
|---|---|
| Target root | `/model/dockervolume/hku-custom-sso-v4` |
| Compose project | `hku-sso-v4` |
| Public backend TLS | `0.0.0.0:28380` |
| UI | `127.0.0.1:28180` |
| Authentication gateway | `127.0.0.1:28480` |
| Session store | `127.0.0.1:28679` |
| Agent runtime | `127.0.0.1:28655` |
| Search API | `127.0.0.1:28891` |
| Browser origin | `https://curr-planner.hku.hk` |
| Callback | `https://curr-planner.hku.hk/oauth2/callback` |

The vector coordinator, object store, and vector engine use private Docker bridge addresses without published host ports. Existing lanes on `18380`, `20380`, and `443`, and the shared service on `18890`, are control resources and must remain unchanged.

## Staging

1. Extract the signed release archive directly under `/model/dockervolume` so that the exact target root is created.
2. Copy `.env.g5680a.sso-poc04.example` to `.env`.
3. Set the HKU OIDC client ID and model API key in `.env`.
4. Put the newline-free HKU OIDC client secret in `secrets/oidc-client-secret`.
5. Review `image-list.sso-poc04.g5680a.txt` and `g5680a-sso-poc04-components.lock.json`.

Do not put credentials in Git, the release archive, screenshots, shell history, or logs.

## Deployment

Run the following scripts from the exact target root:

```text
./PrepareSsoPOC04G5680A.sh
./InstallSsoPOC04G5680A.sh
./PreflightSsoPOC04G5680A.sh
./StartSsoPOC04G5680A.sh
```

`StartSsoPOC04G5680A.sh` captures every existing container before startup, restores the immutable POC04 seed into lane-owned storage, starts only `hku-sso-v4`, and compares all pre-existing containers after verification. A failed startup stops only the new lane.

## Acceptance

The automated check proves:

- exact image and ARM64 artifact ownership;
- backend TLS, strict host handling, and security headers;
- HKU issuer, callback, PKCE S256, state, nonce, RS256, and secure cookie configuration;
- staff and student email-domain handling;
- stable OIDC subject propagation;
- forged identity-header rejection;
- POC04 collection identity and row counts;
- both generator and judge use `deepseek-v4-flash`;
- grounded-answer gate, prompt hash, runtime caps, and source-removal protection;
- existing containers and control endpoints remain unchanged.

After HKU routes `https://curr-planner.hku.hk` to `https://10.64.142.35:28380`, complete one staff and one student pilot login, authenticated chat, history, logout, and session-restart test. The deployment is not accepted until this interactive gate passes.

The optional six-case backend regression is:

```text
./RunRegressionSsoPOC04G5680A.sh
```

## Stop And Rollback

To stop only this candidate while preserving all data and evidence:

```text
./StopSsoPOC04G5680A.sh
```

Do not run `docker-compose down`, remove containers or volumes, prune images, or alter another Compose project. HKU should keep its public route on the previous backend until this lane passes local and pilot-user acceptance.
