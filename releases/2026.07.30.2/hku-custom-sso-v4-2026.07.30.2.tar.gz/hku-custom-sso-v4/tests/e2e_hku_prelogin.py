#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import socket
import ssl
import urllib.error
import urllib.parse
import urllib.request


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # type: ignore[no-untyped-def]
        return None


def request(opener: urllib.request.OpenerDirector, url: str, host: str, headers: dict[str, str] | None = None):
    merged = {"Host": host, **(headers or {})}
    req = urllib.request.Request(url, headers=merged)
    try:
        with opener.open(req, timeout=20) as response:
            return response.status, dict(response.headers), response.read()
    except urllib.error.HTTPError as exc:
        return exc.code, dict(exc.headers), exc.read()


def require(condition: object, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--host", required=True)
    parser.add_argument("--client-id", required=True)
    parser.add_argument("--issuer", required=True)
    parser.add_argument("--scope", required=True)
    parser.add_argument("--resolve-to")
    parser.add_argument("--ca-certificate")
    parser.add_argument("--backend-port", type=int, default=19380)
    args = parser.parse_args()

    if args.resolve_to:
        original_getaddrinfo = socket.getaddrinfo

        def resolve_target(host, port, family=0, type=0, proto=0, flags=0):  # type: ignore[no-untyped-def]
            target = args.resolve_to if host == args.host else host
            return original_getaddrinfo(target, port, family, type, proto, flags)

        socket.getaddrinfo = resolve_target  # type: ignore[assignment]

    handlers: list[urllib.request.BaseHandler] = [urllib.request.ProxyHandler({}), NoRedirect()]
    if args.ca_certificate:
        context = ssl.create_default_context(cafile=args.ca_certificate)
        handlers.append(urllib.request.HTTPSHandler(context=context))
    opener = urllib.request.build_opener(*handlers)
    base = args.base.rstrip("/")

    status, headers, body = request(opener, base + "/", args.host)
    require(status == 200, "public landing page did not return 200")
    require(b"AI Student Curriculum Planner" in body, "landing page title is missing")
    require(headers.get("Strict-Transport-Security"), "HSTS is missing")
    require(headers.get("Content-Security-Policy"), "CSP is missing")

    forged = {
        "X-HKU-Auth-User": "forged-browser-user",
        "X-HKU-Auth-Email": "forged@hku.hk",
        "X-Auth-Request-User": "forged-auth-request-user",
        "Authorization": "Bearer forged-browser-token",
    }
    status, _, _ = request(opener, base + "/api/me", args.host, forged)
    require(status in {401, 403}, "browser identity headers bypassed authentication")

    status, headers, _ = request(opener, base + "/oauth2/start?rd=%2F", args.host)
    require(status in {302, 303}, "authentication start did not redirect")
    location = headers.get("Location", "")
    parsed = urllib.parse.urlparse(location)
    query = urllib.parse.parse_qs(parsed.query)
    require(location.startswith(args.issuer + "/"), "authentication redirect uses the wrong issuer")
    require(query.get("client_id") == [args.client_id], "authentication redirect uses the wrong client ID")
    require(
        query.get("redirect_uri") == [f"https://{args.host}/oauth2/callback"],
        "authentication redirect uses the wrong callback",
    )
    require(query.get("scope") == [args.scope], "authentication redirect uses the wrong scopes")
    require(query.get("response_type") == ["code"], "authorization code flow is not configured")
    require(query.get("code_challenge_method") == ["S256"], "PKCE S256 is not configured")
    require(bool(query.get("code_challenge", [""])[0]), "PKCE challenge is missing")
    require(bool(query.get("state", [""])[0]), "state is missing")
    require(bool(query.get("nonce", [""])[0]), "nonce is missing")
    require("127.0.0.1" not in location, "redirect leaked localhost")
    require("10.64.142.35" not in location, "redirect leaked the private target address")
    require(
        f":{args.backend_port}" not in location,
        "redirect leaked the backend port",
    )

    print(json.dumps({"status": "ok", "authorization_endpoint": parsed.path, "pkce": "S256"}))


if __name__ == "__main__":
    main()
