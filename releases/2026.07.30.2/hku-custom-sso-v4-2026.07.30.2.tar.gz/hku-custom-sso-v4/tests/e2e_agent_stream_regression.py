#!/usr/bin/env python3
"""Verify stream and non-stream completion for six historical regressions."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence


CASES = (
    ("V2-12", "In what circumstances will I be recommended discontinuation?"),
    (
        "V2-20",
        "I'm left with an arts and humanities CC course to take and I like exams. "
        "Any recommendations?",
    ),
    (
        "V2-21",
        "What CC courses about politics are available? I have taken CCGL5005 already.",
    ),
    (
        "V1-4",
        "I drop my course accidentally, however, the enrollment add/drop is over, "
        "can I know how to enroll the course again? Top of FormBottom of Form",
    ),
    (
        "V1-9",
        "why my class search result is different from that of my senior classmates????",
    ),
    ("V1-13", "Can I add courses into the temp course list for summer sem now?"),
)

RETRIEVAL_NARRATION_PREFIXES = (
    "let me search",
    "let me look up",
    "i searched",
    "i will search",
)

INTERNAL_TOOL_MARKERS = (
    "<｜｜dsml｜｜tool_calls>",
    "<｜｜dsml｜｜invoke",
    "<tool_call",
    '"tool_calls"',
)


def chat_url(base_url: str) -> str:
    base = base_url.rstrip("/")
    return f"{base}/chat/completions" if base.endswith("/v1") else f"{base}/v1/chat/completions"


def request_for(
    *, url: str, api_key: str, model: str, prompt: str, stream: bool
) -> urllib.request.Request:
    payload: dict[str, Any] = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "stream": stream,
    }
    if stream:
        payload["stream_options"] = {"include_usage": True}
    return urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream" if stream else "application/json",
        },
        method="POST",
    )


def call_nonstream(
    *, url: str, api_key: str, model: str, prompt: str, timeout: float
) -> dict[str, Any]:
    started = time.monotonic()
    request = request_for(
        url=url, api_key=api_key, model=model, prompt=prompt, stream=False
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        body = json.loads(response.read())
        choice = body["choices"][0]
        return {
            "status_code": int(response.status),
            "elapsed_seconds": round(time.monotonic() - started, 3),
            "finish_reason": choice.get("finish_reason"),
            "answer": choice.get("message", {}).get("content", "") or "",
        }


def parse_stream(lines: Iterable[bytes]) -> dict[str, Any]:
    content: list[str] = []
    done_seen = False
    finish_reason = None
    data_event_count = 0
    malformed_event_count = 0
    for raw_line in lines:
        line = raw_line.strip()
        if not line.startswith(b"data:"):
            continue
        payload = line[len(b"data:") :].strip()
        if payload == b"[DONE]":
            done_seen = True
            continue
        try:
            event = json.loads(payload)
        except (json.JSONDecodeError, UnicodeDecodeError):
            malformed_event_count += 1
            continue
        data_event_count += 1
        choices = event.get("choices") if isinstance(event, Mapping) else None
        for choice in choices or []:
            if not isinstance(choice, Mapping):
                continue
            delta = choice.get("delta") if isinstance(choice.get("delta"), Mapping) else {}
            value = delta.get("content")
            if isinstance(value, str) and value:
                content.append(value)
            if choice.get("finish_reason") is not None:
                finish_reason = choice.get("finish_reason")
    return {
        "answer": "".join(content),
        "done_seen": done_seen,
        "finish_reason": finish_reason,
        "data_event_count": data_event_count,
        "malformed_event_count": malformed_event_count,
    }


def call_stream(
    *, url: str, api_key: str, model: str, prompt: str, timeout: float
) -> dict[str, Any]:
    started = time.monotonic()
    request = request_for(
        url=url, api_key=api_key, model=model, prompt=prompt, stream=True
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        parsed = parse_stream(response)
        return {
            "status_code": int(response.status),
            "elapsed_seconds": round(time.monotonic() - started, 3),
            **parsed,
        }


def answer_metadata(result: dict[str, Any]) -> tuple[dict[str, Any], str]:
    answer = str(result.pop("answer", ""))
    result["answer_chars"] = len(answer)
    result["answer_sha256"] = hashlib.sha256(answer.encode("utf-8")).hexdigest()
    return result, answer


def evaluate_pair(
    *, case_id: str, nonstream: dict[str, Any], stream: dict[str, Any]
) -> tuple[dict[str, bool], dict[str, Any], dict[str, Any]]:
    nonstream, nonstream_answer = answer_metadata(nonstream)
    stream, stream_answer = answer_metadata(stream)
    checks = {
        "nonstream_status_200": nonstream["status_code"] == 200,
        "nonstream_finish_reason_stop": nonstream["finish_reason"] == "stop",
        "nonstream_has_answer": bool(nonstream_answer.strip()),
        "stream_status_200": stream["status_code"] == 200,
        "stream_finish_reason_stop": stream["finish_reason"] == "stop",
        "stream_done_seen": stream["done_seen"] is True,
        "stream_has_answer": bool(stream_answer.strip()),
        "stream_events_well_formed": stream["malformed_event_count"] == 0,
        "stream_has_no_retrieval_narration": not stream_answer.casefold().startswith(
            RETRIEVAL_NARRATION_PREFIXES
        ),
        "stream_has_no_internal_tool_markup": not any(
            marker in stream_answer.casefold() for marker in INTERNAL_TOOL_MARKERS
        ),
    }
    if case_id == "V2-20":
        for label, answer in (
            ("nonstream", nonstream_answer),
            ("stream", stream_answer),
        ):
            codes = set(
                re.findall(r"\bCC(?:ST|HU|GL|CH)\d{4}\b", answer.upper())
            )
            checks[f"{label}_arts_humanities_codes_in_scope"] = all(
                code.startswith("CCHU") for code in codes
            )
    return checks, nonstream, stream


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    temporary.chmod(0o600)
    temporary.replace(path)


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--api-key-env", default="AUTH_AGENT_API_KEY")
    parser.add_argument("--model", default="hku-rag-agent")
    parser.add_argument("--timeout-seconds", type=float, default=240)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    api_key = os.environ.get(args.api_key_env, "")
    if not api_key:
        parser.error(f"{args.api_key_env} is required")

    url = chat_url(args.base_url)
    results: list[dict[str, Any]] = []
    for index, (case_id, prompt) in enumerate(CASES, start=1):
        print(f"[{index}/{len(CASES)}] {case_id}", flush=True)
        error = ""
        checks: dict[str, bool] = {}
        nonstream: dict[str, Any] = {}
        stream: dict[str, Any] = {}
        try:
            nonstream = call_nonstream(
                url=url,
                api_key=api_key,
                model=args.model,
                prompt=prompt,
                timeout=args.timeout_seconds,
            )
            stream = call_stream(
                url=url,
                api_key=api_key,
                model=args.model,
                prompt=prompt,
                timeout=args.timeout_seconds,
            )
            checks, nonstream, stream = evaluate_pair(
                case_id=case_id, nonstream=nonstream, stream=stream
            )
        except (OSError, ValueError, KeyError, RuntimeError) as exc:
            error = f"{type(exc).__name__}: {exc}"
        results.append(
            {
                "case_id": case_id,
                "nonstream": nonstream,
                "stream": stream,
                "checks": checks,
                "pass": bool(checks) and all(checks.values()),
                "error": error,
            }
        )
        if index < len(CASES):
            time.sleep(0.5)

    pass_count = sum(result["pass"] for result in results)
    summary = {
        "completed_at": dt.datetime.now(dt.timezone.utc).isoformat(),
        "case_count": len(results),
        "pass_count": pass_count,
        "fail_count": len(results) - pass_count,
        "results": results,
    }
    write_json(args.output, summary)
    print(f"pass_count={pass_count} fail_count={len(results) - pass_count}")
    return 0 if pass_count == len(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
