#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

env_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' .env
}

mkdir -p evidence
chmod 700 evidence
export SSO_TARGET_AGENT_API_KEY="$(env_value AUTH_AGENT_API_KEY)"
python3 tests/e2e_agent_stream_regression.py \
  --base-url "http://127.0.0.1:$(env_value NO_SSO_AGENT_HOST_PORT)" \
  --api-key-env SSO_TARGET_AGENT_API_KEY \
  --output "$ROOT/evidence/six-case-stream-regression.json"
unset SSO_TARGET_AGENT_API_KEY
echo "Six-case target regression completed."
