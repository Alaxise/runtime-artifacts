# Third-party notices

This deployment uses unmodified container artifacts from the following projects. Their license and notice files remain inside their respective images.

| Component | Pinned version | License reference |
|---|---|---|
| NGINX Open Source | `1.30.4-alpine` | 2-clause BSD-like license, https://github.com/nginx/nginx/blob/master/LICENSE |
| OAuth2 Proxy | `v7.15.3` | MIT License, https://github.com/oauth2-proxy/oauth2-proxy/blob/v7.15.3/LICENSE |
| Redis Open Source | `8.2.7` | Redis 8 tri-license, https://github.com/redis/redis/blob/8.2/LICENSE.txt |
| etcd | `v3.5.18` | Apache License 2.0, https://github.com/etcd-io/etcd/blob/v3.5.18/LICENSE |
| MinIO | `RELEASE.2024-05-28T17-19-04Z` | GNU AGPL v3.0, https://github.com/minio/minio/blob/master/LICENSE |
| Milvus | `v2.6.3` | Apache License 2.0, https://github.com/milvus-io/milvus/blob/v2.6.3/LICENSE |

The deployment does not rename or modify these infrastructure binaries. The application artifacts are separately identified in `g5680a-sso-poc04-components.lock.json`.

This notice is an inventory aid, not a substitute for legal review of the selected licenses or transitive image dependencies.
