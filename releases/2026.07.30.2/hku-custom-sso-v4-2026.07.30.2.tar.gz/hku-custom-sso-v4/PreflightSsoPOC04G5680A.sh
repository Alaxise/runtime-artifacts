#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

python3 scripts/sso_poc04_target.py --root "$ROOT" --env "$ROOT/.env" check-config
"$ROOT/scripts/compose_no_sso.sh" \
  -p hku-sso-v4 \
  -f compose.sso-poc04.g5680a.yml \
  config >/dev/null
python3 scripts/sso_poc04_target.py --root "$ROOT" --env "$ROOT/.env" preflight
