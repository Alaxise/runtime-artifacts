#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT"
ENV_FILE="${NO_SSO_ENV_FILE:-$ROOT/.env}"
EVIDENCE_ROOT="${NO_SSO_OPERATION_EVIDENCE_DIR:-$ROOT/evidence}"
OPERATION_RUNTIME="${NO_SSO_OPERATION_RUNTIME_DIR:-$ROOT/runtime}"

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

env_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' "$ENV_FILE"
}

milvus_post() {
  local path="$1"
  local body="$2"
  curl -fsS \
    -H "Authorization: Bearer root:Milvus" \
    -H "Request-Timeout: 30" \
    -H "Content-Type: application/json" \
    -d "$body" \
    "http://${milvus_address}:${milvus_port}${path}"
}

collection_exists() {
  milvus_post /v2/vectordb/collections/list '{"dbName":"default"}' \
    | grep -Fq "\"${collection}\""
}

query_filter_count() {
  local filter="$1"
  local response=""
  local count=""
  local attempt

  for attempt in $(seq 1 180); do
    response="$(
      milvus_post /v2/vectordb/entities/query \
        "{\"dbName\":\"default\",\"collectionName\":\"$collection\",\"filter\":\"$filter\",\"outputFields\":[\"count(*)\"]}" \
        2>/dev/null || true
    )"
    if count="$(python3 - "$response" <<'PY'
import json
import sys

try:
    payload = json.loads(sys.argv[1])
    if int(payload.get("code", -1)) != 0:
        raise ValueError
    print(int(payload["data"][0]["count(*)"]))
except (IndexError, KeyError, TypeError, ValueError, json.JSONDecodeError):
    raise SystemExit(1)
PY
    )"; then
      printf '%s\n' "$count"
      return 0
    fi
    sleep 2
  done

  printf '%s\n' "$response" > "$EVIDENCE_ROOT/vector-query-error.json"
  fail "The restored collection did not become queryable for filter: $filter"
}

[[ -f "$ENV_FILE" ]] || fail "Missing environment file: $ENV_FILE"
mkdir -p "$EVIDENCE_ROOT" "$OPERATION_RUNTIME"
collection="$(env_value NO_SSO_COLLECTION)"
expected_rows="$(env_value NO_SSO_EXPECTED_ROWS)"
expected_latest_rows="$(env_value NO_SSO_EXPECTED_LATEST_ROWS)"
expected_not_latest_rows="$(env_value NO_SSO_EXPECTED_NOT_LATEST_ROWS)"
backup_name="$(env_value NO_SSO_VECTOR_BACKUP_NAME)"
data_root="$(env_value NO_SSO_DATA_ROOT)"
milvus_address="$(env_value NO_SSO_VECTOR_ENGINE_ADDRESS)"
milvus_port="$(env_value NO_SSO_VECTOR_ENGINE_PORT)"
milvus_port="${milvus_port:-19530}"
milvus_http_port="$(env_value NO_SSO_VECTOR_ENGINE_HTTP_PORT)"
milvus_http_port="${milvus_http_port:-9091}"
etcd_address="$(env_value NO_SSO_VECTOR_COORDINATOR_ADDRESS)"
etcd_port="$(env_value NO_SSO_VECTOR_COORDINATOR_PORT)"
etcd_port="${etcd_port:-2379}"
minio_address="$(env_value NO_SSO_VECTOR_OBJECT_ADDRESS)"
minio_port="$(env_value NO_SSO_VECTOR_OBJECT_PORT)"
minio_port="${minio_port:-9000}"
minio_user="$(env_value NO_SSO_MINIO_ROOT_USER)"
minio_password="$(env_value NO_SSO_MINIO_ROOT_PASSWORD)"
payload="$(env_value NO_SSO_VECTOR_SEED_ROOT)"
payload="${payload:-$ROOT/runtime/vector-seed}"
source_backup="$payload/backup/$backup_name"
target_backup="$data_root/object/a-bucket/backup/hku-sync/$backup_name"

[[ -x "$payload/milvus-backup" ]] || fail "The verified vector seed has not been staged"
[[ -d "$target_backup" ]] || fail "The lane-owned backup payload has not been staged"
python3 scripts/verify_vector_seed.py compare --left "$source_backup" --right "$target_backup" \
  > "$EVIDENCE_ROOT/vector-seed-restore-tree.json"

backup_binary="$payload/milvus-backup"
restore_config="$OPERATION_RUNTIME/vector-restore.yaml"
cat > "$restore_config" <<EOF
log:
  level: info
  console: true
  file:
    filename: "$EVIDENCE_ROOT/vector-restore.log"
milvus:
  address: "$milvus_address"
  port: $milvus_port
  user: "root"
  password: "Milvus"
  tlsMode: 0
  rpcChannelName: "by-dev-replicate-msg"
  etcd:
    endpoints: "$etcd_address:$etcd_port"
    rootPath: "by-dev"
minio:
  storageType: "minio"
  address: "$minio_address"
  port: $minio_port
  region: ""
  accessKeyID: "$minio_user"
  secretAccessKey: "$minio_password"
  useSSL: false
  useIAM: false
  bucketName: "a-bucket"
  rootPath: "files"
  backupStorageType: "minio"
  backupAddress: "$minio_address"
  backupPort: $minio_port
  backupAccessKeyID: "$minio_user"
  backupSecretAccessKey: "$minio_password"
  backupBucketName: "a-bucket"
  backupRootPath: "backup/hku-sync"
  backupUseSSL: false
  crossStorage: false
backup:
  parallelism:
    copydata: 8
    backupCollection: 1
    backupSegment: 16
    restoreCollection: 1
    importJob: 4
  keepTempFiles: false
  gcPause:
    enable: false
    address: "http://$milvus_address:$milvus_http_port"
EOF
chmod 600 "$restore_config"

"$backup_binary" --config "$restore_config" check >/dev/null
"$backup_binary" --config "$restore_config" get -n "$backup_name" \
  > "$EVIDENCE_ROOT/vector-backup-record.json"

if ! collection_exists; then
  "$backup_binary" --config "$restore_config" restore \
    -n "$backup_name" \
    --filter "default.$collection" \
    --rebuild_index \
    > "$EVIDENCE_ROOT/vector-restore-command.log"
fi

for _ in $(seq 1 180); do
  stats="$(milvus_post /v2/vectordb/collections/get_stats "{\"dbName\":\"default\",\"collectionName\":\"$collection\"}" 2>/dev/null || true)"
  if python3 - "$expected_rows" "$stats" <<'PY'
import json
import sys
expected = int(sys.argv[1])
try:
    payload = json.loads(sys.argv[2])
    value = payload.get("data", {}).get("row_count", payload.get("data", {}).get("rowCount"))
    raise SystemExit(0 if int(value) == expected else 1)
except (TypeError, ValueError, json.JSONDecodeError):
    raise SystemExit(1)
PY
  then
    break
  fi
  sleep 2
done

[[ -n "${stats:-}" ]] || fail "The restored collection did not expose row statistics"
describe="$(milvus_post /v2/vectordb/collections/describe "{\"dbName\":\"default\",\"collectionName\":\"$collection\"}")"
python3 - "$collection" "$expected_rows" "$stats" "$describe" > "$EVIDENCE_ROOT/vector-collection.json" <<'PY'
import json
import sys

collection = sys.argv[1]
expected_rows = int(sys.argv[2])
stats = json.loads(sys.argv[3])
describe = json.loads(sys.argv[4])
row_count = stats.get("data", {}).get("row_count", stats.get("data", {}).get("rowCount"))
if int(row_count) != expected_rows:
    raise SystemExit(f"row count mismatch: {row_count} != {expected_rows}")
fields = describe.get("data", {}).get("fields", [])
latest = [field for field in fields if field.get("fieldName", field.get("name")) == "is_latest"]
if not latest:
    raise SystemExit("is_latest field is absent from the restored collection")
print(json.dumps({"collection": collection, "row_count": int(row_count), "is_latest_field": True}, sort_keys=True))
PY

load_response="$(
  milvus_post /v2/vectordb/collections/load \
    "{\"dbName\":\"default\",\"collectionName\":\"$collection\"}"
)"
python3 - "$load_response" <<'PY'
import json
import sys

payload = json.loads(sys.argv[1])
if int(payload.get("code", -1)) != 0:
    raise SystemExit(
        f"Milvus refused to load the restored collection: {payload.get('message', payload)}"
    )
PY
latest_count="$(query_filter_count "is_latest == true")"
not_latest_count="$(query_filter_count "is_latest == false")"
python3 - \
  "$collection" \
  "$expected_rows" \
  "$expected_latest_rows" \
  "$expected_not_latest_rows" \
  "$latest_count" \
  "$not_latest_count" \
  > "$EVIDENCE_ROOT/vector-latest-counts.json" <<'PY'
import json
import sys

collection = sys.argv[1]
expected_total, expected_latest, expected_not_latest = map(int, sys.argv[2:5])
actual_latest, actual_not_latest = map(int, sys.argv[5:7])
if actual_latest != expected_latest:
    raise SystemExit(
        f"is_latest=true row count changed: expected {expected_latest}, got {actual_latest}"
    )
if actual_not_latest != expected_not_latest:
    raise SystemExit(
        "is_latest=false row count changed: "
        f"expected {expected_not_latest}, got {actual_not_latest}"
    )
if actual_latest + actual_not_latest != expected_total:
    raise SystemExit("latest-tag counts do not reconcile to the collection total")
print(
    json.dumps(
        {
            "collection": collection,
            "total": expected_total,
            "is_latest_true": actual_latest,
            "is_latest_false": actual_not_latest,
            "is_latest_null": 0,
        },
        sort_keys=True,
    )
)
PY

echo "POC03 vector collection is ready in the lane-owned store."
