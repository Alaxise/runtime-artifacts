#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
PROJECT=hku-sso-v4
COMPOSE=(
  "$ROOT/scripts/compose_no_sso.sh"
  -p "$PROJECT"
  -f compose.sso-poc04.g5680a.yml
)
SNAPSHOT="$ROOT/evidence/control-before.json"

env_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' .env
}

wait_http() {
  local url="$1"
  local label="$2"
  shift 2
  for _ in $(seq 1 180); do
    if curl "$@" -fsS "$url" >/dev/null 2>&1; then
      return 0
    fi
    sleep 2
  done
  echo "ERROR: $label did not become ready: $url" >&2
  return 1
}

wait_milvus() {
  local address="$1"
  for _ in $(seq 1 180); do
    if curl -fsS \
      -H 'Authorization: Bearer root:Milvus' \
      -H 'Content-Type: application/json' \
      -d '{"dbName":"default"}' \
      "http://${address}:19530/v2/vectordb/collections/list" >/dev/null 2>&1; then
      return 0
    fi
    sleep 2
  done
  echo "ERROR: Vector store did not become ready at ${address}:19530" >&2
  return 1
}

started=0
verified=0

stop_unverified_lane() {
  local status=$?
  trap - EXIT INT TERM
  if [[ "$started" == "1" && "$verified" != "1" ]]; then
    echo "Verification did not complete; stopping only the unverified $PROJECT containers." >&2
    "${COMPOSE[@]}" stop || true
  fi
  exit "$status"
}

./PrepareSsoPOC04G5680A.sh
./InstallSsoPOC04G5680A.sh
./PreflightSsoPOC04G5680A.sh
python3 scripts/sso_poc04_target.py \
  --root "$ROOT" \
  --env "$ROOT/.env" \
  capture \
  --output "$SNAPSHOT"
NO_SSO_ENV_FILE="$ROOT/.env" \
NO_SSO_OPERATION_EVIDENCE_DIR="$ROOT/evidence" \
  ./StagePOC03.sh

trap stop_unverified_lane EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
started=1

"${COMPOSE[@]}" up -d vector-coordinator vector-object vector-engine
python3 scripts/sso_poc04_target.py \
  --root "$ROOT" \
  --env "$ROOT/.env" \
  sync-vector-addresses
wait_http \
  "http://$(env_value NO_SSO_VECTOR_COORDINATOR_ADDRESS):2379/health" \
  "vector coordinator"
wait_http \
  "http://$(env_value NO_SSO_VECTOR_OBJECT_ADDRESS):9000/minio/health/live" \
  "object store"
wait_milvus "$(env_value NO_SSO_VECTOR_ENGINE_ADDRESS)"
NO_SSO_ENV_FILE="$ROOT/.env" \
NO_SSO_OPERATION_EVIDENCE_DIR="$ROOT/evidence" \
NO_SSO_OPERATION_RUNTIME_DIR="$ROOT/runtime" \
  ./RestorePOC03.sh

"${COMPOSE[@]}" up -d --no-deps rag-api
wait_http "http://127.0.0.1:$(env_value NO_SSO_RAG_HOST_PORT)/health" "search API"
"${COMPOSE[@]}" up -d --no-deps agent-runtime
wait_http "http://127.0.0.1:$(env_value NO_SSO_AGENT_HOST_PORT)/health" "agent runtime"
"${COMPOSE[@]}" up -d --no-deps web-ui session-store
wait_http "http://127.0.0.1:$(env_value AUTH_UI_HOST_PORT)/healthz" "application UI"
"${COMPOSE[@]}" up -d --no-deps auth-gateway
"${COMPOSE[@]}" up -d --no-deps entrypoint
wait_http \
  "https://$(env_value AUTH_EXPECTED_HOST):$(env_value AUTH_ENTRYPOINT_PORT)/__health" \
  "TLS entrypoint" \
  --resolve "$(env_value AUTH_EXPECTED_HOST):$(env_value AUTH_ENTRYPOINT_PORT):127.0.0.1" \
  --cacert certs/tls.crt

./CheckSsoPOC04G5680A.sh
verified=1
trap - EXIT INT TERM
echo "SSO POC04 target started and verified."
