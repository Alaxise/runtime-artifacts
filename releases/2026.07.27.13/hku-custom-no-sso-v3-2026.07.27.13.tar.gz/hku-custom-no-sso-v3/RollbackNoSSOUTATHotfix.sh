#!/usr/bin/env bash
set -Eeuo pipefail

TARGET_ROOT="${1:-/model/dockervolume/hku-custom-no-sso-v3}"
EVIDENCE_DIR="${2:-}"
EXPECTED_ROOT="/model/dockervolume/hku-custom-no-sso-v3"
PROJECT="hku-no-sso-v3"
COMPOSE_FILE="$TARGET_ROOT/compose.no-sso-rag-v2.g5680a.yml"
ENV_FILE="$TARGET_ROOT/.env"

compose_target() {
  (
    cd "$TARGET_ROOT"
    docker-compose -p "$PROJECT" -f "$COMPOSE_FILE" "$@"
  )
}
APPLICATION_CONTAINERS=(
  hku-no-sso-v3-entrypoint
  hku-no-sso-v3-ui
)
APPROVED_PROXY_IMAGES=(
  "nginx:1.27-alpine@sha256:65645c7bb6a0661892a8b03b89d0743208a18dd2f3f17a54ef4b76fb8e2f2a10"
  "nginx:1.30.4-alpine@sha256:97d490c12ba55b4946b01546d1c3ed324e8d41ab1c9fcb2a616aa470620e5b46"
)
APPROVED_UI_IMAGES=(
  "middletaste/hku-custom-web:no-sso-v2-d6620b808330-arm64@sha256:db3a35c168d9fb729348f8bdcde1feca734c88e0f532ca6a647eabbd07d14b66"
  "middletaste/hku-custom-web:no-sso-v3-f0d66beec43d-arm64@sha256:f068dd8e855ea40b929f3ee9cb79ca5ea937063f3a80ee459e06d57219ec924b"
  "middletaste/hku-custom-web:no-sso-v4-59c237429d40-arm64@sha256:6122a3755092c4f28143b9ec50b0c831705aee0e6f31d290206df269a96204df"
  "middletaste/hku-custom-web:no-sso-v4-f6bc882bfde8-arm64@sha256:7da63e25d5a9edb7260c4ab6aa699d02f445372b228a96b6fae3288d19e38fb3"
)
APPROVED_AGENT_IMAGES=(
  "middletaste/hku-custom-core:no-sso-v2-37162016e4ca-arm64@sha256:628c4a7e7fdc4766c094bfd32928eb72a57658e3f9e15fa3f899d9b3d44f3449"
  "middletaste/hku-custom-core:poc03-latest-942fed8-arm64@sha256:9ba0344a7efa8aa38d2f1cf426c5ecbe4cb9a3d13f9ca33a269dc43d2ada3c5a"
  "middletaste/hku-custom-core:poc03-family-d38e4bf-arm64@sha256:f3c8e9dbf105ae61a988fd29f26172cc5a431badd35727829e19fe281b1fceab"
  "middletaste/hku-custom-core:poc03-family-f05cc96e5106-arm64@sha256:5faab8a03368a2ab2e980e106de42f480095e714e7db7ce90b49b5c95e8b5e36"
)
APPROVED_RAG_IMAGES=(
  "middletaste/hku-custom-search:no-sso-v2-d13b3054f68d-arm64@sha256:c5cde614860ef5abce423e31bf86015df4304b1f9bf1b6a8010950a610dc5d53"
  "middletaste/hku-custom-search:poc03-latest-20bab76-arm64@sha256:1123d1d1a92b85fc602472951d6d1e0e0cd1f31468b122f78625d9838c131692"
  "middletaste/hku-custom-search:poc03-family-bfd6e8c-arm64@sha256:e84172e5b05085b79d0ba5f8012aef7012275710c47c359771c222e184f34105"
)
RESTORE_FILES=(
  CheckNoSSOG5680A.sh
  RunRegressionNoSSOTarget.sh
  RestorePOC03.sh
  StagePOC03.sh
  compose.no-sso-rag-v2.g5680a.yml
  entrypoint/no-sso.g5680a.template.conf
  g5680a-no-sso-rag-v2-components.lock.json
  image-list.no-sso-rag-v2.g5680a.txt
  scripts/compose_no_sso.sh
  scripts/no_sso_target_config.py
  scripts/no_sso_target_control.py
  scripts/verify_no_sso_ingress.py
  scripts/verify_vector_seed.py
  tests/e2e_agent_stream_regression.py
  tests/e2e_no_sso_rehearsal.py
)

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

env_value() {
  local key="$1"
  awk -F= -v key="$key" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' "$ENV_FILE"
}

file_env_value() {
  local path="$1"
  local key="$2"
  awk -F= -v key="$key" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' "$path"
}

contains_value() {
  local candidate="$1"
  shift
  local value
  for value in "$@"; do
    [[ "$candidate" == "$value" ]] && return 0
  done
  return 1
}

wait_http() {
  local url="$1"
  local label="$2"
  local authority="${3:-}"
  local deadline=$((SECONDS + 180))
  while true; do
    if [[ -n "$authority" ]]; then
      curl -fsS -H "Host: $authority" "$url" >/dev/null 2>&1 && return 0
    else
      curl -fsS "$url" >/dev/null 2>&1 && return 0
    fi
    (( SECONDS < deadline )) || fail "$label did not become ready: $url"
    sleep 3
  done
}

restore_file_atomically() {
  local source="$1"
  local destination="$2"
  python3 - "$source" "$destination" <<'PY'
import os
import shutil
import sys
import tempfile
from pathlib import Path

source = Path(sys.argv[1])
destination = Path(sys.argv[2])
descriptor, temporary_name = tempfile.mkstemp(
    dir=destination.parent, prefix=f".{destination.name}.restore."
)
os.close(descriptor)
temporary = Path(temporary_name)
try:
    shutil.copy2(source, temporary)
    os.replace(temporary, destination)
finally:
    temporary.unlink(missing_ok=True)
PY
}

[[ "$TARGET_ROOT" == "$EXPECTED_ROOT" ]] || fail "target root is not approved"
[[ -n "$EVIDENCE_DIR" && -f "$EVIDENCE_DIR/env.before" ]] \
  || fail "provide the preserved UAT hotfix evidence directory"
[[ -f "$COMPOSE_FILE" && -f "$ENV_FILE" ]] || fail "target deployment is incomplete"
resolved_evidence="$(CDPATH= cd -- "$EVIDENCE_DIR" && pwd -P)"
[[ "$resolved_evidence" == "$TARGET_ROOT"/evidence/uat-http-hotfix-* ]] \
  || fail "rollback evidence is outside the approved target evidence path"
EVIDENCE_DIR="$resolved_evidence"

for name in "${APPLICATION_CONTAINERS[@]}"; do
  project="$(
    docker inspect "$name" \
      --format '{{index .Config.Labels "com.docker.compose.project"}}' 2>/dev/null
  )"
  [[ "$project" == "$PROJECT" ]] || fail "container is outside the approved project: $name"
done

contains_value \
  "$(file_env_value "$EVIDENCE_DIR/env.before" NO_SSO_PROXY_IMAGE)" \
  "${APPROVED_PROXY_IMAGES[@]}" \
  || fail "preserved entrypoint image is outside the approved rollback boundary"
contains_value \
  "$(file_env_value "$EVIDENCE_DIR/env.before" NO_SSO_UI_IMAGE)" \
  "${APPROVED_UI_IMAGES[@]}" \
  || fail "preserved UI image is outside the approved rollback boundary"
contains_value \
  "$(file_env_value "$EVIDENCE_DIR/env.before" NO_SSO_AGENT_IMAGE)" \
  "${APPROVED_AGENT_IMAGES[@]}" \
  || fail "preserved agent image is outside the approved rollback boundary"
contains_value \
  "$(file_env_value "$EVIDENCE_DIR/env.before" NO_SSO_RAG_IMAGE)" \
  "${APPROVED_RAG_IMAGES[@]}" \
  || fail "preserved search image is outside the approved rollback boundary"
cd "$TARGET_ROOT"

cp -p "$EVIDENCE_DIR/env.before" "$ENV_FILE"
for relative in "${RESTORE_FILES[@]}"; do
  backup="$EVIDENCE_DIR/files/$relative"
  [[ ! -f "$backup" ]] || cp -p "$backup" "$TARGET_ROOT/$relative"
done
[[ ! -f "$EVIDENCE_DIR/runtime/no-sso-entrypoint.conf" ]] \
  || restore_file_atomically \
    "$EVIDENCE_DIR/runtime/no-sso-entrypoint.conf" \
    "$TARGET_ROOT/runtime/no-sso-entrypoint.conf"
[[ ! -f "$EVIDENCE_DIR/manifest.before" ]] \
  || cp -p "$EVIDENCE_DIR/manifest.before" "$TARGET_ROOT/g5680a-no-sso-rag-v2-components.lock.json"
[[ ! -f "$EVIDENCE_DIR/image-list.before" ]] \
  || cp -p "$EVIDENCE_DIR/image-list.before" "$TARGET_ROOT/image-list.no-sso-rag-v2.g5680a.txt"

compose_target config >/dev/null
compose_target up -d --no-deps web-ui
wait_http "http://127.0.0.1:$(env_value NO_SSO_UI_HOST_PORT)/healthz" "previous UI"
compose_target up -d --no-deps --force-recreate entrypoint
wait_http \
  "http://127.0.0.1:$(env_value NO_SSO_ENTRYPOINT_PORT)/healthz" \
  "entrypoint" \
  "10.64.142.35:20380"

echo "Previous UAT entrypoint and UI settings restored."
echo "Agent, search, vector data, application data, and evidence paths were preserved."
