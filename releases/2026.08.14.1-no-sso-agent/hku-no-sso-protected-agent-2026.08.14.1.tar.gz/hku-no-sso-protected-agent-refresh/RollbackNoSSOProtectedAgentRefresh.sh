#!/usr/bin/env bash
set -Eeuo pipefail

PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET_ROOT="/model/dockervolume/hku-custom-no-sso-v3"
PROJECT="hku-no-sso-v3"
BASE_COMPOSE="$TARGET_ROOT/compose.no-sso-rag-v2.g5680a.yml"
UPDATE_DIR="${1:-}"

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

wait_healthy() {
  local state=""
  for _ in $(seq 1 90); do
    state="$(docker inspect hku-no-sso-v3-agent --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' 2>/dev/null || true)"
    [[ "$state" == "healthy" ]] && return 0
    sleep 2
  done
  fail "restored agent did not become healthy"
}

[[ -n "$UPDATE_DIR" ]] \
  || fail "usage: $0 /model/dockervolume/hku-custom-no-sso-v3/updates/<update>"
case "$(cd "$UPDATE_DIR" 2>/dev/null && pwd -P || true)" in
  "$TARGET_ROOT"/updates/*) ;;
  *) fail "rollback evidence directory is outside the authorized target root" ;;
esac
for file in before.env compose.before.yml agent-refresh-before.json control-before.json; do
  [[ -f "$UPDATE_DIR/$file" ]] || fail "rollback evidence is missing: $file"
done
cmp -s "$UPDATE_DIR/compose.before.yml" "$BASE_COMPOSE" \
  || fail "live base Compose file drifted"

temporary="$(mktemp "$TARGET_ROOT/.env.rollback.XXXXXX")"
cp "$UPDATE_DIR/before.env" "$temporary"
chmod 600 "$temporary"
mv "$temporary" "$TARGET_ROOT/.env"

COMPOSE=(
  "$PACKAGE_ROOT/scripts/compose_no_sso.sh"
  -p "$PROJECT"
  -f "$BASE_COMPOSE"
)
cd "$TARGET_ROOT"
"${COMPOSE[@]}" config >/dev/null
"${COMPOSE[@]}" up -d --no-deps --force-recreate agent-runtime
wait_healthy

python3 "$PACKAGE_ROOT/scripts/no_sso_agent_refresh_control.py" \
  compare-preserved --snapshot "$UPDATE_DIR/agent-refresh-before.json"
python3 "$PACKAGE_ROOT/scripts/no_sso_agent_refresh_control.py" \
  verify-agent --snapshot "$UPDATE_DIR/agent-refresh-before.json"
python3 "$PACKAGE_ROOT/scripts/no_sso_target_control.py" \
  --root "$TARGET_ROOT" --env "$TARGET_ROOT/.env" \
  compare --before "$UPDATE_DIR/control-before.json"
python3 "$PACKAGE_ROOT/scripts/no_sso_target_control.py" \
  --root "$TARGET_ROOT" --env "$TARGET_ROOT/.env" verify-target
printf '%s\n' "ROLLED_BACK $UPDATE_DIR" > "$UPDATE_DIR/deployment-status.txt"
chmod 600 "$UPDATE_DIR/deployment-status.txt"
echo "Prior no-SSO agent image and runtime contract restored."
