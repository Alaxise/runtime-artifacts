#!/usr/bin/env bash
set -euo pipefail

PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET_ROOT="/model/dockervolume/hku-custom-no-sso-v3"
CONTRACT="$PACKAGE_ROOT/.env.g5680a.no-sso-protected-agent.example"
UPDATE_DIR="${1:-}"

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

contract_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' "$CONTRACT"
}

live_value() {
  awk -F= -v key="$1" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' "$TARGET_ROOT/.env"
}

[[ -n "$UPDATE_DIR" && -f "$UPDATE_DIR/agent-refresh-before.json" ]] \
  || fail "agent-refresh snapshot is missing"
mkdir -p "$UPDATE_DIR/evidence"

python3 "$PACKAGE_ROOT/scripts/no_sso_target_control.py" \
  --root "$TARGET_ROOT" --env "$TARGET_ROOT/.env" verify-target
python3 "$PACKAGE_ROOT/scripts/no_sso_agent_refresh_control.py" \
  compare-preserved --snapshot "$UPDATE_DIR/agent-refresh-before.json"
python3 "$PACKAGE_ROOT/scripts/no_sso_target_control.py" \
  --root "$TARGET_ROOT" --env "$TARGET_ROOT/.env" \
  compare --before "$UPDATE_DIR/control-before.json"
python3 "$PACKAGE_ROOT/scripts/no_sso_agent_refresh_control.py" \
  verify-agent \
  --snapshot "$UPDATE_DIR/agent-refresh-before.json" \
  --expected-image-id "$(contract_value REFRESH_CANDIDATE_AGENT_IMAGE_ID)"

actual_image_id="$(docker inspect hku-no-sso-v3-agent --format '{{.Image}}')"
[[ "$actual_image_id" == "$(contract_value REFRESH_CANDIDATE_AGENT_IMAGE_ID)" ]] \
  || fail "running agent differs from the qualified protected image"
[[ "$(live_value NO_SSO_AGENT_IMAGE)" == "$(contract_value REFRESH_CANDIDATE_AGENT_IMAGE)" ]] \
  || fail "live environment is not pinned to the protected image digest"

for label in \
  "org.opencontainers.image.revision=$(contract_value REFRESH_EXPECTED_SOURCE_REVISION)" \
  "hku.agent.behavior.revision=$(contract_value REFRESH_EXPECTED_BEHAVIOR_REVISION)" \
  "hku.agent.prompt.sha256=$(contract_value REFRESH_EXPECTED_PROMPT_SHA256)"; do
  key="${label%%=*}"
  value="${label#*=}"
  actual="$(docker image inspect "$(contract_value REFRESH_CANDIDATE_AGENT_IMAGE)" --format "{{index .Config.Labels \"$key\"}}")"
  [[ "$actual" == "$value" ]] || fail "protected image label changed: $key"
done

agent_env="$(docker inspect hku-no-sso-v3-agent --format '{{range .Config.Env}}{{println .}}{{end}}')"
for setting in \
  'DEEPSEEK_MODEL=deepseek-v4-flash' \
  'DEEPSEEK_JUDGE_MODEL=deepseek-v4-flash' \
  'HKU_AGENT_MODEL_MAX_TOKENS=4096' \
  'HKU_AGENT_CONTEXT_FILE_MAX_CHARS=65536' \
  'HKU_AGENT_DASHBOARD_ENABLED=false' \
  'HKU_GROUNDED_JUDGE_TIMEOUT_SECONDS=8' \
  'HKU_GROUNDED_JUDGE_MAX_TOKENS=1024' \
  'HKU_GROUNDED_REPAIR_TIMEOUT_SECONDS=6' \
  'HKU_GROUNDED_REPAIR_MAX_TOKENS=4096' \
  'HKU_GLOBAL_DEADLINE_SECONDS=60' \
  'HKU_COURSE_SEARCH_RETRIEVAL_EVALUATOR_TIMEOUT_SECONDS=4' \
  'HKU_COURSE_SEARCH_QUALIFIED_ROUTING=false' \
  'HKU_COURSE_SEARCH_ANSWER_HINTS=false' \
  'HKU_TIMETABLE_DB_PATH=/opt/hku-runtime/data/timetable.sqlite3' \
  'HKU_TIMETABLE_QUERY_TIMEOUT_SECONDS=2' \
  'HKU_TIMETABLE_CONFLICT_TIMEOUT_SECONDS=2' \
  'GATEWAY_ALLOW_ALL_USERS=true' \
  'LOG_LEVEL=ERROR' \
  'HKU_AGENT_LOG_LEVEL=ERROR'; do
  grep -Fqx "$setting" <<<"$agent_env" || fail "agent runtime setting changed: $setting"
done

docker exec hku-no-sso-v3-agent sh -ec '
  test -x /opt/hku-runtime/bin/hku-agent-runtime
  test ! -e /app
  test ! -d /opt/hku-runtime/venv
  test -z "$(find /opt/hku-runtime -type f \( -name "*.py" -o -name "*.pyc" \) -print -quit)"
  internal_a="her""mes"
  internal_b="no""us"
  internal_c="co""dex"
  test -z "$(find /opt/hku-runtime \( -iname "*${internal_a}*" -o -iname "*${internal_b}*" -o -iname "*${internal_c}*" \) -print -quit)"
  test ! -w /opt/hku-runtime/data/timetable.sqlite3
  /opt/hku-runtime/bin/hku-agent-runtime __release_check__
' > "$UPDATE_DIR/evidence/release-check.json"
grep -Fq '"dashboard_enabled": false' "$UPDATE_DIR/evidence/release-check.json"
grep -Fq '"global_deadline_seconds": 60.0' "$UPDATE_DIR/evidence/release-check.json"
grep -Fq '"meeting_rows": 28174' "$UPDATE_DIR/evidence/release-check.json"
grep -Fq "\"prompt_sha256\": \"$(contract_value REFRESH_EXPECTED_PROMPT_SHA256)\"" \
  "$UPDATE_DIR/evidence/release-check.json"

timetable_sha="$(docker exec hku-no-sso-v3-agent sha256sum /opt/hku-runtime/data/timetable.sqlite3 | awk '{print $1}')"
[[ "$timetable_sha" == "$(contract_value REFRESH_EXPECTED_TIMETABLE_SHA256)" ]] \
  || fail "protected timetable snapshot changed"

docker exec hku-no-sso-v3-agent \
  /opt/hku-runtime/bin/hku-agent-runtime __live_contract_check__ \
  > "$UPDATE_DIR/evidence/live-timetable-contract.json"
grep -Fq '"verified": true' "$UPDATE_DIR/evidence/live-timetable-contract.json"

curl -fsS "http://127.0.0.1:$(live_value NO_SSO_AGENT_HOST_PORT)/health" \
  > "$UPDATE_DIR/evidence/agent-health.json"
curl -fsS \
  -H "Authorization: Bearer $(live_value NO_SSO_AGENT_API_KEY)" \
  "http://127.0.0.1:$(live_value NO_SSO_AGENT_HOST_PORT)/v1/models" \
  > "$UPDATE_DIR/evidence/agent-models.json"

python3 "$PACKAGE_ROOT/tests/e2e_no_sso_protected_agent.py" \
  --base-url "http://127.0.0.1:$(live_value NO_SSO_AGENT_HOST_PORT)" \
  --env-file "$TARGET_ROOT/.env" \
  --output "$UPDATE_DIR/evidence/behavior.json"

curl -fsS -H 'Host: planner.its.hku.hk' \
  http://127.0.0.1:20380/healthz > "$UPDATE_DIR/evidence/public-health.json"
curl -fsS -H 'Host: planner.its.hku.hk' \
  http://127.0.0.1:20380/ > "$UPDATE_DIR/evidence/public-root.html"
bad_host_status="$(curl -sS -o "$UPDATE_DIR/evidence/bad-host.html" -w '%{http_code}' \
  -H 'Host: invalid.example' http://127.0.0.1:20380/)"
[[ "$bad_host_status" == "421" ]] || fail "arbitrary Host was not rejected"

python3 "$PACKAGE_ROOT/scripts/no_sso_agent_refresh_control.py" \
  compare-preserved --snapshot "$UPDATE_DIR/agent-refresh-before.json"
python3 "$PACKAGE_ROOT/scripts/no_sso_target_control.py" \
  --root "$TARGET_ROOT" --env "$TARGET_ROOT/.env" \
  compare --before "$UPDATE_DIR/control-before.json"
echo "Protected no-SSO agent refresh verification passed."
