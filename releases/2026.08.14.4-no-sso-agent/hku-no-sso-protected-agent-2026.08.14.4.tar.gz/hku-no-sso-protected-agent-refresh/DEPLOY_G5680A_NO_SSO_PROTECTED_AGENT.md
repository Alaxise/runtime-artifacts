# Protected non-SSO agent refresh

This package replaces only the application agent in the existing
`hku-no-sso-v3` lane on port `20380`. It does not recreate the entrypoint, UI,
search API, vector services, persistent data, or any authenticated lane.

## Release identity

- Release: `hku-no-sso-protected-agent-g5680a-2026.08.14.4`
- Supersedes: `.1` (irrelevant seed-directory preflight), `.2` (startup `503`
  escaped the bounded retry), and `.3` (stale packaging tag); do not deploy
  the superseded releases
- Parent: `hku-no-sso-poc03-family-uat-http-g5680a-2026.07.27.13+ui-2026.07.27.16`
- Target root: `/model/dockervolume/hku-custom-no-sso-v3`
- Compose project: `hku-no-sso-v3`
- Mutation boundary: `hku-no-sso-v3-agent`
- Public authority: `planner.its.hku.hk`
- Public port: `20380`
- Qualified source lane: protected no-SSO `28480` on GB10

The protected image is digest-pinned for Linux ARM64 and was built with a
renamed application package, PyInstaller, a multi-stage container build,
application-source removal, and no dashboard.

The agent inherits the live no-SSO lane's RAG URL, API key, and collection.
This allows an agent-behavior comparison without changing the older POC03
corpus currently owned by `20380`.

## Deployment

1. Read the local deployment playbook and compare it with a fresh read-only
   inventory.
2. Confirm the target root, project, parent image, mounts, listeners, and
   control lanes match the package contract.
3. Extract this archive outside the target root.
4. Run `./ApplyNoSSOProtectedAgentRefresh.sh`.
5. Open the canonical `planner.its.hku.hk` route and test timetable, curriculum,
   mixed, and nonexistent-course questions.

The apply script captures rollback state before mutation, validates the live
parent agent, pulls and verifies the approved image, changes only
`NO_SSO_AGENT_IMAGE`, recreates only `agent-runtime`, and automatically
restores the parent agent if qualification fails. Full-lane seed validation is
deliberately excluded because this transaction neither reads nor changes the
historical POC03 seed directory.

## Rollback

```bash
./RollbackNoSSOProtectedAgentRefresh.sh \
  /model/dockervolume/hku-custom-no-sso-v3/updates/<update-id>
```

Rollback restores the captured environment and parent agent, while requiring
all preserved target and control containers to remain unchanged.

## Deliberate exclusions

This is not an accuracy-tuning release. It does not alter the UI, ingress,
search service, collection, embedding endpoint, reranker, vector data,
authentication, or scaling topology. Local playbooks, lane registries, live
secrets, and generated archives are excluded from the target archive.
