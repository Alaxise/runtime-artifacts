#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import time
import urllib.error
import urllib.request


RAW_MARKERS = ("{{cite:", "<｜｜dsml｜｜", "<tool_call")
TERMINAL_ERRORS = (
    "language-model service is temporarily unavailable",
    "provider output was truncated",
    "request took too long to complete safely",
)
INTERNAL_LABELS = (
    "her" + "mes",
    "no" + "us",
    "co" + "dex",
    "clau" + "de",
    "op" + "us",
)
TRANSIENT_STARTUP_STATUS = 503
TRANSIENT_STARTUP_RETRY_SECONDS = 5


def read_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if line and not line.startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            values[key] = value
    return values


def request(base_url: str, api_key: str, question: str, *, stream: bool) -> dict[str, object]:
    payload = json.dumps(
        {
            "model": "hku-rag-agent",
            "messages": [{"role": "user", "content": question}],
            "stream": stream,
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        base_url.rstrip("/") + "/v1/chat/completions",
        data=payload,
        headers={
            "Authorization": "Bearer " + api_key,
            "Content-Type": "application/json",
            "Accept": "text/event-stream" if stream else "application/json",
        },
    )
    started = time.monotonic()
    with urllib.request.urlopen(req, timeout=70) as response:
        raw = response.read().decode("utf-8")
    elapsed = round(time.monotonic() - started, 3)
    if not stream:
        choice = json.loads(raw)["choices"][0]
        return {
            "answer": choice["message"]["content"],
            "done": True,
            "finish_reason": choice.get("finish_reason"),
            "seconds": elapsed,
        }
    answer_parts: list[str] = []
    done = False
    finish_reason = None
    for line in raw.splitlines():
        if not line.startswith("data: "):
            continue
        data = line[6:]
        if data == "[DONE]":
            done = True
            continue
        event = json.loads(data)
        for choice in event.get("choices", []):
            answer_parts.append(choice.get("delta", {}).get("content", ""))
            if choice.get("finish_reason") is not None:
                finish_reason = choice["finish_reason"]
    return {
        "answer": "".join(answer_parts),
        "done": done,
        "finish_reason": finish_reason,
        "seconds": elapsed,
    }


def qualify(
    base_url: str,
    api_key: str,
    *,
    case_id: str,
    question: str,
    required: tuple[str, ...],
    stream: bool,
) -> dict[str, object]:
    attempts: list[dict[str, object]] = []
    for attempt in range(1, 3):
        try:
            result = request(base_url, api_key, question, stream=stream)
        except urllib.error.HTTPError as exc:
            attempts.append({"attempt": attempt, "http_status": exc.code})
            if exc.code == TRANSIENT_STARTUP_STATUS and attempt == 1:
                time.sleep(TRANSIENT_STARTUP_RETRY_SECONDS)
                continue
            raise
        answer = str(result.pop("answer"))
        folded = answer.casefold()
        if not answer.strip():
            raise RuntimeError("empty answer")
        for value in INTERNAL_LABELS + RAW_MARKERS + TERMINAL_ERRORS:
            if value.casefold() in folded:
                raise RuntimeError(f"forbidden user-visible value: {value}")
        matched = all(value.casefold() in folded for value in required)
        terminal = result["finish_reason"] == "stop" and bool(result["done"])
        attempts.append(
            {
                "attempt": attempt,
                "matched": matched,
                "terminal": terminal,
                "seconds": result["seconds"],
                "sha256": hashlib.sha256(answer.encode()).hexdigest(),
            }
        )
        if matched and terminal:
            return {
                "case_id": case_id,
                "question": question,
                "stream": stream,
                "attempts": attempts,
                "answer": answer,
            }
    raise RuntimeError(f"{case_id} failed both bounded qualification samples")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--env-file", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    api_key = read_env(args.env_file).get("NO_SSO_AGENT_API_KEY", "")
    if not api_key:
        raise RuntimeError("agent API key is missing from the target environment")
    checks = (
        (
            "timetable_title",
            "Using the 2026-2027 class timetable records, what course title is listed for BBMS1001?",
            ("Introduction to Human Anatomy and Physiology",),
            False,
        ),
        (
            "timetable_conflict",
            "Does BBMS1001 conflict with BBMS2007?",
            ("BBMS1001", "BBMS2007"),
            False,
        ),
        (
            "rag_advising",
            "Under current HKU degree regulations, what Graduation GPA range corresponds to First Class Honours?",
            ("3.60", "4.30"),
            False,
        ),
        (
            "mixed_timetable_rag",
            "Can I take BBMS1001 and BBMS2007? Check timetable conflicts and any documented enrollment restrictions.",
            ("BBMS1001", "BBMS2007"),
            True,
        ),
        (
            "nonexistent_course",
            "What is the timetable and prerequisite for ABCD9999?",
            ("do not have sufficient evidence",),
            False,
        ),
    )
    evidence: list[dict[str, object]] = []
    for case_id, question, required, stream in checks:
        result = qualify(
            args.base_url,
            api_key,
            case_id=case_id,
            question=question,
            required=required,
            stream=stream,
        )
        answer = str(result["answer"])
        if case_id == "nonexistent_course" and any(
            token in answer.casefold() for token in ("is a course", "carries", "prerequisite is")
        ):
            raise RuntimeError("nonexistent course was presented as factual")
        evidence.append(result)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(evidence, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(f"protected no-SSO agent behavioral cases passed: {len(evidence)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
