# No-SSO UAT welcome-copy refresh

This patch updates only the UI image in the existing `hku-no-sso-v3` project.
It does not replace or restart the entrypoint, agent, search API, vector store,
object store, coordinator, shared embedding service, or shared reranking
service.

## Fixed boundary

| Item | Value |
|---|---|
| Target root | `/model/dockervolume/hku-custom-no-sso-v3` |
| Compose project | `hku-no-sso-v3` |
| Public URL | `http://10.64.142.35:20380` |
| Only recreated container | `hku-no-sso-v3-ui` |
| Release | `hku-no-sso-welcome-copy-g5680a-2026.07.27.16` |
| New UI source | `0d2b5701c4f74323a770362c9e434b9d0e4c748e` |

The new UI artifact is:

`middletaste/hku-custom-web:no-sso-v5-0d2b570-arm64@sha256:90b4e0ecbf8139d24dc170d80c006865227ae748eb70ada078fd6bb44440c740`

The release removes only `timetable conflicts` from the initial planner
welcome message. Agent, prompt, retrieval, citation, security, and data
artifacts remain pinned to the deployed `20380` release.

## Apply

Stage and verify the release archive inside an approved staging directory below
the target root. Then run:

```bash
./ApplyNoSSOUIRefresh.sh /model/dockervolume/hku-custom-no-sso-v3
```

The script:

1. Verifies target ownership and the current UI release boundary.
2. Captures sanitized UI and non-UI container snapshots.
3. Creates a consistent SQLite backup and row-count record.
4. Pulls and validates the locked Linux ARM64 image.
5. Changes only `NO_SSO_UI_IMAGE` in the existing environment.
6. Recreates only the `web-ui` service with `--no-deps`.
7. Requires the reviewed welcome message, the same UI mounts, healthy UI and
   entrypoint, unchanged database counts, and byte-identical non-UI container
   records.
8. Restores the previous UI image automatically if any post-cutover gate fails.

Every backup and check result is preserved below:

`/model/dockervolume/hku-custom-no-sso-v3/evidence/ui-refresh-<UTC timestamp>`

## Rollback

To restore a successful cutover later, provide its preserved evidence directory:

```bash
./RollbackNoSSOUIRefresh.sh \
  /model/dockervolume/hku-custom-no-sso-v3 \
  /model/dockervolume/hku-custom-no-sso-v3/evidence/ui-refresh-<UTC timestamp>
```

Rollback restores the previous image pin and recreates only the UI service.
It does not delete containers, volumes, databases, backups, or evidence.

This release does not change References, Terms and Conditions, Markdown
rendering, citation handling, conversation behavior, or mobile layout.
