#!/usr/bin/env bash
set -euo pipefail

TARGET_ROOT="${1:-/model/dockervolume/hku-custom-no-sso-v3}"
EVIDENCE_DIR="${2:-}"
EXPECTED_ROOT="/model/dockervolume/hku-custom-no-sso-v3"
PROJECT="hku-no-sso-v3"
COMPOSE_FILE="$TARGET_ROOT/compose.no-sso-rag-v2.g5680a.yml"

[[ "$TARGET_ROOT" == "$EXPECTED_ROOT" ]] || {
  echo "ERROR: target root is not approved" >&2
  exit 1
}
[[ -n "$EVIDENCE_DIR" && -f "$EVIDENCE_DIR/env.before" ]] || {
  echo "ERROR: provide the preserved ui-refresh evidence directory" >&2
  exit 1
}
cd "$TARGET_ROOT"

cp -p "$EVIDENCE_DIR/env.before" "$TARGET_ROOT/.env"
[[ ! -f "$EVIDENCE_DIR/env-example.before" ]] \
  || cp -p \
    "$EVIDENCE_DIR/env-example.before" \
    "$TARGET_ROOT/.env.g5680a.no-sso-rag-v2.example"
[[ ! -f "$EVIDENCE_DIR/manifest.before" ]] \
  || cp -p "$EVIDENCE_DIR/manifest.before" "$TARGET_ROOT/g5680a-no-sso-rag-v2-components.lock.json"
[[ ! -f "$EVIDENCE_DIR/image-list.before" ]] \
  || cp -p "$EVIDENCE_DIR/image-list.before" "$TARGET_ROOT/image-list.no-sso-rag-v2.g5680a.txt"

docker-compose -p "$PROJECT" -f "$COMPOSE_FILE" config >/dev/null
docker-compose -p "$PROJECT" -f "$COMPOSE_FILE" up -d --no-deps web-ui

deadline=$((SECONDS + 120))
until curl -fsS http://127.0.0.1:20180/healthz >/dev/null; do
  (( SECONDS < deadline )) || {
    echo "ERROR: previous UI did not become healthy" >&2
    exit 1
  }
  sleep 3
done

echo "Previous UI image restored; all evidence and data were preserved."
